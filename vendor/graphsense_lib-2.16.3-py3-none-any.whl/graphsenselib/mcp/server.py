from __future__ import annotations

import logging
from contextlib import AsyncExitStack, asynccontextmanager

from fastmcp import FastMCP
from mcp.types import Icon
from starlette.requests import Request as StarletteRequest
from starlette.responses import RedirectResponse
from starlette.routing import Route

from graphsenselib import __version__ as gs_version
from graphsenselib.mcp import curation as curation_mod
from graphsenselib.mcp.config import GSMCPConfig
from graphsenselib.mcp.error_logging import ErrorLoggingMiddleware
from graphsenselib.mcp.routes import make_component_fn, make_route_map_fn
from graphsenselib.mcp.tools import register_custom_tools

logger = logging.getLogger(__name__)


class MCPBootstrapError(Exception):
    pass


def build_mcp(app, config: GSMCPConfig) -> tuple[FastMCP, AsyncExitStack]:
    """Build a FastMCP server from the given FastAPI app.

    Returns (mcp, stack). The stack owns async resources (notably the httpx
    client used by external tools) and must be entered before serving and
    exited on shutdown. When used via `attach_to_fastapi`, lifespan handles
    that automatically.
    """
    curation = curation_mod.load(config.resolved_curation_path())
    if config.strict_validation:
        curation_mod.validate_against_app(
            curation, curation_mod.collect_operation_ids(app)
        )

    route_map_fn = make_route_map_fn(curation)
    component_fn = make_component_fn(curation)

    # serverInfo extras advertised in the initialize handshake, forwarded
    # through from_fastapi's **settings to the FastMCP constructor. Both
    # default to the bundled Iknaio branding (icon = the docs favicon) and can
    # be overridden or suppressed via config. Note: not all hosts read `icons`
    # (e.g. Mistral derives the connector icon from the origin favicon instead).
    icon_src = config.resolved_icon_url()
    icons = None
    if icon_src:
        sizes: list[str] | None = [str(s) for s in (config.icon_sizes or "").split()]
        sizes = sizes or None
        icons = [
            Icon(
                src=icon_src,
                mimeType=config.icon_mime_type,
                sizes=sizes,
            )
        ]

    mcp = FastMCP.from_fastapi(
        app=app,
        name="graphsense-mcp",
        version=gs_version,
        instructions=config.resolved_instructions(),
        route_map_fn=route_map_fn,
        mcp_component_fn=component_fn,
        website_url=config.website_url or None,
        icons=icons,
    )

    # Surface unhandled tool/resource/prompt exceptions to the graphsenselib.mcp
    # logger so the same handlers the REST app uses for incident notifications
    # (Slack/SMTP, set up in web/app.py:setup_logging) fire for MCP failures too.
    mcp.add_middleware(ErrorLoggingMiddleware())

    # Consolidated tools receive (mcp, app, stack) but not the MCP config;
    # tools that build Pathfinder deep links (build_pathfinder_file's
    # `open_url`) read the base URL off app.state instead. None means the
    # open-url feature is disabled: the tool then neither mints the link
    # nor advertises it in its description.
    app.state._graphsense_mcp_pathfinder_base_url = (
        config.pathfinder_base_url.rstrip("/")
        if config.pathfinder_open_url_enabled
        else None
    )

    stack = AsyncExitStack()
    register_custom_tools(mcp, app, curation, config, stack)
    return mcp, stack


def attach_to_fastapi(app, config: GSMCPConfig) -> None:
    """Mount the MCP endpoint into the given FastAPI app at `config.path`.

    This is the supported way to deploy the MCP: one uvicorn process serves
    both REST and MCP. The MCP's own session-manager lifespan is composed
    with the app's existing lifespan, and the AsyncExitStack holding the
    external-tool httpx client is entered on startup / exited on shutdown.

    Calling this twice on the same app raises MCPBootstrapError.
    """
    if getattr(app.state, "_graphsense_mcp_attached", False):
        raise MCPBootstrapError("MCP is already attached to this FastAPI app")

    # The wrappers in tools/consolidated.py read this off `app.state` to
    # decide whether to dispatch in-process via ASGITransport (the default)
    # or to issue real HTTP requests against this base URL.
    app.state._graphsense_mcp_internal_base_url = config.internal_base_url

    mcp, stack = build_mcp(app, config)

    # FastMCP >= 3.4.3 validates the request Host against an allowlist
    # (DNS-rebinding protection) and returns 421 for anything but localhost.
    # Behind a reverse proxy the Host is the public domain, so pass the
    # configured allowed hosts through. Done version-safely: FastMCP <= 3.4.2
    # neither validates the Host nor accepts the kwarg, so we fall back cleanly.
    if config.allowed_hosts:
        try:
            # allowed_hosts is only accepted by FastMCP >= 3.4.3; the pinned
            # (older) version doesn't declare it, hence the type-ignore + the
            # TypeError fallback below.
            mcp_asgi = mcp.http_app(
                path="/",
                stateless_http=config.stateless_http,
                allowed_hosts=config.allowed_hosts,  # ty: ignore[unknown-argument]
            )
        except TypeError:
            # FastMCP <= 3.4.2 doesn't accept the kwarg — but it also doesn't
            # validate the Host at all, so there's nothing to enforce and the
            # fallback is harmless. (On >= 3.4.3 the kwarg is honoured above.)
            logger.info(
                "Installed FastMCP does not accept allowed_hosts (needs "
                ">= 3.4.3); it does not validate the request Host either, so "
                "GS_MCP_ALLOWED_HOSTS=%s is not needed and not applied.",
                config.allowed_hosts,
            )
            mcp_asgi = mcp.http_app(path="/", stateless_http=config.stateless_http)
    else:
        mcp_asgi = mcp.http_app(path="/", stateless_http=config.stateless_http)

    existing_lifespan = app.router.lifespan_context

    @asynccontextmanager
    async def composed_lifespan(app_):
        async with stack:
            async with mcp_asgi.lifespan(mcp_asgi):
                async with existing_lifespan(app_):
                    yield

    app.router.lifespan_context = composed_lifespan

    # Register an explicit trailing-slash redirect for the mount path with a
    # relative Location. Starlette's Mount default builds an absolute URL from
    # the incoming Host header, which leaks the upstream hostname when sat
    # behind a reverse proxy that sets Host to the internal upstream (e.g.,
    # APISIX with pass_host: node -> Location: http://gs-rest:9000/mcp/).
    # A relative Location keeps the client on the same origin.
    mount_path = config.path.rstrip("/")
    if mount_path:
        redirect_target = mount_path + "/"

        async def _trailing_slash_redirect(request: StarletteRequest):
            return RedirectResponse(url=redirect_target, status_code=307)

        app.router.routes.append(
            Route(
                mount_path,
                endpoint=_trailing_slash_redirect,
                methods=["GET", "POST", "DELETE", "HEAD", "OPTIONS"],
                include_in_schema=False,
            )
        )

    app.mount(config.path, mcp_asgi)
    app.state._graphsense_mcp_attached = True
    logger.info("graphsense MCP mounted at %s", config.path)


def validate_curation(app, config: GSMCPConfig) -> list[str]:
    """Check the curation YAML against the given FastAPI app. Returns the
    list of problems (empty if valid). Does not raise — the CLI layer decides
    how to surface issues.
    """
    try:
        curation = curation_mod.load(config.resolved_curation_path())
    except curation_mod.CurationError as exc:
        return [str(exc)]

    try:
        curation_mod.validate_against_app(
            curation, curation_mod.collect_operation_ids(app)
        )
    except curation_mod.CurationError as exc:
        return [str(exc)]

    return []
