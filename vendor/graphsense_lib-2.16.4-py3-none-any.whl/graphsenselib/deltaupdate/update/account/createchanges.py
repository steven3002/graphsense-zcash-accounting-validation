import logging
from collections import defaultdict
from datetime import datetime
from typing import Any, Callable, Dict, List, NamedTuple, Optional, Tuple

from graphsenselib.db import DbChange
from graphsenselib.deltaupdate.update.abstractupdater import TABLE_NAME_DELTA_HISTORY
from graphsenselib.deltaupdate.update.account.modelsdelta import (
    BalanceDelta,
    EntityDeltaAccount,
    RawEntityTxAccount,
    RelationDeltaAccount,
)
from graphsenselib.deltaupdate.update.generic import DeltaValue, Tx
from graphsenselib.utils import DataObject as MutableNamedTuple

# from graphsenselib.utils import truncateI32
from graphsenselib.utils.account import (
    get_id_group,
    get_id_group_with_secondary_addresstransactions,
    get_id_group_with_secondary_relations,
)
from graphsenselib.utils.logging import LoggerScope

logger = logging.getLogger(__name__)

# Cassandra's 32-bit `int` upper bound, and the default cap for address tx
# counts. Account keyspaces created before the bigint widening (graphsense-lib
# 2.16.2) keep 32-bit count columns forever — Cassandra cannot ALTER int ->
# bigint — and a write past 2**31 into one of them fails the whole ingest
# batch, which is strictly worse than a saturated under-report.
#
# A keyspace rebuilt since the widening resolves `count_cap` to None instead
# and stores the true count, which the Spark transform also writes now
# (TransformHelpers.saturateToLong, spark 26.08.2). Capping there would be
# actively destructive rather than merely lossy: the merge reads the stored
# total, adds the delta and writes the result back, so a capped write returns
# a *smaller* number than it read — TRON USDT's 3.7e9 would drop to 2^31-1 on
# the first batch that touches it.
INT32_MAX = 2147483647


def _capped(value: int, cap: Optional[int]) -> int:
    """Saturate ``value`` at ``cap``; ``None`` means the column is 64-bit."""
    return value if cap is None else min(value, cap)


def prepare_token_exchange_rates_for_ingest(
    token_rates: Dict[Tuple[str, int], List[float]],
) -> List[DbChange]:
    """Write per-block token exchange rates for the transferred (asset, block)
    pairs so the serving layer can price unpegged tokens.

    token_rates maps (asset, block_id) -> positional fiat_values list.
    """
    return [
        DbChange.new(
            table="token_exchange_rates",
            data={"asset": asset, "block_id": block_id, "fiat_values": fiat_values},
        )
        for (asset, block_id), fiat_values in token_rates.items()
    ]


def prepare_txs_for_ingest(
    delta: List[Tx],
    id_bucket_size: int,
    block_bucket_size: int,
    get_transaction_prefix: Callable[[bytes], Tuple[str, str]],
) -> List[DbChange]:
    changes = []

    for update in delta:
        transaction_id = update.tx_id
        transaction_id_group = get_id_group(transaction_id, id_bucket_size)
        transaction = update.tx_hash

        transaction_prefix = get_transaction_prefix(transaction)[1]

        data = {
            "transaction_id_group": transaction_id_group,
            "transaction_id": transaction_id,
            "transaction": transaction,
        }

        chng = DbChange.new(
            table="transaction_ids_by_transaction_id_group",
            data=data,
        )
        changes.append(chng)

        data = {
            "transaction_prefix": transaction_prefix,
            "transaction": transaction,
            "transaction_id": transaction_id,
        }

        chng = DbChange.new(
            table="transaction_ids_by_transaction_prefix",
            data=data,
        )
        changes.append(chng)

        # get transaction ids

        changes.append(chng)

    changes.extend(
        [
            DbChange.new(
                table="block_transactions",
                data={
                    "block_id_group": get_id_group(tx.block_id, block_bucket_size),
                    "block_id": tx.block_id,
                    "tx_id": tx.tx_id,
                },
            )
            for tx in delta
            if not tx.failed
        ]
    )

    return changes


def prepare_balances_for_ingest(
    delta: List[BalanceDelta], id_bucket_size: int, addr_balances: dict
) -> List[DbChange]:
    changes = []
    for balance in delta:
        addr_id = balance.identifier
        addr_group = get_id_group(addr_id, id_bucket_size)
        balance_update = balance.left_join(
            addr_balances.get(addr_id, BalanceDelta(addr_id, {}))
        )

        for assetname, dv in balance_update.asset_balances.items():
            chng = DbChange.update(
                table="balance",
                data={
                    "address_id_group": addr_group,
                    "address_id": addr_id,
                    "currency": assetname,
                    "balance": dv.value,
                },
            )

            changes.append(chng)

    return changes


def prepare_relations_for_ingest(
    delta: List[RelationDeltaAccount],
    hash_to_id: Dict[str, bytes],
    inrelations: dict,
    relations_with_new_addr: set,
    id_bucket_size: int,
    relations_nbuckets: int,
) -> Tuple[List[DbChange], dict, dict]:
    """Prepare relation changes for database ingest.

    Note: We only query incoming relations. Outgoing relations have identical
    data (no_transactions, value, token_values) and their existence can be
    derived from incoming relations. Both tables are still written to.
    Cassandra's UPSERT behavior handles any rare inconsistencies.

    Args:
        relations_with_new_addr: Set of (src, dst) relation keys where at least
            one address is new. These relations are guaranteed to be new and
            don't need database queries.
    """
    new_relations_in = defaultdict(int)
    new_relations_out = defaultdict(int)

    changes = []

    """ Merging relations deltas """
    for relations_update in delta:
        rel_key = (relations_update.src_identifier, relations_update.dst_identifier)

        # Check if this relation involves a new address (skip query)
        if rel_key in relations_with_new_addr:
            inr = None  # Guaranteed new - no query needed
        else:
            # Queried row (or None) - plain data, may come from a worker process
            inr = inrelations[rel_key]

        id_src = hash_to_id[relations_update.src_identifier]
        id_dst = hash_to_id[relations_update.dst_identifier]

        src_group, src_secondary = get_id_group_with_secondary_relations(
            id_src, id_dst, id_bucket_size, relations_nbuckets
        )
        dst_group, dst_secondary = get_id_group_with_secondary_relations(
            id_dst, id_src, id_bucket_size, relations_nbuckets
        )

        if inr is None:
            """new address relation to insert"""
            new_relations_out[relations_update.src_identifier] += 1
            new_relations_in[relations_update.dst_identifier] += 1

            chng_in = DbChange.new(
                table="address_incoming_relations",
                data={
                    "dst_address_id_group": dst_group,
                    "dst_address_id_secondary_group": dst_secondary,
                    "dst_address_id": id_dst,
                    "src_address_id": id_src,
                    "no_transactions": relations_update.no_transactions,
                    "value": relations_update.value,
                    "token_values": relations_update.token_values,
                },
            )
            chng_out = DbChange.new(
                table="address_outgoing_relations",
                data={
                    "src_address_id_group": src_group,
                    "src_address_id_secondary_group": src_secondary,
                    "src_address_id": id_src,
                    "dst_address_id": id_dst,
                    "no_transactions": relations_update.no_transactions,
                    "value": relations_update.value,
                    "token_values": relations_update.token_values,
                },
            )

        else:
            """update existing address relation - use inr data for both tables"""
            nv = DeltaValue.from_db(inr.value).merge(relations_update.value)

            nv_token = inr.token_values
            nv_token = nv_token if nv_token is not None else {}
            new_token = relations_update.token_values
            keys = set(nv_token.keys()).union(new_token.keys())
            for key in keys:
                if key in nv_token and key in relations_update.token_values:
                    nv_token[key] = DeltaValue.from_db(nv_token[key]).merge(
                        relations_update.token_values[key]
                    )
                elif key in nv_token:
                    pass
                elif key in relations_update.token_values:
                    nv_token[key] = relations_update.token_values[key]

            chng_in = DbChange.update(
                table="address_incoming_relations",
                data={
                    "dst_address_id_group": dst_group,
                    "dst_address_id_secondary_group": dst_secondary,
                    "dst_address_id": id_dst,
                    "src_address_id": id_src,
                    "no_transactions": inr.no_transactions
                    + relations_update.no_transactions,
                    "value": nv,
                    "token_values": nv_token,
                },
            )

            # Cassandra UPSERT handles rare case where outgoing doesn't exist
            chng_out = DbChange.update(
                table="address_outgoing_relations",
                data={
                    "src_address_id_group": src_group,
                    "src_address_id_secondary_group": src_secondary,
                    "src_address_id": id_src,
                    "dst_address_id": id_dst,
                    "no_transactions": inr.no_transactions
                    + relations_update.no_transactions,
                    "value": nv,
                    "token_values": nv_token,
                },
            )

        changes.append(chng_in)
        changes.append(chng_out)

    return changes, new_relations_in, new_relations_out


def prepare_entities_for_ingest(
    delta: List[EntityDeltaAccount],
    resolve_identifier: Dict[str, int],
    bytes_to_row_address: Dict[str, Any],
    new_rel_in: dict,
    new_rel_out: dict,
    id_bucket_size: int,
    get_address_prefix: Callable[[str], Tuple[str, str]],
    count_cap: Optional[int] = INT32_MAX,
) -> Tuple[List[DbChange], int]:
    changes = []
    nr_new_entities = 0
    for update in delta:
        int_ident, entity = (
            resolve_identifier[update.identifier],
            bytes_to_row_address[update.identifier],
        )

        group = get_id_group(int_ident, id_bucket_size)

        if entity is not None:
            """old Address"""
            assert getattr(entity, "address_id") == int_ident

            # recast so we can calculate without handling None all the time
            new_value = EntityDeltaAccount.from_db(entity).merge(update)
            # bytes to hex
            bytes_ = new_value.identifier
            bytes_.hex()
            assert new_value.first_tx_id <= new_value.last_tx_id

            # Nr. of addresses (no_addresses) is currently not updated for clusters
            # Since no merges happen there should not be a difference

            generic_data = {
                "no_incoming_txs": _capped(new_value.no_incoming_txs, count_cap),
                "no_outgoing_txs": _capped(new_value.no_outgoing_txs, count_cap),
                "no_incoming_txs_zero_value": _capped(
                    new_value.no_incoming_txs_zero_value, count_cap
                ),
                "no_outgoing_txs_zero_value": _capped(
                    new_value.no_outgoing_txs_zero_value, count_cap
                ),
                "first_tx_id": new_value.first_tx_id,
                "last_tx_id": new_value.last_tx_id,
                "total_received": new_value.total_received,
                "total_spent": new_value.total_spent,
                "total_tokens_received": new_value.total_tokens_received,
                "total_tokens_spent": new_value.total_tokens_spent,
                "in_degree": entity.in_degree + new_rel_in[update.identifier],
                "out_degree": entity.out_degree + new_rel_out[update.identifier],
                "in_degree_zero_value": entity.in_degree_zero_value,  # too broad
                "out_degree_zero_value": entity.out_degree_zero_value,  # too broad
                "address_id": int_ident,
                "address_id_group": group,
                "is_contract": new_value.is_contract,
            }

            chng = DbChange.update(
                table="address",
                data=generic_data,
            )

            changes.append(chng)
        else:
            """new address"""
            assert update.first_tx_id <= update.last_tx_id
            nr_new_entities += 1

            data = {
                "no_incoming_txs": _capped(update.no_incoming_txs, count_cap),
                "no_outgoing_txs": _capped(update.no_outgoing_txs, count_cap),
                "no_incoming_txs_zero_value": _capped(
                    update.no_incoming_txs_zero_value, count_cap
                ),
                "no_outgoing_txs_zero_value": _capped(
                    update.no_outgoing_txs_zero_value, count_cap
                ),
                "first_tx_id": update.first_tx_id,
                "last_tx_id": update.last_tx_id,
                "total_received": update.total_received,
                "total_spent": update.total_spent,
                "total_tokens_received": update.total_tokens_received,
                "total_tokens_spent": update.total_tokens_spent,
                "address_id": int_ident,
                "address_id_group": group,
                "in_degree": new_rel_in[update.identifier],
                "out_degree": new_rel_out[update.identifier],
                "in_degree_zero_value": 0,
                # update.no_incoming_txs_zero_value, # too broad
                "out_degree_zero_value": 0,
                # update.no_outgoing_txs_zero_value, #  too broad
                "is_contract": update.is_contract,
            }
            data["address"] = update.identifier
            chng = DbChange.new(table="address", data=data)
            changes.append(chng)
            address, address_prefix = get_address_prefix(update.identifier)

            changes.append(
                DbChange.new(
                    table="address_ids_by_address_prefix",
                    data={
                        "address": address,
                        "address_id": int_ident,
                        "address_prefix": address_prefix,
                    },
                )
            )
    return changes, nr_new_entities


def prepare_entity_txs_for_ingest(
    delta: List[RawEntityTxAccount],
    id_bucket_size: int,
    currency: str,
    block_bucket_size_address_txs: int,
) -> List[DbChange]:
    """
    Creating new address transaction
    """
    changes = []
    for atx in delta:
        ident = atx.identifier
        is_token_transfer = len(atx.token_values.keys()) > 0
        for tokenname in atx.token_values.keys():
            (
                address_id_group,
                address_id_secondary_group,
            ) = get_id_group_with_secondary_addresstransactions(
                ident, id_bucket_size, atx.block_id, block_bucket_size_address_txs
            )
            chng = DbChange.new(
                table="address_transactions",
                data={
                    "address_id_group": address_id_group,
                    "address_id_secondary_group": address_id_secondary_group,
                    "address_id": ident,
                    "currency": tokenname,
                    "transaction_id": atx.tx_id,
                    "is_outgoing": atx.is_outgoing,
                    "tx_reference": atx.tx_reference,
                },
            )
            changes.append(chng)

        if not is_token_transfer:
            (
                address_id_group,
                address_id_secondary_group,
            ) = get_id_group_with_secondary_addresstransactions(
                ident, id_bucket_size, atx.block_id, block_bucket_size_address_txs
            )
            chng = DbChange.new(
                table="address_transactions",
                data={
                    "address_id_group": address_id_group,
                    "address_id_secondary_group": address_id_secondary_group,
                    "address_id": ident,
                    "currency": currency,
                    "transaction_id": atx.tx_id,
                    "is_outgoing": atx.is_outgoing,
                    "tx_reference": atx.tx_reference,
                },
            )

            changes.append(chng)
    return changes


def get_bookkeeping_changes(
    base_statistics: MutableNamedTuple,
    current_statistics: NamedTuple,
    last_block_processed: int,
    nr_new_address_relations: int,
    nr_new_addresses: int,
    nr_new_tx: int,
    highest_address_id: int,
    runtime_seconds: int,
    bts: Dict[int, datetime],
    new_blocks: int,
    patch_mode: bool,
) -> List[DbChange]:
    """Creates changes for the bookkeeping tables like summary statistics after
    other data has been updated.

    Args:
        base_statistics (MutableNamedTuple): statistics db row, all the other
        parameters are note data is updated in this process
        current_statistics (NamedTuple): Current value of db statistics for comparison
        last_block_processed (int): Last block processed
        nr_new_address_relations (int): Delta new addresses relations in changeset
        nr_new_addresses (int): Delta new addresses in changeset
        nr_new_tx (int): Delta new txs in changeset
        highest_address_id (int): current highest address_id
        runtime_seconds (int): runtime to create the last changes in seconds
        bts (Dict[int, datetime]): mapping from block to its timestamp
        delta values
    """
    changes = []
    with LoggerScope.debug(logger, "Creating summary_statistics updates") as lg:
        lb_date = bts[last_block_processed]
        stats = base_statistics
        stats.no_blocks = current_statistics.no_blocks + new_blocks
        stats.timestamp = int(lb_date.timestamp())
        stats.no_address_relations += nr_new_address_relations
        stats.no_addresses += nr_new_addresses
        stats.no_transactions += nr_new_tx

        statistics = stats.as_dict()

        if current_statistics.no_blocks != stats.no_blocks:
            if not patch_mode:
                assert current_statistics.no_blocks < stats.no_blocks

        changes.append(DbChange.new(table="summary_statistics", data=statistics))

        lg.debug(f"Statistics: {statistics}")

        data_history = {
            "last_synced_block": last_block_processed,
            "last_synced_block_timestamp": lb_date,
            "highest_address_id": highest_address_id,
            "timestamp": datetime.now(),
            "write_new": False,
            "write_dirty": False,
            "runtime_seconds": runtime_seconds,
        }
        changes.append(DbChange.new(table=TABLE_NAME_DELTA_HISTORY, data=data_history))

        lg.debug(f"History: {data_history}")

    return changes
