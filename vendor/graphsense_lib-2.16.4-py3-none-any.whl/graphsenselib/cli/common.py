import hashlib
import os
import sys

import click

from ..config import (
    default_environments,
    get_config,
    schema_types,
    supported_base_currencies,
)
import logging

logger = logging.getLogger(__name__)


def require_environment(required=True):
    def inner(function):
        function = click.option(
            "--env",
            "-e",
            type=click.Choice(default_environments, case_sensitive=False),
            help="Environment to work on",
            required=required,
        )(function)
        return function

    return inner


def require_schema_type(required=True):
    def inner(function):
        function = click.option(
            "--schema",
            "-s",
            type=click.Choice(schema_types, case_sensitive=False),
            help="Type of schema supported by graphsense.",
            required=required,
        )(function)
        return function

    return inner


def require_currency(required=True):
    def inner(function):
        function = click.option(
            "--currency",
            "-c",
            type=click.Choice(supported_base_currencies, case_sensitive=False),
            help="Currency to work on",
            required=required,
        )(function)
        return function

    return inner


def spark_profile_option(function):
    """Add --spark-profile to a command that resolves a Spark config.

    Selects a named profile when spark_config is in the nested baseline+profiles
    form; defaults to None, which resolves to the baseline profile (nested) or
    the flat config as-is (legacy).
    """
    function = click.option(
        "--spark-profile",
        "spark_profile",
        default=None,
        help=(
            "Named spark_config profile to use (nested baseline+profiles form). "
            "Defaults to the baseline profile."
        ),
    )(function)
    return function


def out_file(required=True, append=False):
    def inner(function):
        function = click.option(
            "--out-file",
            "-o",
            type=click.File(
                mode="a" if append else "w",
                encoding=None,
                errors="strict",
                lazy=None,
                atomic=False,
            ),
            help="Output text file.",
            required=required,
        )(function)
        return function

    return inner


def try_load_config(filename: str):
    remaining_args = sys.argv[1:]

    global_options_with_values = {"--config-file"}
    top_level_command = None
    skip_next = False
    for arg in remaining_args:
        if skip_next:
            skip_next = False
            continue
        if arg in global_options_with_values:
            skip_next = True
            continue
        if arg.startswith("-"):
            continue
        top_level_command = arg
        break

    is_optional_config_command = top_level_command in [
        "tagpack-tool",
        "tagstore",
        "web",
        "convert",
        "mcp",
    ]

    app_config = get_config()
    f = filename or app_config.underlying_file

    try:
        if is_optional_config_command:
            success, errors = app_config.load_partial(filename=filename)

            if not success:
                logger.debug(
                    f"Partial config loading for {top_level_command} with {len(errors)} issues:"
                )
                for error in errors:
                    logger.debug(f"  - {error}")
                logger.debug("Continuing with partial/default configuration...")
            else:
                logger.debug(f"Config created successfully for {top_level_command}")
        else:
            # Use strict loading for other tools
            app_config.load(filename=filename)

        if f and os.path.exists(f):
            with open(f, "rb") as file:
                md5hash = hashlib.md5(file.read()).hexdigest()
        else:
            md5hash = "no-config-file"
            if not is_optional_config_command:
                raise Exception("No config file loaded")

        return app_config, md5hash

    except Exception as e:
        if not f:
            logger.error("No config file specified or found in default locations")
        elif not os.path.exists(f):
            logger.error(f"Config file {f} does not exist")
            logger.error("Suggestions")
            file_loc = " or ".join(app_config.model_config["default_files"])
            logger.error(
                f"Error: {e} \n"
                f"Please create the file in {file_loc} or specify a custom config path"
                f" in the environment variable {app_config.model_config['file_env_var']}."
            )
        else:
            logger.error(e)
            logger.error(
                "If there are errors in your graphsenselib config, please check the template below:"
            )
            logger.error("Template")
            logger.debug(app_config.generate_yaml(DEBUG=False))

        sys.exit(10)
