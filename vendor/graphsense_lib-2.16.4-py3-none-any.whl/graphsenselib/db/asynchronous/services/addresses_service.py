import asyncio
from typing import Any, Dict, List, Optional, Protocol, Tuple, Callable

from graphsenselib.config import chain_forks
from graphsenselib.datatypes.common import NodeType
from graphsenselib.db.asynchronous.cassandra import MAX_ROW_LOOKUP_CONCURRENCY
from graphsenselib.errors import (
    AddressNotFoundException,
    NetworkNotFoundException,
    ClusterNotFoundException,
    DBInconsistencyException,
)
from graphsenselib.utils.address import address_to_user_format
from graphsenselib.utils.bch import (
    InvalidAddress as BCHInvalidAddress,
    bch_address_to_legacy,
)
from graphsenselib.utils.rest_utils import is_eth_like
from graphsenselib.utils.tron import (
    evm_to_tron_address_string,
    tron_address_to_evm_string,
)
from graphsenselib.tagstore.db import TagPublic

from .blocks_service import BlocksService
from .common import (
    address_from_row,
    cannonicalize_address,
    gather_bounded,
    get_address,
    links_response,
    list_neighbors,
    tagstore_session,
    tagstore_session_kwargs,
    try_get_cluster_id,
    txs_from_rows,
)
from .entities_service import EntitiesService
from .models import (
    Address,
    AddressTagResult,
    AddressTxs,
    CrossChainPubkeyRelatedAddresses,
    Entity,
    LabeledItemRef,
    Links,
    NeighborAddress,
    NeighborAddresses,
    CrossChainPubkeyRelatedAddress,
    TagSummary,
    AddressTagQueryInput,
)
from .rates_service import RatesService
from .tags_service import TagsService


class DatabaseProtocol(Protocol):
    async def get_address_id(self, currency: str, address: str) -> Optional[int]: ...
    async def list_address_txs(
        self,
        currency: str,
        address: str,
        direction: Optional[str],
        min_height: Optional[int],
        max_height: Optional[int],
        order: str,
        token_currency: Optional[str],
        page: Optional[str],
        pagesize: Optional[int],
    ) -> Tuple[List[Dict[str, Any]], Optional[str]]: ...
    async def list_address_links(
        self,
        currency: str,
        address: str,
        neighbor: str,
        min_height: Optional[int],
        max_height: Optional[int],
        order: str,
        token_currency: Optional[str],
        page: Optional[str],
        pagesize: Optional[int],
    ) -> Tuple[List[Dict[str, Any]], Optional[str]]: ...
    async def get_address_entity_id(self, currency: str, address: str) -> int: ...
    async def new_entity(self, currency: str, address: str) -> Dict[str, Any]: ...
    async def get_fresh_cluster_id(
        self, currency: str, address_id: int
    ) -> Optional[int]: ...
    def get_token_configuration(self, currency: str) -> Dict[str, Any]: ...


# (base_chain, fork_chain) pairs, derived from the shared fork registry
# (config.chain_forks) so fork relationships live in one place.
FORK_TUPLES = [(spec["base"], fork) for fork, spec in chain_forks.items()]

# Networks where an address on one chain is structurally identical to an
# address on the other, so cross-chain presence can be detected by a direct
# lookup of the equivalent address without consulting the pubkey table.
TRIVIAL_FORK_PAIRS = [("btc", "bch")]
TRIVIAL_EVM_PAIRS = [("trx", "eth")]


class AddressesService:
    def __init__(
        self,
        db: DatabaseProtocol,
        tags_service: TagsService,
        entities_service: EntitiesService,
        blocks_service: BlocksService,
        rates_service: RatesService,
        logger: Any,
    ):
        self.db = db
        self.tagstore = tags_service.tagstore if tags_service is not None else None
        self.tags_service = tags_service
        self.entities_service = entities_service
        self.blocks_service = blocks_service
        self.rates_service = rates_service
        self.logger = logger

    async def _handle_fork_address_overlap(
        self,
        raw_query_results: List[Dict[str, Any]],
        address: str,
        network: Optional[str] = None,
    ) -> List[CrossChainPubkeyRelatedAddress]:
        results = []
        for b, f in FORK_TUPLES:
            included_nets = {addr["currency"] for addr in raw_query_results}

            if network is not None:
                included_nets.add(network)

            if b in included_nets and f not in included_nets:
                base_network = b
                fork_network = f

            elif f in included_nets and b not in included_nets:
                base_network = f
                fork_network = b
            else:
                continue

            core_addresses = [
                addr for addr in raw_query_results if addr["currency"] == base_network
            ]

            if not core_addresses:
                continue

            # Try each base-network address format on the fork chain.
            # The original queried address (e.g. a ZEC address) won't
            # exist on the fork network, so we use the derived
            # base-network addresses instead.
            for candidate in core_addresses:
                try:
                    fork_address = await self.get_address(
                        fork_network,
                        candidate["address"],
                        tagstore_groups=[],
                        include_actors=False,
                    )
                except (AddressNotFoundException, NetworkNotFoundException):
                    continue

                results.append(
                    CrossChainPubkeyRelatedAddress(
                        currency=fork_address.currency,
                        address=fork_address.address,
                        type=candidate.get("type", "fork_only"),
                        pubkey=candidate.get("pubkey"),
                    )
                )
        return results

    async def _handle_trivial_cross_chain_overlap(
        self,
        address: str,
        network: Optional[str],
        existing: List[CrossChainPubkeyRelatedAddress],
    ) -> List[CrossChainPubkeyRelatedAddress]:
        # Detect cross-chain presence for cases where the relationship is
        # structural (not pubkey-derived): same address bytes between BTC and
        # BCH legacy P2PKH/P2SH, and trivial TRX<->ETH address conversion.
        if network is None:
            return []

        existing_keys = {(a.network, a.address) for a in existing}
        results: List[CrossChainPubkeyRelatedAddress] = []

        for a, b in TRIVIAL_FORK_PAIRS:
            if network not in (a, b):
                continue
            other = b if network == a else a

            try:
                lookup_address = bch_address_to_legacy(address)
            except BCHInvalidAddress:
                continue

            lower = lookup_address.lower()
            if lower.startswith("bc1") or lower.startswith("ltc1"):
                # Segwit / bech32 addresses are not script-equivalent across
                # the BTC/BCH fork; skip rather than emit a false positive.
                continue

            if (other, lookup_address) in existing_keys:
                continue
            try:
                other_addr = await self.get_address(
                    other,
                    lookup_address,
                    tagstore_groups=[],
                    include_actors=False,
                )
            except (AddressNotFoundException, NetworkNotFoundException):
                continue

            key = (other_addr.currency, other_addr.address)
            if key in existing_keys:
                continue
            existing_keys.add(key)
            results.append(
                CrossChainPubkeyRelatedAddress(
                    currency=other_addr.currency,
                    address=other_addr.address,
                    type="trivial_fork",
                )
            )

        for a, b in TRIVIAL_EVM_PAIRS:
            if network not in (a, b):
                continue
            other = b if network == a else a
            try:
                if network == "trx":
                    converted = tron_address_to_evm_string(address)
                else:
                    converted = evm_to_tron_address_string(address)
            except Exception as exc:
                self.logger.warning(
                    "Skipping trivial EVM cross-chain lookup for %s on %s: %s",
                    address,
                    network,
                    exc,
                )
                continue

            if (other, converted) in existing_keys:
                continue
            try:
                other_addr = await self.get_address(
                    other,
                    converted,
                    tagstore_groups=[],
                    include_actors=False,
                )
            except (AddressNotFoundException, NetworkNotFoundException):
                continue

            key = (other_addr.currency, other_addr.address)
            if key in existing_keys:
                continue
            existing_keys.add(key)
            results.append(
                CrossChainPubkeyRelatedAddress(
                    currency=other_addr.currency,
                    address=other_addr.address,
                    type="trivial_evm",
                )
            )

        return results

    async def get_cross_chain_pubkey_related_addresses(
        self,
        address: str,
        network: Optional[str] = None,
        page: Optional[int] = None,
        pagesize: Optional[int] = None,
    ) -> CrossChainPubkeyRelatedAddresses:
        if page is not None and page < 1:
            raise ValueError("Page number must be at least 1")

        try:
            raw_query_results = await self.db.get_cross_chain_pubkey_related_addresses(
                address, network
            )
        except NetworkNotFoundException:
            raw_query_results = []

        data = [
            CrossChainPubkeyRelatedAddress.model_validate(addr)
            for addr in raw_query_results
            if addr["address"] != address
            or (
                network is None or (network is not None and addr["currency"] != network)
            )
        ]

        if network is not None and network == "trx" and len(data) == 0:
            # Special case for TRX, if trx is not found in the address_to_pubkey table, retry with
            # the EVM equivalent address
            # This is because TRX addresses can be derived from EVM addresses
            # and we want to ensure we find related addresses even if the TRX address is not
            # directly in the address_to_pubkey table.
            try:
                evm_address = tron_address_to_evm_string(address)
            except Exception as exc:
                self.logger.warning(
                    "Skipping TRX pubkey-derived lookup due to invalid TRX address %s: %s",
                    address,
                    exc,
                )
            else:
                try:
                    results_trx = (
                        await self.db.get_cross_chain_pubkey_related_addresses(
                            evm_address, "eth"
                        )
                    )
                except NetworkNotFoundException:
                    results_trx = []

                data = [
                    CrossChainPubkeyRelatedAddress.model_validate(addr)
                    for addr in results_trx
                    if addr["address"] != address
                    or (
                        network is None
                        or (network is not None and addr["currency"] != network)
                    )
                ]

                raw_query_results = results_trx

        forked_addresses = await self._handle_fork_address_overlap(
            raw_query_results, address, network=network
        )

        data.extend(forked_addresses)

        trivial_addresses = await self._handle_trivial_cross_chain_overlap(
            address, network, data
        )

        data.extend(trivial_addresses)

        # Note: we always produce all results and then simulate pages if needed.
        next_page = None
        if page is not None and pagesize is not None:
            page = page - 1
            start = page * pagesize
            end = start + pagesize
            if end < len(data):
                next_page = page + 2
            data = data[start:end]

        return CrossChainPubkeyRelatedAddresses(addresses=data, next_page=next_page)

    async def get_address(
        self,
        currency: str,
        address: str,
        tagstore_groups: List[str],
        include_actors: bool = True,
        new_address_fallback: bool = True,
    ) -> Address:
        return await get_address(
            self.db,
            self.tagstore,
            self.rates_service,
            currency,
            address,
            tagstore_groups,
            include_actors=include_actors,
            new_address_fallback=new_address_fallback,
        )

    async def list_tags_by_address(
        self,
        currency: str,
        address: str,
        tagstore_groups: List[str],
        cache: Dict[str, Any],
        page: Optional[int] = None,
        pagesize: Optional[int] = None,
        include_best_cluster_tag: bool = False,
        include_pubkey_derived_tags: bool = False,
    ) -> AddressTagResult:
        page = page or 0

        assert page is None or isinstance(page, int)

        cluster_id = await try_get_cluster_id(self.db, currency, address, cache=cache)

        if include_pubkey_derived_tags:
            additional_tags = await self.get_cross_chain_pubkey_related_addresses(
                address,
                network=currency,
            )

            addresses = [AddressTagQueryInput(network=currency, address=address)] + [
                AddressTagQueryInput(
                    network=pk.network,
                    address=pk.address,
                    inherited_from_marker="pubkey",
                )
                for pk in additional_tags.addresses
            ]
        else:
            addresses = [AddressTagQueryInput(network=currency, address=address)]

        tags, is_last_page = await self.tags_service.list_tags_by_addresses_raw(
            addresses,
            tagstore_groups,
            page=page,
            pagesize=pagesize,
            include_best_cluster_tag=include_best_cluster_tag,
            cache=cache,
        )

        self.logger.info(
            f"Fetched {len(tags)} tags for address {address} on network {currency}"
        )

        # Convert to AddressTag objects using tags service
        address_tags = []
        for pt in tags:
            tag = self.tags_service._address_tag_from_public_tag(pt, cluster_id)
            # Handle foreign network clusters
            if tag.currency and tag.currency.upper() != currency.upper():
                tag.entity = await try_get_cluster_id(
                    self.db, tag.currency, address, cache=cache
                )
            address_tags.append(tag)

        return self.tags_service._get_address_tag_result(
            current_page=page,
            page_size=pagesize,
            tags=address_tags,
            is_last_page=is_last_page,
        )

    async def list_address_txs(
        self,
        currency: str,
        address: str,
        min_height: Optional[int] = None,
        max_height: Optional[int] = None,
        min_date: Optional[Any] = None,
        max_date: Optional[Any] = None,
        direction: Optional[str] = None,
        order: str = "desc",
        token_currency: Optional[str] = None,
        page: Optional[str] = None,
        pagesize: Optional[int] = None,
    ) -> AddressTxs:
        min_b, max_b = await self.blocks_service.get_min_max_height(
            currency, min_height, max_height, min_date, max_date
        )

        address = cannonicalize_address(currency, address)
        results, paging_state = await self.db.list_address_txs(
            currency=currency,
            address=address,
            direction=direction,
            min_height=min_b,
            max_height=max_b,
            order=order,
            token_currency=token_currency,
            page=page,
            pagesize=pagesize,
        )

        address_txs = await txs_from_rows(
            currency,
            results,
            self.rates_service,
            self.db.get_token_configuration(currency),
        )
        return AddressTxs(next_page=paging_state, address_txs=address_txs)

    async def list_address_neighbors(
        self,
        currency: str,
        address: str,
        direction: str,
        tagstore_groups: List[str],
        only_ids: Optional[List[str]] = None,
        include_labels: bool = False,
        include_actors: bool = True,
        page: Optional[str] = None,
        pagesize: Optional[int] = None,
    ) -> NeighborAddresses:
        address = cannonicalize_address(currency, address)

        if isinstance(only_ids, list):
            aws = [
                self.db.get_address_id(currency, cannonicalize_address(currency, id))
                for id in only_ids
            ]
            only_ids = await asyncio.gather(*aws)
            only_ids = [id for id in only_ids if id is not None]

        is_outgoing = "out" in direction
        dst = "dst" if is_outgoing else "src"
        relations = []

        # Share one Postgres session across this request's tagstore calls
        # (the label batch inside list_neighbors and the actor batch below)
        # instead of opening one pool connection per call.
        async with tagstore_session(self.tagstore) as ts:
            ts_kw = tagstore_session_kwargs(ts)

            results, paging_state = await list_neighbors(
                self.db,
                currency,
                address,
                direction,
                NodeType.ADDRESS,
                ids=only_ids,
                include_labels=include_labels,
                page=page,
                pagesize=pagesize,
                tagstore=self.tagstore if include_labels else None,
                tagstore_groups=tagstore_groups if include_labels else None,
                tagstore_session=ts,
            )

            if results is None:
                return NeighborAddresses(neighbors=[])

            # Batched actor prefetch: one Postgres query for the whole page
            # instead of one per neighbor (each previously opened its own
            # session via the per-row get_address() call below).
            actors_by_address: Dict[str, List[LabeledItemRef]] = {}
            if include_actors and results:
                addr_strings = [
                    address_to_user_format(currency, row[dst + "_address"])
                    for row in results
                ]
                actors_by_address = await self.tags_service.get_actors_by_subjectids(
                    addr_strings, tagstore_groups, **ts_kw
                )

            rates = await self.rates_service.get_rates(currency)
            token_config = self.db.get_token_configuration(currency)

            # Batched fresh-cluster-id prefetch (UTXO only): pure Cassandra
            # point reads, bounded well above the tagstore concurrency limit
            # since none of this fan-out touches Postgres.
            fresh_cluster_by_id: Dict[int, Optional[int]] = {}
            if not is_eth_like(currency) and results:
                address_ids = [row[dst + "_address_id"] for row in results]
                fresh_sem = asyncio.Semaphore(MAX_ROW_LOOKUP_CONCURRENCY)
                fresh_ids = await gather_bounded(
                    fresh_sem,
                    *[
                        self.db.get_fresh_cluster_id(currency, aid)
                        for aid in address_ids
                    ],
                )
                fresh_cluster_by_id = dict(zip(address_ids, fresh_ids))

            nodes = []
            for row in results:
                full_row = row.get(dst + "_address_row")
                addr_string = address_to_user_format(currency, row[dst + "_address"])
                if full_row is None:
                    # Address row missing from the batched fetch (a data
                    # inconsistency) - fall back to the original per-address
                    # path so behavior matches exactly.
                    node = await self.get_address(
                        currency,
                        addr_string,
                        tagstore_groups,
                        include_actors=include_actors,
                    )
                else:
                    actors = (
                        actors_by_address.get(addr_string) if include_actors else None
                    )
                    node = address_from_row(
                        currency,
                        full_row,
                        rates.rates,
                        token_config,
                        actors,
                        fresh_cluster_id=fresh_cluster_by_id.get(
                            row[dst + "_address_id"]
                        ),
                    )
                nodes.append(node)

        for row, node in zip(results, nodes):
            nb = NeighborAddress(
                labels=row["labels"],
                value=row["value"],
                no_txs=row["no_transactions"],
                token_values=row["token_values"],
                address=node,
            )
            relations.append(nb)

        return NeighborAddresses(next_page=paging_state, neighbors=relations)

    async def list_address_links(
        self,
        currency: str,
        address: str,
        neighbor: str,
        min_height: Optional[int] = None,
        max_height: Optional[int] = None,
        min_date: Optional[Any] = None,
        max_date: Optional[Any] = None,
        order: str = "desc",
        token_currency: Optional[str] = None,
        page: Optional[str] = None,
        pagesize: Optional[int] = None,
        request_timeout: Optional[float] = None,
    ) -> Links:
        min_b, max_b = await self.blocks_service.get_min_max_height(
            currency, min_height, max_height, min_date, max_date
        )

        address = cannonicalize_address(currency, address)
        neighbor = cannonicalize_address(currency, neighbor)

        try:
            result = await asyncio.wait_for(
                self.db.list_address_links(
                    currency,
                    address,
                    neighbor,
                    min_height=min_b,
                    max_height=max_b,
                    order=order,
                    token_currency=token_currency,
                    page=page,
                    pagesize=pagesize,
                ),
                timeout=request_timeout,
            )
        except asyncio.TimeoutError:
            raise Exception(
                f"Timeout while fetching links for {currency}/"
                f"{address_to_user_format(currency, address)} to "
                f"{address_to_user_format(currency, neighbor)}"
            )

        return await links_response(
            currency,
            result,
            self.rates_service,
            self.db.get_token_configuration(currency),
        )

    async def get_address_entity(
        self,
        currency: str,
        address: str,
        include_actors: bool = True,
        tagstore_groups: List[str] = [],
    ) -> Entity:
        address_canonical = cannonicalize_address(currency, address)

        try:
            entity_id = await self.db.get_address_entity_id(currency, address_canonical)
        except AddressNotFoundException:
            rates = await self.rates_service.get_rates(currency)
            entity_data = await self.db.new_entity(currency, address_canonical)
            return self.entities_service._from_row(
                currency,
                entity_data,
                rates.rates,
                self.db.get_token_configuration(currency),
            )

        try:
            entity = await self.entities_service.get_entity(
                currency,
                entity_id,
                include_actors=include_actors,
                tagstore_groups=tagstore_groups,
            )
            # Remove inherited indicator from tag if it's the same address
            if (
                entity is not None
                and entity.best_address_tag is not None
                and entity.best_address_tag.address == address
            ):
                entity.best_address_tag.inherited_from = None
            return entity
        except ClusterNotFoundException:
            raise DBInconsistencyException(
                f"entity referenced by {address} in {currency} not found"
            )

    async def get_tag_summary_by_address(
        self,
        currency: str,
        address: str,
        tagstore_groups: List[str],
        include_best_cluster_tag: bool = False,
        include_pubkey_derived_tags: bool = False,
        only_propagate_high_confidence_actors: bool = True,
        tag_transformer: Callable[["TagPublic"], "TagPublic"] = None,
    ) -> TagSummary:
        if include_pubkey_derived_tags:
            additional_tags = await self.get_cross_chain_pubkey_related_addresses(
                address,
                network=currency,
            )

            addresses = [AddressTagQueryInput(network=currency, address=address)] + [
                AddressTagQueryInput(
                    network=pk.network,
                    address=pk.address,
                    inherited_from_marker="pubkey",
                )
                for pk in additional_tags.addresses
            ]
        else:
            addresses = [AddressTagQueryInput(network=currency, address=address)]

        return await self.tags_service.get_tag_summary_by_addresses(
            addresses,
            tagstore_groups,
            only_propagate_high_confidence_actors=only_propagate_high_confidence_actors,
            include_best_cluster_tag=include_best_cluster_tag,
            tag_transformer=tag_transformer,
        )
