import asyncio
import hashlib
import logging
import re
import time
from collections import UserDict, namedtuple
from datetime import datetime
from functools import partial
from itertools import product
from math import floor
from pprint import PrettyPrinter
from typing import Callable, List, Optional, Sequence, Tuple, Union, Dict, Any

from async_lru import alru_cache
from cassandra import ConsistencyLevel, InvalidRequest
from cassandra.auth import PlainTextAuthProvider
from cassandra.cluster import (
    EXEC_PROFILE_DEFAULT,
    Cluster,
    ExecutionProfile,
    NoHostAvailable,
)
from cassandra.policies import (
    ConstantSpeculativeExecutionPolicy,
    DCAwareRoundRobinPolicy,
    ExponentialReconnectionPolicy,
    TokenAwarePolicy,
)
from cassandra.protocol import ProtocolException
from cassandra.query import SimpleStatement, ValueSequence, dict_factory
from graphsenselib.db.cassandra import GraphsenseRetryPolicy
from graphsenselib.utils.accountmodel import hex_to_bytes
from graphsenselib.config.cassandra_async_config import CassandraConfig
from graphsenselib.db.state import (
    FRESH_CLUSTERING_ACTIVE_KEY,
    INGEST_COMPLETE_KEY,
    STATE_TABLE,
)
from graphsenselib.datatypes.abi import decode_logs_db
from graphsenselib.utils.account import calculate_id_group_with_overflow
from graphsenselib.utils.accountmodel import bytes_to_hex, hex_str_to_bytes, strip_0x
from graphsenselib.utils.address import address_to_user_format, cannonicalize_address
from graphsenselib.utils.constants import (
    is_fresh_cluster_id,
    is_representable_entity_id,
    replace_tron_dummy_address_with_valid_null_address,
    to_public_fresh_cluster_id,
    to_raw_fresh_cluster_id,
)
from graphsenselib.utils.function_call_parser import (
    parse_function_call,
    function_signatures as function_call_signatures,
)
from graphsenselib.utils.pubkey_to_address import convert_pubkey_to_addresses
from graphsenselib.utils.transactions import (
    SubTransactionIdentifier,
    SubTransactionType,
)
from graphsenselib.utils.tron import partial_tron_to_partial_evm
from graphsenselib.datatypes import NodeType
from graphsenselib.errors import (
    AddressNotFoundException,
    BadConfigError,
    BadUserInputException,
    BlockNotFoundException,
    ClusterNotFoundException,
    DBInconsistencyException,
    NetworkNotFoundException,
    NotFoundException,
    TransactionNotFoundException,
    nodeNotFoundException,
)
from graphsenselib.utils.rest_utils import is_eth_like
from graphsenselib.utils.account import get_block_from_tx_id


logger = logging.getLogger(__name__)


class GraphsenseFallbackToLocalOneRetryPolicy(GraphsenseRetryPolicy):
    """Read-path policy that downgrades LOCAL_QUORUM to LOCAL_ONE on the
    first Unavailable / ReadTimeout when at least one replica is alive.

    Lets the web tier survive a rolling restart on RF=2 (where losing one
    of two replicas takes LOCAL_QUORUM below quorum) at the cost of
    read-after-write consistency for those downgraded reads.

    Scope is intentionally narrow:
      * Only the first attempt downgrades. Subsequent retries delegate to
        the parent policy (retry-on-next-host / backoff / RETHROW).
      * Only LOCAL_QUORUM is downgraded. Stronger CLs (QUORUM, ALL,
        EACH_QUORUM) are left alone — if the caller picked them, the
        availability trade-off was deliberate.
      * Writes are NOT downgraded — `on_write_timeout` is inherited
        unchanged. The web reader is read-only; if a write path ever
        starts using this policy, downgrading writes would silently
        weaken durability and is the wrong default.
    """

    def on_unavailable(
        self, query, consistency, required_replicas, alive_replicas, retry_num
    ):
        if (
            retry_num == 0
            and consistency == ConsistencyLevel.LOCAL_QUORUM
            and alive_replicas >= 1
        ):
            logger.warning(
                "Unavailable at LOCAL_QUORUM (need %d, have %d); "
                "downgrading to LOCAL_ONE for this read",
                required_replicas,
                alive_replicas,
            )
            return (self.RETRY, ConsistencyLevel.LOCAL_ONE)
        return super().on_unavailable(
            query, consistency, required_replicas, alive_replicas, retry_num
        )

    def on_read_timeout(self, *args, **kwargs):
        retry_num = kwargs.get("retry_num")
        consistency = kwargs.get("consistency")
        received = kwargs.get("received_responses")
        required = kwargs.get("required_responses")
        if (
            retry_num == 0
            and consistency == ConsistencyLevel.LOCAL_QUORUM
            and received is not None
            and required is not None
            and 1 <= received < required
        ):
            logger.warning(
                "Read timeout at LOCAL_QUORUM (got %d/%d responses); "
                "downgrading to LOCAL_ONE for this read",
                received,
                required,
            )
            return (self.RETRY, ConsistencyLevel.LOCAL_ONE)
        return super().on_read_timeout(*args, **kwargs)


SMALL_PAGE_SIZE = 1000
BIG_PAGE_SIZE = 5000
SEARCH_PAGE_SIZE = 100

MAX_HEX_STRING_LENGTH = 64
FETCH_SIZE_MIN = 100
HEX_ALPHABET = "0123456789ABCDEF"

# Bound on concurrent per-row trace/log/timestamp lookups in
# normalize_address_transactions — turns up to `pagesize` sequential round-trips
# per page into bounded-concurrent ones on the hottest (address-txs) endpoint.
MAX_ROW_LOOKUP_CONCURRENCY = 100

# In-flight statement cap for the per-(direction, asset, tx) subquery fan-out
# in list_address_txs_ordered. High enough to keep the pipeline to all nodes
# full, low enough that one links scan cannot monopolize the session.
ADDRESS_TXS_SUBQUERY_CONCURRENCY = 500


def _fresh_degrees_pending(row) -> bool:
    """A fresh_cluster_stats row lacking degrees.

    ``fresh_cluster_stats`` no longer carries ``in_degree``/``out_degree``
    (dropped in transformed_utxo migration 4->5; the recompute never derives
    them), so rows miss the keys entirely — or carry nulls on a
    not-yet-migrated keyspace. The API requires non-null ints, filled via the
    legacy hop. Guarded on ``total_received`` so field-subset lookups do not
    trigger fills.
    """
    return "total_received" in row and (
        row.get("in_degree") is None or row.get("out_degree") is None
    )


class _AddressIdNotFound(Exception):
    """Internal sentinel raised on an address_id cache miss.

    ``@alru_cache`` does not cache calls that raise, so raising here keeps
    "address not found" out of the cache: an assigned ``address_id`` is
    immutable and safe to cache forever, but a currently-unknown address may
    be ingested later and must always be re-resolved.
    """


def account_calc_tx_fee(tx) -> Optional[int]:
    rgu = tx.get("receipt_gas_used", None)
    if rgu is None:
        return None
    # do we need to use effective gas price here?
    if (
        "receipt_effective_gas_price" in tx
        and tx["receipt_effective_gas_price"] is not None
    ):
        return rgu * tx["receipt_effective_gas_price"]
    else:
        return rgu * tx.get("gas_price", 0)


def try_partial_tron_to_partial_evm(addr_prefix):
    try:
        return partial_tron_to_partial_evm(addr_prefix)
    except ValueError:
        return ""


def create_upper_bound(s, is_string_not_hex=False):
    """Create upper bound for range query by incrementing last character"""
    if not s:
        return s

    if is_string_not_hex:
        chars = list(s)
        chars[-1] = chr(ord(chars[-1]) + 1)
        return "".join(chars)

    if all([x == "f" for x in strip_0x(s)]):
        return s + MAX_HEX_STRING_LENGTH * "f"
    else:
        has_0x = s != strip_0x(s)

        stripped_len_before = len(strip_0x(s))
        num = int(s, 16) + 1  # drops leading 0s
        hex_ = hex(num)[2:]  # drop 0x
        len_after = len(hex_)
        chars_to_pad = stripped_len_before - len_after
        padded = chars_to_pad * "0" + hex_
        if has_0x:
            return "0x" + padded
        else:
            return padded


def is_hexadecimal(s):
    """Check if a string is a valid hexadecimal number.

    ascii-strict on purpose: str.upper() applies full unicode case mapping
    (the ligature "ﬀ" U+FB00 expands to "FF"), which would accept strings
    that int(s, 16) / bytes.fromhex later reject.
    """
    s = strip_0x(s)
    return all(c in "0123456789abcdefABCDEF" for c in s)


def getDateFromKeyspaceName(x):
    datePart = x.split("_")[-1]
    try:
        return datetime.strptime(datePart, "%Y%m%d")
    except ValueError:
        return None


class NetworkParameters(UserDict):
    def __getitem__(self, network):
        if network not in self:
            raise NetworkNotFoundException(network)
        return super().__getitem__(network)


def to_hex(paging_state):
    return paging_state.hex() if paging_state else paging_state


def bytes_from_hex(h_str: str) -> bytes:
    return hex_to_bytes(h_str)


def tx_hash_from_hex(tx_hash_str: str) -> bytes:
    try:
        return bytes_from_hex(tx_hash_str)
    except ValueError:
        raise BadUserInputException(
            f"{tx_hash_str} does not look like a valid transaction hash."
        )


def page_from_hex(page):
    try:
        return bytes_from_hex(page)
    except ValueError:
        # bytes.fromHex throws value error if non hex chars are found
        raise BadUserInputException(
            f"The requested next page token ({page}) "
            "is not formatted correctly. "
            "Only use the next_page token found in the response."
        )


def transaction_ordering_key(tx_id_key, tx):
    ref = tx.get("tx_reference", [None, None])
    trace_index = ref[0] or 0
    log_index = ref[1] or 0
    return (tx[tx_id_key], -trace_index, -log_index)


def identity1(x):
    return x


def identity2(y, x):
    return x


def fmt(v):
    if isinstance(v, str):
        return "'" + v + "'"
    if isinstance(v, bytes):
        return "0x" + v.hex()
    return str(v)


def replaceFrom(keyspace, query):
    r = re.compile(r"\s+FROM\s+", re.IGNORECASE)
    return r.sub(f" FROM {keyspace}.", query)


def replacePerc(query, named=False):
    if not named:
        r = re.compile(r"%s", re.IGNORECASE)
        return r.sub("?", query)
    else:
        r = re.compile(r"%\((\S+?)\)s", re.IGNORECASE)
        return r.sub(r":\1", query)


def one(result):
    if result is not None:
        return result.one()
    return None


def check_height_bounds_impossible(
    min_height: Optional[int], max_height: Optional[int], last_height: int
) -> bool:
    """Check if the height bounds represent an impossible query range.

    Returns True if the query would never return results.
    """
    return (min_height is not None and min_height > last_height) or (
        max_height is not None and max_height < 0
    )


def build_token_tx(token_currency, tx, token_tx, log):
    token_from = token_tx["parameters"].get("from", "decoding error")
    token_to = token_tx["parameters"].get("to", "decoding error")
    value = token_tx["parameters"].get("value", "decoding error")
    return {
        "currency": token_currency,
        "block_id": tx["block_id"],
        "block_timestamp": tx["block_timestamp"],
        "tx_hash": tx["tx_hash"],
        "from_address": hex_str_to_bytes(strip_0x(token_from)),
        "to_address": hex_str_to_bytes(strip_0x(token_to)),
        "token_tx_id": log["log_index"],
        "value": value,
        "type": "erc20",
    }


class BytesPrettyPrinter(PrettyPrinter):
    def format(self, object, context, maxlevels, level):
        if isinstance(object, bytes):
            x = object.hex()
            return (x[0:24] + "...", True, False)
        return PrettyPrinter.format(self, object, context, maxlevels, level)


class Result:
    def __init__(self, current_rows, params, paging_state):
        self.current_rows = current_rows
        self.params = params
        self.paging_state = paging_state

    def __len__(self):
        return len(self.current_rows)

    def __getitem__(self, key):
        return self.current_rows[key]

    def is_empty(self):
        return self.current_rows is None or not self.current_rows

    def one(self):
        if self.is_empty():
            return None
        return self.current_rows[0]


TxSummary = namedtuple("TxSummary", ["height", "timestamp", "tx_hash"])


def get_tx_id_column_name(network: str) -> str:
    return "transaction_id" if is_eth_like(network) else "tx_id"


# helper functions
def wc(cl, cond):
    return f"AND {cl} " if cond else ""


# Cassandra stores tx counts and degrees as 32-bit `int`. Two writers fill
# those columns and they used to disagree once a value passed 2**31: the Spark
# full transform cast the true count (a Long) down with a plain cast, which
# TRUNCATES two's complement and lands NEGATIVE, while the delta updater caps
# at Int.MaxValue (`min(value, 2147483647)`, deltaupdate/update/account/
# createchanges.py). The TRON USDT contract has ~3.7e9 incoming txs and a
# freshly transformed keyspace served -591,097,850 for it.
#
# Spark now saturates too (TransformHelpers.saturateToInt), but keyspaces
# written by older jars still hold wrapped values, so reads normalize as well:
# the API must never emit a negative count, whatever is in the table.
INT32_MAX = 2**31 - 1


def saturate_int32_count(value: Optional[int]) -> Optional[int]:
    """Normalize a possibly-wrapped 32-bit counter to delta-updater semantics.

    A negative counter can only be a wrapped one — these columns are counts and
    are never legitimately below zero. Its true value is ``value + 2**32``,
    which is necessarily >= 2**31 and therefore saturates to ``INT32_MAX``,
    exactly what the delta updater would have written.

    Both the cap and the wrap under-report; the column really wants to be
    ``bigint``. Until that migration, a saturated value is at least
    non-negative and monotone.
    """
    if value is None:
        return None
    return INT32_MAX if value < 0 else value


def get_tx_identifier(row, currency, type_overwrite=None) -> str:
    # trace_tx = row.get("is_tx_trace", False)
    h = row["tx_hash"].hex()

    if type_overwrite == "internal" or row["type"] == "internal":  # and not trace_tx:
        t_type = SubTransactionType.InternalTx
        sub_tx = row["trace_index"]
    elif type_overwrite == "erc20" or row["type"] == "erc20":
        t_type = SubTransactionType.ERC20
        sub_tx = row["token_tx_id"]
    elif type_overwrite == "external" or row["type"] == "external":
        if currency == "eth" and row.get("trace_index", None) is not None:
            t_type = SubTransactionType.InternalTx
            sub_tx = row["trace_index"]
        else:
            t_type = SubTransactionType.ExternalTx
            sub_tx = None
    else:
        raise Exception(f"Unknown transaction type {row}")

    return SubTransactionIdentifier(
        tx_hash=h, tx_type=t_type, sub_index=sub_tx
    ).to_string()


def merge_address_txs_subquery_results(
    logger,
    result_sets: Sequence[Result],
    ascending: bool,
    fetch_size: Optional[int],
    tx_id_keys: str = "tx_id",
    fetched_limit: Optional[int] = None,
    page: Optional[int] = None,
    offset: int = 0,
) -> Tuple[Sequence[dict], Optional[int], Optional[int]]:
    """Merges sub results of the address txs queries per asset and direction

    Args:
        result_sets (Sequence[Result]): List of result sets,
            one per parameter tuple
        fetch_size (int): number of items return at most
        tx_id_keys (str): name of the tx_id column
        fetched_limit (int): The limit that was used to fetch the result sets

    Returns:
        Tuple[Sequence[dict], Optional[int, int]]: A merged list of ordered
            transactions, highest id and the number of rows with this same id
            included in this results set,
            the last two form the page id for subsequent queries.
    """
    # find the least common tx_id where we then cut the result sets.
    # We need this because we order by tx_id, but we make queries for specific
    # (direction, asset) combinations. Without this logic (wlog ascending case),
    # we could progress within one query to tx_id n while another result set is
    # limited and has not yet loaded all txs for tx_ids < n. In this case these rows
    # would be skipped if we simply took the next page's tx_id as the maximum of
    # the tx_ids of the combined result sets. We cap all the result sets
    # at the minimum over all the within-result-set maximums of the tx_ids.
    border_tx_id = None
    for results in result_sets:
        if not results:
            continue
        if fetched_limit and len(results) < fetched_limit:
            continue
        if border_tx_id is None:
            border_tx_id = results[-1][tx_id_keys]
            continue
        order = min if ascending else max
        border_tx_id = order(border_tx_id, results[-1][tx_id_keys])

    # cut result_sets so that we only have the overlapping rows below/above
    # the border_tx_id
    # filtered out rows could be overlapping with yet not retrieved result sets
    candidates = [
        v
        for results in result_sets
        for v in results
        if border_tx_id is None
        or ascending
        and v[tx_id_keys] <= border_tx_id
        or not ascending
        and v[tx_id_keys] >= border_tx_id
    ]

    # Merge overlapping result sets by given sort order
    results = sorted(
        candidates,
        reverse=not ascending,
        key=partial(transaction_ordering_key, tx_id_keys),
    )

    # pp = BytesPrettyPrinter()
    # logger.debug(f'results {pp.pformat(results)}')

    if results and offset:
        results = results[offset:]

    if fetch_size is not None:
        results = results[:fetch_size]

    def get_offset(results, border_tx_id, page, offset):
        if border_tx_id is None:
            return None
        same_key_offset = 0
        while (
            len(results) > same_key_offset
            and results[-same_key_offset - 1][tx_id_keys] == border_tx_id
        ):  # noqa
            same_key_offset += 1

        if page == border_tx_id:
            same_key_offset += offset

        return same_key_offset

    current_offset = offset
    current_page = page
    border_tx_ids_reversed = []
    same_key_offsets_reversed = []
    # simulate all scenarios so we can get all the pages and offsets
    for i in range(len(results)):
        border_tx_id = results[len(results) - i - 1][tx_id_keys]
        current_results = results[:-i] if i > 0 else results
        offset_to_use = current_offset if border_tx_id == current_page else 0

        same_key_offsets_reversed.append(
            get_offset(current_results, border_tx_id, current_page, offset_to_use)
        )
        current_offset = same_key_offsets_reversed[-1]
        current_page = border_tx_id
        border_tx_ids_reversed.append(border_tx_id)

    border_tx_ids = border_tx_ids_reversed[::-1]
    same_key_offsets = same_key_offsets_reversed[::-1]

    return results, border_tx_ids, same_key_offsets


def build_select_address_txs_statement(
    network: str,
    node_type: NodeType,
    cols: Optional[Sequence[str]],
    with_lower_bound: bool,
    with_upper_bound: bool,
    with_tx_id: bool,
    ascending: bool,
    limit: Optional[int],
    tx_id_in: bool = False,
) -> str:
    # prebuild useful helpers and conditions
    eth_like = is_eth_like(network)
    tx_id_col = get_tx_id_column_name(network)

    # Select and shared where clause
    # Build select statement
    columns = ",".join(cols) if cols is not None else "*"

    query = (
        f"SELECT {columns} from {node_type}_transactions "
        f"WHERE {node_type}_id = %(id)s "
        f"AND {node_type}_id_group = %(g_id)s "
        "AND is_outgoing = %(is_outgoing)s "
    )

    # conditional where clause, loop independent
    query += wc(f"{node_type}_id_secondary_group = %(s_d_group)s", eth_like)

    query += wc("currency = %(currency)s", eth_like)

    # ascending
    query += wc(
        f"{tx_id_col} >= %(tx_id_lower_bound)s",
        not with_tx_id and ascending and with_lower_bound,
    )
    query += wc(
        f"{tx_id_col} <= %(tx_id_upper_bound)s",
        not with_tx_id and ascending and with_upper_bound,
    )

    # descending
    query += wc(
        f"{tx_id_col} >= %(tx_id_lower_bound)s",
        not with_tx_id and not ascending and with_lower_bound,
    )
    query += wc(
        f"{tx_id_col} <= %(tx_id_upper_bound)s",
        not with_tx_id and not ascending and with_upper_bound,
    )

    query += wc(f"{tx_id_col} = %(tx_id)s", with_tx_id and not tx_id_in)
    # single-partition named-slice batch; the tx_reference clustering suffix
    # stays unrestricted so this needs no ALLOW FILTERING
    query += wc(f"{tx_id_col} IN %(tx_ids)s", with_tx_id and tx_id_in)

    ordering = "ASC" if ascending else "DESC"
    # Ordering statement
    ordering_statement = (
        "ORDER BY "
        + (f" currency {ordering}," if eth_like else "")
        + f" {tx_id_col} {ordering}"
    )

    limit = "" if limit is None else f"LIMIT {limit}"

    return f"{query} {ordering_statement} {limit}"


class Cassandra:
    def eth(func):
        def check(*args, **kwargs):
            self = args[0]
            currency = args[1]
            if is_eth_like(currency):
                # first look for currency specific
                # then fallback to eth.
                do = func.__name__ + "_" + currency
                if not hasattr(self, do):
                    do = func.__name__ + "_eth"
                if hasattr(self, do) and callable(getattr(self, do)):
                    f = getattr(self, do)
                    args = args[1:]
                    return f(*args, **kwargs)
            return func(*args, **kwargs)

        return check

    def new(func):
        def check(*args, **kwargs):
            self = args[0]
            currency = args[1]
            if is_eth_like(currency):
                do = func.__name__ + "_new"
                if hasattr(self, do) and callable(getattr(self, do)):
                    f = getattr(self, do)
                    args = args[1:]
                    return f(*args, **kwargs)
            return func(*args, **kwargs)

        return check

    def __init__(self, config: Union[Dict[str, Any], CassandraConfig], logger):
        self.logger = logger

        tconfig = None
        # Convert dict config to CassandraConfig if needed
        if isinstance(config, dict):
            try:
                tconfig = CassandraConfig(**config)
            except Exception as e:
                raise BadConfigError(f"Invalid configuration: {e}")
        elif isinstance(config, CassandraConfig):
            tconfig = config
        else:
            raise BadConfigError(
                "Config must be a dictionary or CassandraConfig instance"
            )

        # Convert back to dict for backward compatibility with existing code
        config = tconfig.model_dump()

        if "currencies" not in config or config["currencies"] is None:
            raise BadConfigError("Missing config property: currencies")
        if "nodes" not in config or config["nodes"] is None:
            raise BadConfigError("Missing config property: nodes")
        self.config = config
        self.tconfig = tconfig
        self.prepared_statements = {}
        self.connect()
        self.parameters = NetworkParameters()
        self.get_cross_chain_pubkey_related_addresses_available = False
        self.cross_chain_pubkey_keyspaces: List[str] = []

        for currency in config["currencies"]:
            if config["currencies"][currency] is None:
                config["currencies"][currency] = {}

            # automatically find latest active keyspace if not configured
            if (
                "raw" not in config["currencies"][currency]
                or config["currencies"][currency]["raw"] is None
            ):
                config["currencies"][currency]["raw"] = self.find_latest_raw_keyspace(
                    currency
                )

            if (
                "transformed" not in config["currencies"][currency]
                or config["currencies"][currency]["transformed"] is None
            ):
                config["currencies"][currency]["transformed"] = (
                    self.find_latest_transformed_keyspace(currency)
                )

            self.check_keyspace(config["currencies"][currency]["raw"])
            self.check_keyspace(config["currencies"][currency]["transformed"])
            self.load_parameters(currency)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()

    def _build_session(self):
        """Create the Cluster + session. Raises NoHostAvailable if no host is up."""
        # LOCAL_ONE is the recommended default for the read path: it tolerates
        # any (RF - 1) replicas being down. LOCAL_QUORUM only adds value when
        # RF >= 3 and read-after-write consistency is actually required.
        cl = ConsistencyLevel.name_to_value.get(
            self.config.get("consistency_level", "LOCAL_ONE"),
            ConsistencyLevel.LOCAL_ONE,
        )
        retry_policy_cls = (
            GraphsenseFallbackToLocalOneRetryPolicy
            if self.config.get("consistency_level_fallback", False)
            else GraphsenseRetryPolicy
        )

        exec_prof = ExecutionProfile(
            request_timeout=60,
            row_factory=dict_factory,
            load_balancing_policy=TokenAwarePolicy(DCAwareRoundRobinPolicy()),
            consistency_level=cl,
            retry_policy=retry_policy_cls(max_retries=3),
            # For idempotent reads (all REST queries are SELECTs), fire a second
            # attempt at another host after 200 ms to mask slow/dead replicas.
            speculative_execution_policy=ConstantSpeculativeExecutionPolicy(
                delay=0.2, max_attempts=2
            ),
        )

        auth_provider = None
        if "username" in self.config and self.config["username"] is not None:
            auth_provider = PlainTextAuthProvider(
                username=self.config["username"],
                password=self.config.get("password", ""),
            )

        self.cluster = Cluster(
            self.config["nodes"],
            port=int(self.config.get("port", 9042)),
            # Pin v4, for the same reason as the synchronous driver: v5's
            # checksummed segment framing desyncs under load and reads a segment
            # header at the wrong offset (CASSANDRA-19971 / PYTHON-1337, still
            # open), surfacing as "CRC mismatch on header" and defuncting the
            # connection — which fails every in-flight request on it. Framing is
            # v5-only. Queries here carry their keyspace in the CQL itself (see
            # replaceFrom), so the v5-only statement-level keyspace flag is not
            # relied on. See db/cassandra.py:connect for the full rationale.
            protocol_version=4,
            connect_timeout=15,
            execution_profiles={EXEC_PROFILE_DEFAULT: exec_prof},
            auth_provider=auth_provider,
            reconnection_policy=ExponentialReconnectionPolicy(1.0, 60.0),
        )
        self.session = self.cluster.connect()
        if self.logger:
            self.logger.info(f"Connection ready. Using CL: {cl}")

    def connect(self):
        """(Re)establish the Cassandra cluster/session with a bounded, non-recursive
        retry.

        Safe to call at startup — the blocking retry waits for a slow-starting
        Cassandra. It must NOT be relied on to reconnect from the async serving
        path: the driver's ``ExponentialReconnectionPolicy`` re-adds downed hosts
        on its own, so the read paths let a transient ``NoHostAvailable`` propagate
        instead of re-creating the cluster on the event loop (the old code did the
        latter via ``time.sleep`` + unbounded recursion, freezing every in-flight
        REST request during an outage).
        """
        retry = self.config.get("retry_interval", None)
        retry = 5 if retry is None else retry
        max_attempts = int(self.config.get("connect_max_attempts", 60))
        last_exc = None
        for attempt in range(1, max_attempts + 1):
            try:
                self._build_session()
                return
            except NoHostAvailable as e:
                last_exc = e
                if self.logger:
                    self.logger.warning(
                        f"Could not connect (attempt {attempt}/{max_attempts}); "
                        f"retrying in {retry} secs."
                    )
                if attempt < max_attempts:
                    time.sleep(retry)
        raise last_exc

    def check_keyspace(self, keyspace):
        query = "SELECT * FROM system_schema.keyspaces where keyspace_name = %s"
        result = self.session.execute(query, [keyspace])
        if one(result) is None:
            raise BadConfigError("Keyspace {} does not exist".format(keyspace))

        if self.logger:
            self.logger.info(f"Using keyspace: {keyspace}")

    def _has_table(self, keyspace, table):
        result = self.session.execute(
            "SELECT table_name FROM system_schema.tables "
            "WHERE keyspace_name = %s AND table_name = %s",
            [keyspace, table],
        )
        return one(result) is not None

    def _is_ingest_complete(self, keyspace, fallback_table):
        # Back-compat fallback (existence-of-any-row in `fallback_table`) covers
        # keyspaces that pre-date the state table; drop once all production
        # keyspaces have been re-ingested at least once.
        if self._has_table(keyspace, STATE_TABLE):
            row = self.session.execute(
                f"SELECT key FROM {keyspace}.{STATE_TABLE} WHERE key = %s",
                [INGEST_COMPLETE_KEY],
            )
            return one(row) is not None

        row = self.session.execute(f"SELECT * FROM {keyspace}.{fallback_table} limit 1")
        return one(row) is not None

    def _dated_keyspaces(self, prefix):
        # Return [(keyspace_name, date), ...] for keyspaces starting with
        # `prefix` and ending in a parseable _YYYYMMDD suffix, sorted
        # newest-date-first.
        result = self.session.execute(
            "SELECT keyspace_name FROM system_schema.keyspaces"
        )
        dated = [
            (x["keyspace_name"], getDateFromKeyspaceName(x["keyspace_name"]))
            for x in result
            if x["keyspace_name"].startswith(prefix)
            and getDateFromKeyspaceName(x["keyspace_name"]) is not None
        ]
        return sorted(dated, key=lambda kd: kd[1], reverse=True)

    def find_latest_transformed_keyspace(self, network):
        # Transformed keyspaces are produced by the transformation pipeline,
        # not ingested — nothing writes the `state.ingest_complete` marker on
        # this side. Treat a populated `summary_statistics` table as the
        # readiness signal instead.
        prefix = f"{network.lower()}_transformed"
        res = []
        for ks, _ in self._dated_keyspaces(prefix):
            stats = self.session.execute(
                f"SELECT no_blocks FROM {ks}.summary_statistics limit 1"
            )
            stats_row = one(stats)
            if stats_row is None:
                if self.logger:
                    self.logger.warning(f"{ks} has empty summary_statistics. skipping")
                continue
            no_blocks = stats_row["no_blocks"] or 0
            res.append((ks, no_blocks))

        res = sorted(res, key=lambda item: item[1], reverse=True)

        if len(res) > 0:
            return res[0][0]
        else:
            raise Exception(
                f"Automatic detection for transformed keyspace failed for network {network}."
            )

    def find_latest_raw_keyspace(self, network):
        prefix = f"{network.lower()}_raw"
        for ks, _ in self._dated_keyspaces(prefix):
            if self._is_ingest_complete(ks, "configuration"):
                return ks
            if self.logger:
                self.logger.warning(f"{ks} is not marked ingest_complete. skipping")

        if self.logger:
            self.logger.info(
                f"No dated raw keyspace found for {network}; falling back to {prefix}"
            )
        return prefix

    @eth
    def load_token_configuration(self, currency):
        return None

    def load_token_configuration_eth(self, currency):
        query = "SELECT * FROM token_configuration"
        return {
            row["currency_ticker"]: row
            for row in self.execute(currency, "transformed", query)
        }

    async def fix_timestamp(
        self, currency, item, timestamp_col="block_timestamp", block_id_col="block_id"
    ):
        if currency == "trx" and item[timestamp_col] < 500000000:
            # TODO block timestamp in tx is currently
            # wrong / we divide by 1000 to get from
            # mili to seconds. But it appears to be
            # wrong in the txs.
            block = await self.get_block_timestamp(currency, item[block_id_col])
            if block is not None:
                item[timestamp_col] = block["timestamp"]
            else:
                self.logger.warning(
                    f"Could not load block {item[block_id_col]}, to fix timestamp."
                )

    def load_parameters(self, keyspace):
        currency = keyspace
        self.parameters[keyspace] = {}
        for kind in ["raw", "transformed"]:
            query = "SELECT * FROM configuration"
            result = self.execute(keyspace, kind, query)
            if one(result) is None:
                raise BadConfigError(
                    f"No configuration table found for {kind} keyspace {{}}".format(
                        keyspace
                    )
                )
            for key, value in result.one().items():
                self.parameters[keyspace][key] = value

        self.parameters[keyspace]["token_config"] = self.load_token_configuration(
            keyspace
        )

        # check schema for compatibility and set parameter flags
        keyspace_name = self.get_keyspace_mapping(keyspace, "transformed")

        if keyspace == "eth":
            query = (
                "SELECT column_name FROM system_schema.columns "
                "WHERE keyspace_name = %s AND "
                "table_name = 'block_transactions';"
            )
            result = self.session.execute(query, (keyspace_name,))
            self.parameters[currency]["use_flat_block_txs"] = (
                "tx_id" in [x["column_name"] for x in result]
            ) and keyspace == "eth"
        else:
            self.parameters[currency]["use_flat_block_txs"] = False

        query = (
            "SELECT column_name FROM system_schema.columns "
            "WHERE keyspace_name = %s AND table_name = 'address_transactions';"
        )
        result = self.session.execute(query, (keyspace_name,))
        self.parameters[currency]["use_legacy_log_index"] = (
            "log_index" in [x["column_name"] for x in result]
        ) and keyspace == "eth"

        query = "SELECT table_name FROM system_schema.tables WHERE keyspace_name = %s ;"
        result = self.session.execute(query, (keyspace_name,))
        self.parameters[currency]["use_delta_updater_v1"] = "new_addresses" in [
            x["table_name"] for x in result
        ]

        keyspace_name = self.get_keyspace_mapping(keyspace, "raw")
        result = self.session.execute(query, (keyspace_name,))

        self.parameters[currency]["tx_graph_available"] = "transaction_spending" in [
            x["table_name"] for x in result
        ]

        # Keep only the configured pubkey keyspace(s) that actually hold a
        # 'pubkey_by_address' table, so a missing/typo'd keyspace is skipped
        # rather than failing every lookup. The reader merges across all of them.
        self.cross_chain_pubkey_keyspaces = []
        query = "SELECT table_name FROM system_schema.tables WHERE keyspace_name = %s ;"
        for pubkeyks in self.tconfig.get_cross_chain_pubkey_keyspaces():
            result = self.session.execute(query, (pubkeyks,))
            tblnames = [x["table_name"] for x in result]
            if "pubkey_by_address" in tblnames:
                self.cross_chain_pubkey_keyspaces.append(pubkeyks)
        self.get_cross_chain_pubkey_related_addresses_available = (
            len(self.cross_chain_pubkey_keyspaces) > 0
        )

        # Log the resolved set once (this block runs per currency) so it is
        # visible on a running service which pubkey keyspaces are actually used.
        if self.logger and not getattr(self, "_cross_chain_pubkey_logged", False):
            if self.cross_chain_pubkey_keyspaces:
                self.logger.info(
                    "cross-chain pubkey lookup active on keyspaces: %s",
                    self.cross_chain_pubkey_keyspaces,
                )
            else:
                self.logger.info(
                    "cross-chain pubkey lookup disabled (no configured keyspace "
                    "has a pubkey_by_address table; configured: %s)",
                    self.tconfig.get_cross_chain_pubkey_keyspaces() or None,
                )
            self._cross_chain_pubkey_logged = True

    def get_prefix_lengths(self, currency):
        if currency not in self.parameters:
            raise NetworkNotFoundException(currency)
        p = self.parameters[currency]
        return {"address": p["address_prefix_length"], "tx": p["tx_prefix_length"]}

    def get_supported_currencies(self):
        return self.config["currencies"].keys()

    def get_token_configuration(self, currency):
        eth_config = self.parameters.get(currency, None)
        return eth_config["token_config"] if eth_config is not None else {}

    def get_balance_provider(self, currency):
        provider = self.config["currencies"][currency].get("balance_provider", None)
        if provider is not None and provider == "node":
            from graphsenselib.utils.node_balances import get_balances

            return partial(get_balances, provider)
        else:
            return None

    def get_keyspace_mapping(self, currency, keyspace_type):
        if currency is None:
            raise BadUserInputException("Missing currency")
        if keyspace_type not in ("raw", "transformed"):
            raise BadUserInputException(f"Unknown keyspace type {keyspace_type}")
        if currency not in self.config["currencies"]:
            raise BadUserInputException(f"Unknown currency in config: {currency}")
        return self.config["currencies"][currency][keyspace_type]

    def close(self):
        self.cluster.shutdown()

    def execute(
        self,
        currency,
        keyspace_type,
        query,
        params=None,
        paging_state=None,
        fetch_size=None,
    ):
        keyspace = self.get_keyspace_mapping(currency, keyspace_type)
        q = replaceFrom(keyspace, query)
        # self.logger.debug(f'{query} {params}')
        q = SimpleStatement(q, fetch_size=fetch_size)

        # On NoHostAvailable let the error propagate: the driver's reconnection
        # policy re-adds downed hosts on its own. The old behavior re-created the
        # cluster (self.connect()) and recursed without bound.
        result = self.session.execute(q, params, paging_state=paging_state)
        return result

    async def execute_async(
        self,
        currency,
        keyspace_type,
        query,
        params=[],
        paging_state=None,
        fetch_size=None,
        autopaging=False,
    ):
        try:
            result = await self.execute_async_lowlevel(
                currency,
                keyspace_type,
                query,
                params=params,
                paging_state=paging_state,
                fetch_size=fetch_size,
            )
        except ProtocolException as e:
            if "Invalid value for the paging state" not in str(e):
                raise e
            raise BadUserInputException(
                "Invalid value for page. Please use handle from previous requests."
            )
        if not autopaging:
            return result

        if result.paging_state is None:
            return result

        more = await self.execute_async(
            currency,
            keyspace_type,
            query,
            params=params,
            paging_state=result.paging_state,
            fetch_size=fetch_size,
            autopaging=True,
        )

        for row in more.current_rows:
            result.current_rows.append(row)
        return result

    def get_prepared_statement(self, query):
        # Guard: this helper marks every prepared statement as idempotent (a
        # prerequisite for the speculative-execution policy). Lightweight
        # transactions and UPDATEs are not safe to mark idempotent — retried or
        # speculatively-executed copies can double-apply or race — so refuse to
        # prepare them here. Mutating paths must use a dedicated helper that
        # decides idempotency per statement.
        normalized = " ".join(query.split())
        if re.search(r"\bIF\s+(NOT\s+)?EXISTS\b", normalized, re.IGNORECASE):
            raise ValueError(
                "get_prepared_statement refuses LWT (IF [NOT] EXISTS): "
                f"not idempotent. Query: {query!r}"
            )
        if re.match(r"\s*UPDATE\b", normalized, re.IGNORECASE):
            raise ValueError(
                "get_prepared_statement refuses UPDATE: not idempotent. "
                f"Query: {query!r}"
            )

        hash_object = hashlib.sha256(query.encode("utf-8"))
        hex_dig = hash_object.hexdigest()
        if hex_dig not in self.prepared_statements:
            ps = self.session.prepare(query)
            # All REST queries are SELECTs and therefore idempotent. Required for
            # the speculative-execution policy on the ExecutionProfile to fire.
            ps.is_idempotent = True
            self.prepared_statements[hex_dig] = ps
        return self.prepared_statements[hex_dig]

    def execute_async_core(
        self,
        query: str,
        params: Dict[str, Any] = None,
        paging_state=None,
        fetch_size: Optional[int] = None,
        success_callback: Optional[Callable[Result, None]] = None,
    ):
        prep = self.get_prepared_statement(query)

        prep.fetch_size = int(fetch_size) if fetch_size else None
        # self.session.default_timeout = 60

        response_future = self.session.execute_async(
            prep, params, timeout=60, paging_state=paging_state
        )
        loop = asyncio.get_running_loop()
        future = loop.create_future()

        def on_done(result):
            if future.cancelled():
                # Cheap best-effort early-out on the driver thread; the
                # authoritative guard runs on the loop thread below.
                return
            result = Result(
                current_rows=result,
                params=params,
                paging_state=response_future._paging_state,
            )
            if success_callback is not None:
                success_callback(result)

            # Delivery runs on the event loop thread, where cancellation also
            # runs, so the done-check and the set cannot race across threads.
            # A client disconnect may have cancelled the future between this
            # driver callback and delivery; skip silently if so.
            def deliver_result():
                if not future.done():
                    future.set_result(result)

            loop.call_soon_threadsafe(deliver_result)

        def on_err(exc):
            def deliver_exception():
                if not future.done():
                    future.set_exception(exc)

            loop.call_soon_threadsafe(deliver_exception)

        response_future.add_callbacks(on_done, on_err)
        return future

    def execute_async_lowlevel(
        self,
        currency,
        keyspace_type,
        query,
        params=[],
        paging_state=None,
        fetch_size=None,
    ):
        named_params = isinstance(params, dict)
        keyspace = self.get_keyspace_mapping(currency, keyspace_type)
        query = replaceFrom(keyspace, query)
        q = replacePerc(query, named=named_params)

        def callback(result):
            if self.logger.level == logging.DEBUG:
                if named_params:
                    formatted = query
                    for k, v in params.items():
                        formatted = formatted.replace("%(" + k + ")s", fmt(v))
                else:
                    formatted = query % tuple([fmt(v) for v in params])
                if len(result.current_rows) > 0:
                    self.logger.debug(formatted)
                    # pp = BytesPrettyPrinter()
                    # self.logger.debug(pp.pformat(result.current_rows))
                    self.logger.debug(f"result size {len(result.current_rows)}")

        # On NoHostAvailable let the error propagate. Reconnecting here re-created
        # the cluster on the event-loop thread (blocking time.sleep in connect())
        # and recursed without bound, freezing every in-flight REST request during
        # an outage. The driver's ExponentialReconnectionPolicy recovers hosts.
        return self.execute_async_core(
            q,
            params=params,
            fetch_size=fetch_size,
            paging_state=paging_state,
            success_callback=callback,
        )

    async def concurrent_with_args(
        self,
        currency,
        keyspace_type,
        query,
        params,
        filter_empty=True,
        return_one=True,
        keep_meta=False,
    ):
        aws = [
            self.execute_async(currency, keyspace_type, query, param, autopaging=True)
            for param in params
        ]
        results = []
        for result in await asyncio.gather(*aws):
            if filter_empty and result is None:
                continue
            if return_one:
                o = one(result)
                if not keep_meta:
                    result = o
                else:
                    result.current_rows = [o]
                if o:
                    results.append(result)
                else:
                    if not filter_empty:
                        results.append(result)
                continue
            if not keep_meta:
                results.extend(result.current_rows)
            else:
                results.append(result)
        return results

    @alru_cache(ttl=5)
    async def get_currency_statistics(self, currency):
        query = "SELECT * FROM summary_statistics LIMIT 1"
        result = await self.execute_async(currency, "transformed", query)
        stats = one(result)
        if self.parameters[currency]["use_delta_updater_v1"]:
            try:
                query = "SELECT * FROM delta_updater_status LIMIT 1"
                result = await self.execute_async(currency, "transformed", query)
                result = one(result)
                if result:
                    stats["no_blocks"] = result["last_synced_block"] + 1
                    stats["timestamp"] = (
                        int(result["last_synced_block_timestamp"].timestamp())
                        if "last_synced_block_timestamp" in result
                        else stats["timestamp"]
                    )

            except InvalidRequest as e:
                if "delta_updater_status" not in str(e):
                    raise e

        if is_eth_like(currency):
            stats["no_clusters"] = 0

        return stats

    @eth
    async def get_block(self, currency, height):
        query = "SELECT * FROM block WHERE block_id_group = %s AND block_id = %s"
        return (
            await self.execute_async(
                currency,
                "raw",
                query,
                [self.get_block_id_group(currency, height), height],
            )
        ).one()

    @alru_cache(maxsize=10000)
    async def get_block_timestamp(self, currency, height):
        query = (
            "SELECT timestamp FROM block WHERE block_id_group = %s AND block_id = %s"
        )
        return (
            await self.execute_async(
                currency,
                "raw",
                query,
                [self.get_block_id_group(currency, height), height],
            )
        ).one()

    async def get_block_by_date_allow_filtering(self, currency, timestamp: int) -> int:
        query = "SELECT min(block_id) as block_id, timestamp FROM block WHERE timestamp >= %s allow filtering"
        return (
            await self.execute_async(
                currency,
                "raw",
                query,
                [timestamp],
            )
        ).one()

    async def get_block_below_block_allow_filtering(
        self, currency, block_id: int
    ) -> int:
        query = "SELECT max(block_id) as block_id, timestamp FROM block WHERE block_id < %s allow filtering"
        return (
            await self.execute_async(
                currency,
                "raw",
                query,
                [block_id],
            )
        ).one()

    async def list_block_txs(self, currency, height):
        tx_ids = await self.list_block_txs_ids(currency, height)
        if tx_ids is None:
            raise BlockNotFoundException(currency, height)
        tx_ids = sorted(list(set(tx_ids)))
        return await self.list_txs_by_ids(currency, tx_ids, include_token_txs=True)

    @alru_cache(maxsize=1000)
    async def get_rates(self, currency, height):
        query = "SELECT * FROM exchange_rates WHERE block_id = %s"
        result = await self.execute_async(currency, "transformed", query, [height])
        result = one(result)
        if result is None:
            return None
        return self.markup_rates(currency, result)

    async def get_token_rate(self, currency, token, block_id):
        """Per-block fiat rate for an unpegged token at or before `block_id`.

        Returns a labeled rates list ([{code, value}, ...]) or None when no
        rate exists (caller falls back to zero fiat). See the token_exchange_rates
        table populated by the delta-update from fetched per-token prices.
        """
        query = (
            "SELECT fiat_values FROM token_exchange_rates "
            "WHERE asset = %s AND block_id <= %s LIMIT 1"
        )
        result = one(
            await self.execute_async(
                currency, "transformed", query, [token.upper(), block_id]
            )
        )
        if result is None:
            return None
        return self.markup_values(currency, result["fiat_values"])

    async def get_latest_token_rate(self, currency, token):
        """Most recent per-block fiat rate for an unpegged token (for balances)."""
        query = "SELECT fiat_values FROM token_exchange_rates WHERE asset = %s LIMIT 1"
        result = one(
            await self.execute_async(currency, "transformed", query, [token.upper()])
        )
        if result is None:
            return None
        return self.markup_values(currency, result["fiat_values"])

    # async def list_rates(self, currency, heights):
    #     result = await self.concurrent_with_args(
    #         currency, 'transformed',
    #         "SELECT * FROM exchange_rates WHERE block_id = %s",
    #         [[h] for h in heights])
    #     for row in result:
    #         self.markup_rates(currency, row)
    #     return result

    async def list_rates(self, currency, heights):
        aws = [self.get_rates(currency, h) for h in heights]
        return await asyncio.gather(*aws)

    async def list_address_txs(
        self,
        currency,
        address,
        direction,
        min_height=None,
        max_height=None,
        order=None,
        token_currency=None,
        page=None,
        pagesize=None,
    ):
        return await self.list_txs_by_node_type(
            currency,
            NodeType.ADDRESS,
            address,
            direction,
            min_height=min_height,
            max_height=max_height,
            order=order,
            token_currency=token_currency,
            page=page,
            pagesize=pagesize,
        )

    async def list_entity_txs(
        self,
        currency,
        entity,
        direction,
        min_height=None,
        max_height=None,
        order=None,
        token_currency=None,
        page=None,
        pagesize=None,
    ):
        if not is_representable_entity_id(int(entity)):
            return [], None
        return await self.list_txs_by_node_type(
            currency,
            NodeType.CLUSTER,
            entity,
            direction,
            min_height=min_height,
            max_height=max_height,
            order=order,
            token_currency=token_currency,
            page=page,
            pagesize=pagesize,
        )

    def _verify_address_in_tx_btc(
        self,
        currency: str,
        address: str,
        tx: dict,
        is_outgoing: Optional[bool],
    ) -> None:
        """Verify that the queried address actually appears in the resolved
        tx's inputs/outputs as the address_transactions secondary index claims.
        Guards against index misalignments where a tx_id resolves to a tx
        that does not actually involve the queried address.

        Direction-aware: is_outgoing=True checks inputs, False checks outputs,
        None checks either. No-op when strict_data_validation is disabled.
        """
        if not self.tconfig.strict_data_validation:
            return

        def addresses_in_ios(ios):
            if ios is None:
                return []
            return sum([x.address or [] for x in ios], [])

        if is_outgoing is True:
            side = "inputs"
            candidates = addresses_in_ios(tx.get("inputs"))
        elif is_outgoing is False:
            side = "outputs"
            candidates = addresses_in_ios(tx.get("outputs"))
        else:
            side = "inputs/outputs"
            candidates = addresses_in_ios(tx.get("inputs")) + addresses_in_ios(
                tx.get("outputs")
            )

        if address in candidates:
            return

        # coinbase txs have inputs=None; the only legitimate way to receive
        # from one is via outputs (incoming).
        if (
            is_outgoing is False
            and tx.get("inputs") is None
            and tx.get("coinbase") is True
        ):
            return

        tx_hash = tx.get("tx_hash")
        tx_hash_hex = (
            tx_hash.hex() if isinstance(tx_hash, (bytes, bytearray)) else str(tx_hash)
        )
        raise DBInconsistencyException(
            f"Index misalignment in {currency}: queried address {address} "
            f"not found in {side} of tx {tx_hash_hex}. "
            f"Possible address_transactions secondary index corruption."
        )

    def _verify_address_in_tx_eth(
        self,
        currency: str,
        queried_address,
        row: dict,
    ) -> None:
        """Verify that the queried address actually appears as the expected
        side (from_address when is_outgoing else to_address) of an eth-like
        normalized address-transaction row. Guards against index misalignments
        where a tx_id resolves to a transfer that does not involve the
        queried address. No-op when strict_data_validation is disabled.
        """
        if not self.tconfig.strict_data_validation:
            return

        def to_bytes(addr):
            if addr is None:
                return None
            if isinstance(addr, (bytes, bytearray)):
                return bytes(addr)
            if isinstance(addr, str):
                return hex_str_to_bytes(strip_0x(addr))
            return None

        queried = to_bytes(queried_address)
        if row.get("is_outgoing"):
            side = "from_address"
            candidate = to_bytes(row.get("from_address"))
        else:
            side = "to_address"
            candidate = to_bytes(row.get("to_address"))

        if queried is not None and candidate == queried:
            return

        tx_hash = row.get("tx_hash")
        tx_hash_hex = (
            tx_hash.hex() if isinstance(tx_hash, (bytes, bytearray)) else str(tx_hash)
        )
        queried_repr = bytes_to_hex(queried) if queried is not None else queried_address
        candidate_repr = bytes_to_hex(candidate) if candidate is not None else candidate
        raise DBInconsistencyException(
            f"Index misalignment in {currency}: queried address "
            f"{queried_repr} does not match {side}={candidate_repr} of tx "
            f"{tx_hash_hex}. "
            f"Possible address_transactions secondary index corruption."
        )

    @eth
    async def list_txs_by_node_type(
        self,
        currency,
        node_type: NodeType,
        id,
        direction,
        min_height=None,
        max_height=None,
        order=None,
        token_currency=None,
        page=None,
        pagesize=None,
    ):
        ascending = order == "asc"

        self.logger.debug(f"min_height {min_height}")
        self.logger.debug(f"max_height {max_height}")
        first_tx_id, upper_bound = await self.resolve_tx_id_range_by_block(
            currency, min_height, max_height
        )
        self.logger.debug(f"first_tx_id {first_tx_id}")
        self.logger.debug(f"upper_bound {upper_bound}")

        fetch_size = min(pagesize or BIG_PAGE_SIZE, BIG_PAGE_SIZE)
        include_assets = [currency.upper()]

        results, paging_states, finished = await self.list_address_txs_ordered(
            network=currency,
            node_type=node_type,
            id=id,
            tx_id_lower_bound=first_tx_id,
            tx_id_upper_bound=upper_bound,
            is_outgoing=(direction == "out" if direction is not None else None),
            include_assets=include_assets,
            ascending=ascending,
            page=page,
            fetch_size=fetch_size,
        )
        paging_state = paging_states[-1] if paging_states and not finished else None

        tx_ids = [row["tx_id"] for row in results]
        if self.tconfig.strict_data_validation:
            # _verify_address_in_tx_btc needs inputs/outputs, so keep the full read.
            txs = await self.list_txs_by_ids(currency, tx_ids, filter_empty=False)
        else:
            summaries = await self._get_tx_summaries_by_ids(
                currency,
                tx_ids,
                columns="tx_id, tx_hash, block_id, timestamp, coinbase",
            )
            txs = [summaries.get(tx_id) for tx_id in tx_ids]

        rows = []
        for row, tx in zip(results, txs):
            if tx is None:
                continue
            if node_type == NodeType.ADDRESS:
                self._verify_address_in_tx_btc(currency, id, tx, row.get("is_outgoing"))
            row["tx_hash"] = tx["tx_hash"]
            row["height"] = tx["block_id"]
            row["timestamp"] = tx["timestamp"]
            row["coinbase"] = tx["coinbase"]
            rows.append(row)

        return rows, str(paging_state) if paging_state is not None else None

    @eth
    async def get_next_block_with_transactions(
        self, network: str, find_max_block: bool, height: int, highest_block: int
    ):
        # BTC and similar have txs in every block, since there is at least the coinbase
        # so no search needed.
        return height

    async def get_next_block_with_transactions_eth(
        self, network: str, find_max_block: bool, height: int, highest_block: int
    ) -> Optional[int]:
        height_group = self.get_block_id_group(network, height)
        max_group = self.get_block_id_group(network, highest_block)
        min_group = 0
        if find_max_block:
            query = (
                "SELECT max(block_id) as block FROM block "
                "WHERE block_id_group=%s and transaction_count > 0 and block_id <= %s allow filtering "
            )
        else:
            query = (
                "SELECT min(block_id) as block FROM block "
                "WHERE block_id_group=%s and transaction_count > 0 and block_id >= %s allow filtering "
            )
        result_block = None
        while (
            result_block is None
            and height_group >= min_group
            and height_group <= max_group
        ):
            result = await self.execute_async(
                network, "raw", query, [height_group, int(height)]
            )
            row = one(result)
            if row is not None:
                result_block = row["block"]

            height_group = height_group + (-1 if find_max_block else +1)

        return result_block

    async def resolve_tx_id_range_by_block(
        self, network: str, min_height: Optional[int], max_height: Optional[int]
    ) -> Tuple[Optional[int], Optional[int]]:
        stats = await self.get_currency_statistics(network)
        if not stats:
            return None, None
        last_height = stats["no_blocks"] - 1

        # Check for impossible height constraints that should yield empty results
        if check_height_bounds_impossible(min_height, max_height, last_height):
            return 0, -1

        first_tx_id = last_tx_id = None
        if min_height is not None:
            min_block_with_txs = await self.get_next_block_with_transactions(
                network, False, min_height, last_height
            )

            former_txs = (
                await self.list_block_txs_ids(network, min_block_with_txs)
                if min_block_with_txs is not None
                else None
            )
            first_tx_id = min(former_txs) if former_txs else None
        if max_height is not None:
            max_block_with_txs = await self.get_next_block_with_transactions(
                network, True, max_height, last_height
            )
            latter_txs = (
                await self.list_block_txs_ids(network, max_block_with_txs)
                if max_block_with_txs is not None
                else None
            )
            last_tx_id = max(latter_txs) if latter_txs else None

        return first_tx_id, last_tx_id

    @eth
    async def list_block_txs_ids(self, currency, height):
        height_group = self.get_block_id_group(currency, height)
        query = (
            "SELECT txs FROM block_transactions WHERE block_id_group=%s and block_id=%s"
        )
        result = await self.execute_async(
            currency, "raw", query, [height_group, int(height)]
        )

        if one(result) is None:
            return None
        return [tx.tx_id for tx in result.one()["txs"]]

    async def list_block_txs_ids_eth(self, currency, height):
        if not self.parameters[currency]["use_flat_block_txs"]:
            if height is None:
                return None
            height_group = self.get_id_group(currency, height)
            query = (
                "SELECT txs FROM block_transactions "
                "WHERE block_id_group=%s and block_id=%s"
            )
            result = await self.execute_async(
                currency, "transformed", query, [height_group, int(height)]
            )
            if one(result) is None:
                return None
            return result.one()["txs"]
        else:
            return await self.list_block_txs_ids_trx(currency, height)

    async def list_block_txs_ids_trx(self, currency, height):
        if height is None:
            return None
        height_group = self.get_id_group(currency, height)
        query = (
            "SELECT tx_id FROM block_transactions "
            "WHERE block_id_group=%s and block_id=%s"
        )
        result = await self.execute_async(
            currency, "transformed", query, [height_group, int(height)], autopaging=True
        )
        res = [r["tx_id"] for r in result.current_rows]
        return res

    async def get_addresses_by_ids(self, currency, address_ids, address_only=False):
        params = [
            (self.get_id_group(currency, address_id), address_id)
            for address_id in address_ids
        ]
        fields = "address, address_id, address_id_group" if address_only else "*"
        query = (
            f"SELECT {fields} FROM address WHERE "
            "address_id_group = %s and address_id = %s"
        )
        result = await self.concurrent_with_args(currency, "transformed", query, params)

        return result

    async def get_new_address(self, currency, address):
        if not self.parameters[currency]["use_delta_updater_v1"]:
            return None
        prefix = self.scrub_prefix(currency, address)
        if is_eth_like(currency):
            prefix = prefix.upper()
        prefix_length = self.get_prefix_lengths(currency)["address"]
        query = "SELECT * FROM new_addresses WHERE address_prefix = %s AND address = %s"
        try:
            result = await self.execute_async(
                currency, "transformed", query, [prefix[:prefix_length], address]
            )
            return one(result)
        except InvalidRequest as e:
            if "new_addresses" not in str(e):
                raise e

        return None

    async def get_address_id(self, currency, address):
        # An empty address (e.g. an invalid trx address canonicalized with
        # validate=False yields b"") cannot exist; short-circuit before it
        # reaches Cassandra, which rejects an empty partition key.
        if not address:
            return None
        try:
            # Cache hits only: address_ids are immutable once assigned, but a
            # miss must never be cached (see _AddressIdNotFound). This resolver
            # backs get_address, get_address_entity_id, list_address_txs_ordered
            # and the links path, so the same address is otherwise re-resolved
            # several times per request (and across requests for hot addresses).
            return await self._get_address_id_cached(currency, address)
        except _AddressIdNotFound:
            return None

    @alru_cache(maxsize=100_000)
    async def _get_address_id_cached(self, currency, address):
        prefix = self.scrub_prefix(currency, address)
        if is_eth_like(currency):
            prefix = prefix.upper()
        query = (
            "SELECT address_id FROM address_ids_by_address_prefix "
            "WHERE address_prefix = %s AND address = %s"
        )
        prefix_length = self.get_prefix_lengths(currency)["address"]
        result = await self.execute_async(
            currency, "transformed", query, [prefix[:prefix_length], address]
        )
        result = one(result)
        if not result:
            raise _AddressIdNotFound()

        return result["address_id"]

    async def get_address_id_id_group(self, currency, address):
        address_id = await self.get_address_id(currency, address)
        if address_id is None:
            raise AddressNotFoundException(currency, address)
        id_group = self.get_id_group(currency, address_id)
        return address_id, id_group

    def get_id_group(self, keyspace, id_):
        if keyspace not in self.parameters:
            raise NetworkNotFoundException(keyspace)
        bucket_size = self.parameters[keyspace]["bucket_size"]
        gid = floor(int(id_) / bucket_size)
        if gid.bit_length() > 31:
            # tron tx_id are long and the group is int
            # thus we need to also consider overflows in this case
            # additionally spark does not calculate ids on int basis but
            # based on floats which can lead to rounding errors.
            gid = calculate_id_group_with_overflow(id_, bucket_size)
        return gid

    def get_block_id_group(self, keyspace, id_):
        if keyspace not in self.parameters:
            raise NetworkNotFoundException(keyspace)
        return floor(int(id_) / self.parameters[keyspace]["block_bucket_size"])

    @eth
    def get_tx_id_group(self, keyspace, id_):
        if keyspace not in self.parameters:
            raise NetworkNotFoundException(keyspace)
        return floor(int(id_) / self.parameters[keyspace]["tx_bucket_size"])

    def get_tx_id_group_eth(self, keyspace, id_):
        return self.get_id_group(keyspace, id_)

    async def new_address(self, currency, address):
        data = await self.get_new_address(currency, address)
        if data is None:
            raise AddressNotFoundException(currency, address)
        Values = namedtuple("Values", ["value", "fiat_values"])
        zero_values = Values(
            value=0,
            fiat_values=[
                {"code": c.lower(), "value": 0.0}
                for c in self.parameters[currency]["fiat_currencies"]
            ],
        )
        return {
            "address": address,
            "cluster_id": data["address_id"],
            "first_tx": TxSummary(data["block_id"], data["timestamp"], data["tx_hash"]),
            "last_tx": TxSummary(data["block_id"], data["timestamp"], data["tx_hash"]),
            "no_incoming_txs": 0,
            "no_outgoing_txs": 0,
            "total_received": zero_values,
            "total_spent": zero_values,
            "in_degree": 0,
            "out_degree": 0,
            "balance": 0,
            "status": "new",
        }

    async def new_entity(self, currency, address):
        data = await self.new_address(currency, address)
        data["no_addresses"] = 1
        data["root_address"] = address
        return data

    async def get_address_by_address_id(self, currency, address_id):
        address_id_group = self.get_id_group(currency, address_id)
        query = (
            "SELECT address FROM address WHERE address_id = %s"
            " AND address_id_group = %s"
        )
        result = await self.execute_async(
            currency, "transformed", query, [address_id, address_id_group]
        )
        result = one(result)
        if not result:
            if not is_eth_like(currency):
                return None
            raise AddressNotFoundException(currency, address_id, no_external_txs=True)
        return result["address"]

    async def get_address(self, currency, address):
        address_id, address_id_group = await self.get_address_id_id_group(
            currency, address
        )
        query = "SELECT * FROM address WHERE address_id = %s AND address_id_group = %s"
        result = await self.execute_async(
            currency, "transformed", query, [address_id, address_id_group]
        )
        result = one(result)
        if not result:
            if not is_eth_like(currency):
                return None
            raise AddressNotFoundException(currency, address, no_external_txs=True)

        return await self.finish_address(currency, result)

    async def get_addresses_light(
        self, currency: str, addresses: list[str]
    ) -> dict[str, dict]:
        """Batch-fetch lightweight address info for heuristics.

        Returns {address: {cluster_id, no_incoming_txs, no_outgoing_txs, first_tx_id}}
        without running finish_address (no balance, tx lookups, dirty checks).
        """
        if not addresses:
            return {}

        # Step 1: batch-resolve address -> address_id
        prefix_length = self.get_prefix_lengths(currency)["address"]
        id_params = []
        for addr in addresses:
            prefix = self.scrub_prefix(currency, addr)
            if is_eth_like(currency):
                prefix = prefix.upper()
            id_params.append((prefix[:prefix_length], addr))

        id_query = (
            "SELECT address, address_id FROM address_ids_by_address_prefix "
            "WHERE address_prefix = %s AND address = %s"
        )
        id_results = await self.concurrent_with_args(
            currency, "transformed", id_query, id_params, filter_empty=True
        )

        # Step 2: batch-fetch address rows with only needed columns
        addr_id_map = {}  # address_id -> address string
        addr_params = []
        for row in id_results:
            aid = row["address_id"]
            addr_id_map[aid] = row["address"]
            gid = self.get_id_group(currency, aid)
            addr_params.append((aid, gid))

        if not addr_params:
            return {}

        addr_query = (
            "SELECT address_id, cluster_id, no_incoming_txs, no_outgoing_txs, "
            "first_tx_id FROM address "
            "WHERE address_id = %s AND address_id_group = %s"
        )
        addr_results = await self.concurrent_with_args(
            currency, "transformed", addr_query, addr_params, filter_empty=True
        )

        # Step 3: batch-resolve first_tx_id -> block_id (height) for all addresses
        tx_ids = set()
        for row in addr_results:
            if row.get("first_tx_id") is not None:
                tx_ids.add(row["first_tx_id"])

        tx_height_map = {}  # tx_id -> block_id
        if tx_ids:
            tx_params = [(self.get_tx_id_group(currency, tid), tid) for tid in tx_ids]
            tx_query = (
                "SELECT tx_id, block_id FROM transaction "
                "WHERE tx_id_group = %s AND tx_id = %s"
            )
            tx_results = await self.concurrent_with_args(
                currency, "raw", tx_query, tx_params, filter_empty=True
            )
            for row in tx_results:
                tx_height_map[row["tx_id"]] = row["block_id"]

        # Build result dict keyed by original address string
        result = {}
        for row in addr_results:
            addr = addr_id_map.get(row["address_id"])
            if addr is None:
                continue
            first_tx_id = row.get("first_tx_id")
            height = tx_height_map.get(first_tx_id) if first_tx_id is not None else None
            first_tx = None
            if height is not None:
                first_tx = TxSummary(tx_hash=None, timestamp=None, height=height)
            result[addr] = {
                "cluster_id": row.get("cluster_id", -1),
                "no_incoming_txs": saturate_int32_count(row.get("no_incoming_txs", 0)),
                "no_outgoing_txs": saturate_int32_count(row.get("no_outgoing_txs", 0)),
                "first_tx": first_tx,
            }

        return result

    async def get_address_tx_range(self, currency, address):
        """Get only first_tx_id and last_tx_id for an address."""
        address_id, address_id_group = await self.get_address_id_id_group(
            currency, address
        )
        query = (
            "SELECT first_tx_id, last_tx_id FROM address "
            "WHERE address_id = %s AND address_id_group = %s"
        )
        result = await self.execute_async(
            currency, "transformed", query, [address_id, address_id_group]
        )
        result = one(result)
        if not result:
            if not is_eth_like(currency):
                return None
            raise AddressNotFoundException(currency, address, no_external_txs=True)

        return result

    async def get_address_token_assets(self, currency, address, is_outgoing):
        """Return the set of token tickers an address actually transacted in.

        Derived from the address aggregate row's total_tokens_received /
        total_tokens_spent maps, which record exactly the token `currency`
        clustering values present in address_transactions for that address.
        Used to bound the per-token query fan-out (see list_address_txs_ordered)
        to only the tokens the address used instead of every supported token,
        so query cost per request does not grow with the number of supported
        tokens.

        is_outgoing True -> spent tokens, False -> received, None -> union.
        """
        address_id, address_id_group = await self.get_address_id_id_group(
            currency, address
        )
        query = (
            "SELECT total_tokens_received, total_tokens_spent FROM address "
            "WHERE address_id = %s AND address_id_group = %s"
        )
        result = one(
            await self.execute_async(
                currency, "transformed", query, [address_id, address_id_group]
            )
        )
        if not result:
            return set()
        received = {k.upper() for k in (result["total_tokens_received"] or {})}
        spent = {k.upper() for k in (result["total_tokens_spent"] or {})}
        if is_outgoing is None:
            return received | spent
        return spent if is_outgoing else received

    def _warn_unconfigured_tokens(
        self, currency, configured_assets, used_assets, context
    ):
        """Warn when address aggregates reference tokens that are missing from
        token_configuration. Transactions in such tokens can never be returned
        by the per-token queries — with or without fan-out bounding — so this
        points at a token_configuration gap, not at the bounding itself.
        """
        missing = set(used_assets) - {a.upper() for a in configured_assets}
        missing.discard(currency.upper())
        if missing and self.logger:
            self.logger.warning(
                f"{currency}: {context} used tokens missing from "
                f"token_configuration: {sorted(missing)}; transactions in "
                "these tokens are not included in results."
            )

    @eth
    async def get_address_entity_id(self, currency, address):
        address_id, address_id_group = await self.get_address_id_id_group(
            currency, address
        )

        # Always the legacy cluster id: entity ids are self-describing
        # (fresh ids live above FRESH_CLUSTER_ID_OFFSET), and the fresh id of
        # an address is discoverable via the fresh_cluster_id field on address
        # responses, so this legacy resolution needs no switch.
        query = (
            "SELECT cluster_id FROM address WHERE "
            "address_id_group = %s AND address_id = %s "
        )
        result = await self.execute_async(
            currency, "transformed", query, [address_id_group, address_id]
        )
        result = one(result)
        if not result:
            raise DBInconsistencyException(
                f"address {address} in {currency} with id "
                f"{address_id} and id_group {address_id_group} "
                f"not found in address table"
            )
        return result["cluster_id"]

    async def _fresh_clustering_active(self, currency) -> bool:
        """Cached (60s TTL) read of the keyspace's fresh-clustering marker.

        The one-off bootstrap writes the ``fresh_clustering_active`` state row
        as its last step. The fill below must gate on it — the fresh_* tables
        exist empty on every migrated keyspace, and treating every address as
        an implicit singleton on an un-bootstrapped keyspace would be wrong.
        Missing state table (pre-migration keyspace) counts as inactive.
        """
        cache = getattr(self, "_fresh_active_cache", None)
        if cache is None:
            cache = self._fresh_active_cache = {}
        hit = cache.get(currency)
        now = time.monotonic()
        if hit is not None and now - hit[1] < 60.0:
            return hit[0]
        try:
            result = await self.execute_async(
                currency,
                "transformed",
                f"SELECT key FROM {STATE_TABLE} WHERE key = %s",
                [FRESH_CLUSTERING_ACTIVE_KEY],
            )
            active = one(result) is not None
        except InvalidRequest:
            active = False
        cache[currency] = (active, now)
        return active

    async def get_fresh_cluster_id(self, currency, address_id):
        """Resolve an address's public (shifted) fresh cluster id.

        Fresh clustering stores only multi-member clusters, so an address
        without a ``fresh_address_cluster`` row is its own singleton
        (``cluster_id == address_id``). The raw table id is translated to the
        public id space (``+ FRESH_CLUSTER_ID_OFFSET``) so callers can hand it
        straight to the self-routing entity endpoints. Returns None only when
        fresh clustering is not active on this keyspace (bootstrap marker
        absent or fresh tables unavailable).
        """
        if not await self._fresh_clustering_active(currency):
            return None
        address_id_group = self.get_id_group(currency, address_id)
        query = (
            "SELECT cluster_id FROM fresh_address_cluster "
            "WHERE address_id_group = %s AND address_id = %s"
        )
        try:
            result = await self.execute_async(
                currency, "transformed", query, [address_id_group, address_id]
            )
        except InvalidRequest:
            # Table may not exist if fresh clustering has not been run yet
            return None
        result = one(result)
        if not result:
            return to_public_fresh_cluster_id(address_id)
        return to_public_fresh_cluster_id(result["cluster_id"])

    async def list_address_links(
        self,
        currency,
        address,
        neighbor,
        min_height=None,
        max_height=None,
        order=None,
        token_currency=None,
        page=None,
        pagesize=None,
    ):
        return await self.list_links(
            currency,
            NodeType.ADDRESS,
            address,
            neighbor,
            min_height=min_height,
            max_height=max_height,
            order=order,
            token_currency=token_currency,
            page=page,
            pagesize=pagesize,
        )

    async def list_entity_links(
        self,
        currency,
        address,
        neighbor,
        min_height=None,
        max_height=None,
        order=None,
        token_currency=None,
        page=None,
        pagesize=None,
    ):
        return await self.list_links(
            currency,
            NodeType.CLUSTER,
            address,
            neighbor,
            min_height=min_height,
            max_height=max_height,
            order=order,
            token_currency=token_currency,
            page=page,
            pagesize=pagesize,
        )

    async def list_links(
        self,
        currency,
        node_type: NodeType,
        id,
        neighbor,
        min_height=None,
        max_height=None,
        order=None,
        token_currency=None,
        page=None,
        pagesize=None,
        _no_direction_race=False,
        _precheck=None,
    ):
        ascending = order == "asc"

        # _precheck carries the already-fetched node rows, tx-id bounds and
        # edge tx count from the outer call into the direction-race's
        # recursive scans (none of them depend on the scan order), so a raced
        # request pays for the node/range/edge lookups once instead of twice.
        if _precheck is not None:
            src_node = _precheck["src_node"]
            dst_node = _precheck["dst_node"]
        elif node_type == NodeType.ADDRESS:
            src_node = await self.get_address(currency, id)
            dst_node = await self.get_address(currency, neighbor)
        else:
            src_node = await self.get_entity(currency, id)
            dst_node = await self.get_entity(currency, neighbor)

        if src_node is None:
            raise nodeNotFoundException(currency, node_type, id)

        if dst_node is None:
            raise nodeNotFoundException(currency, node_type, neighbor)

        # Saturate before comparing: these columns are 32-bit and a count past
        # 2**31 written by an older Spark jar is stored NEGATIVE (see
        # saturate_int32_count). Comparing the raw values inverts the choice of
        # scan side for exactly the busiest nodes — the TRON USDT contract
        # holds -580,448,962, so every counterparty looked "larger" than it and
        # links scanned its ~3.7e9-row history instead of the other side's.
        src_out = saturate_int32_count(src_node["no_outgoing_txs"])
        dst_in = saturate_int32_count(dst_node["no_incoming_txs"])

        is_outgoing = src_out < dst_in

        if is_outgoing:
            first = id
            second = neighbor
            is_outgoing = True
            first_value = "input_value"
            second_value = "output_value"
        else:
            first = neighbor
            second = id
            is_outgoing = False
            first_value = "output_value"
            second_value = "input_value"

        if token_currency is not None:
            include_assets = [token_currency.upper()]
        else:
            if is_eth_like(currency):
                token_config = self.get_token_configuration(currency)
                # Bound the fan-out to the tokens the "first" node (whose txs we
                # list in results1) actually used in the queried direction,
                # instead of every supported token.
                if is_outgoing:
                    used = src_node.get("total_tokens_spent") or {}
                else:
                    used = dst_node.get("total_tokens_received") or {}
                used = {k.upper() for k in used}
                self._warn_unconfigured_tokens(
                    currency, token_config.keys(), used, f"links {id} -> {neighbor}"
                )
                if self.tconfig.fanout_bounding_and_links_precheck_enabled:
                    include_assets = [a for a in token_config.keys() if a in used]
                else:
                    include_assets = list(token_config.keys())
                include_assets.append(currency.upper())
            else:
                include_assets = [currency.upper()]

        if _precheck is not None:
            # Already clamped by the outer call; the node clamp below is
            # idempotent so re-running it is harmless.
            tx_id_lower_bound = _precheck["tx_id_lower_bound"]
            tx_id_upper_bound = _precheck["tx_id_upper_bound"]
        else:
            (
                tx_id_lower_bound,
                tx_id_upper_bound,
            ) = await self.resolve_tx_id_range_by_block(
                currency, min_height, max_height
            )

        # Get the transaction ID range overlap for both nodes
        src_first_tx_id = src_node["first_tx_id"]
        src_last_tx_id = src_node["last_tx_id"]
        dst_first_tx_id = dst_node["first_tx_id"]
        dst_last_tx_id = dst_node["last_tx_id"]
        node_tx_id_lower_bound = max(src_first_tx_id, dst_first_tx_id)
        node_tx_id_upper_bound = min(src_last_tx_id, dst_last_tx_id)

        tx_id_lower_bound = max(
            tx_id_lower_bound or node_tx_id_lower_bound, node_tx_id_lower_bound
        )
        tx_id_upper_bound = min(
            tx_id_upper_bound or node_tx_id_upper_bound, node_tx_id_upper_bound
        )

        # Point-lookup the directed edge (id -> neighbor) in the relations
        # tables to bound this query. list_links otherwise walks the smaller
        # node's entire tx history to (re)discover an edge whose exact tx count
        # is already stored as no_transactions. This lets us (a) return
        # immediately when no direct edge exists and (b) stop paging once every
        # edge tx has been found (see the early-stop check in the loop below).
        # The endpoint is directional (from_address == id, to_address ==
        # neighbor), i.e. id's outgoing relation to neighbor.
        # eth-like only: UTXO relations net flows per (tx, address) while links
        # keep raw io membership semantics (see the filter below), so the
        # netted edge row is neither a validity gate nor a tx-count bound for
        # UTXO links.
        # edge_tx_count None means the pre-check does not apply: no early
        # return here and no early stop in the loop below (full history walk).
        edge_tx_count = None
        if self.tconfig.fanout_bounding_and_links_precheck_enabled and is_eth_like(
            currency
        ):
            if _precheck is not None:
                edge_tx_count = _precheck["edge_tx_count"]
            else:
                if node_type == NodeType.ADDRESS:
                    neighbor_id = await self.get_address_id(currency, neighbor)
                else:
                    neighbor_id = int(neighbor)

                edge_tx_count = 0
                if neighbor_id is not None:
                    edge_rows, _ = await self.list_neighbors(
                        currency,
                        id,
                        True,
                        node_type,
                        targets=[neighbor_id],
                        page=None,
                        pagesize=None,
                        include_neighbor_rows=False,
                    )
                    if edge_rows:
                        edge_tx_count = sum(row["no_transactions"] for row in edge_rows)

            if edge_tx_count == 0:
                # No direct edge id -> neighbor: there can be no links.
                return [], None

        final_results = []
        requested_pagesize = pagesize or SMALL_PAGE_SIZE
        fetch_size = max(FETCH_SIZE_MIN, requested_pagesize)
        adaptive_cap = self.tconfig.links_adaptive_fetch_size_cap

        # For eth-like the second side can only hold a link tx in the
        # direction opposite to the first side's scan (candidates are
        # first's outgoing txs -> second received them, and vice versa).
        # UTXO must probe both directions: its address_transactions rows
        # carry only the net direction (see comment at the results2 call).
        second_is_outgoing = None
        if is_eth_like(currency) and self.tconfig.links_directed_probe_enabled:
            second_is_outgoing = not is_outgoing

        # Sparse-edge direction race: when the pre-check shows the whole edge
        # fits in one page, the requested-order scan may still walk the entire
        # history when the links sit at its far end, while the opposite
        # direction would find them immediately (and early-stop via
        # all_edge_found). Race both directions and take the first complete
        # result. A flipped result is only used when it provably holds the
        # complete link set (no next page and fewer rows than the requested
        # page), re-sorted into the requested order — so results and page
        # tokens are identical to the non-raced scan.
        # The candidate side of the scan is the smaller directed history
        # (see is_outgoing above); its tx count bounds how long the requested
        # scan can possibly take. Small histories can never be pathologically
        # slow, so they skip the race entirely (structural guard) — the hedge
        # delay below is only a temporal guard and would still fire for every
        # mid-size request whenever the whole cluster is slow, adding a
        # second scan's load exactly when the cluster is struggling.
        candidate_count = min(src_out, dst_in)
        if (
            not _no_direction_race
            and self.tconfig.links_sparse_direction_race_enabled
            and page is None
            and edge_tx_count is not None
            and 0 < edge_tx_count < requested_pagesize
            and candidate_count > self.tconfig.links_direction_race_min_candidates
        ):
            precheck = {
                "src_node": src_node,
                "dst_node": dst_node,
                "tx_id_lower_bound": tx_id_lower_bound,
                "tx_id_upper_bound": tx_id_upper_bound,
                "edge_tx_count": edge_tx_count,
            }
            task_requested = asyncio.ensure_future(
                self.list_links(
                    currency,
                    node_type,
                    id,
                    neighbor,
                    min_height=min_height,
                    max_height=max_height,
                    order=order,
                    token_currency=token_currency,
                    page=None,
                    pagesize=pagesize,
                    _no_direction_race=True,
                    _precheck=precheck,
                )
            )
            task_flipped = None
            # The finally block guarantees neither scan outlives this call,
            # whichever branch returns, raises or is cancelled; a done losing
            # task has its exception marked retrieved.
            try:
                # Hedge: give the requested direction a head start; only a
                # scan that is already slow warrants the cost (and
                # contention) of a concurrent opposite-direction scan.
                done, _ = await asyncio.wait(
                    {task_requested},
                    timeout=self.tconfig.links_direction_race_hedge_delay_ms / 1000.0,
                )
                if task_requested in done:
                    return task_requested.result()
                task_flipped = asyncio.ensure_future(
                    self.list_links(
                        currency,
                        node_type,
                        id,
                        neighbor,
                        min_height=min_height,
                        max_height=max_height,
                        order="desc" if ascending else "asc",
                        token_currency=token_currency,
                        page=None,
                        pagesize=pagesize,
                        _no_direction_race=True,
                        _precheck=precheck,
                    )
                )
                done, _ = await asyncio.wait(
                    {task_requested, task_flipped},
                    return_when=asyncio.FIRST_COMPLETED,
                )
                # A flipped scan that errored simply loses the race; only a
                # clean, provably complete flipped result short-circuits the
                # requested scan.
                if task_requested not in done and task_flipped.exception() is None:
                    flip_results, flip_page = task_flipped.result()
                    if flip_page is None and len(flip_results) < requested_pagesize:
                        self.logger.debug(
                            f"direction race won by flipped scan with "
                            f"{len(flip_results)} complete results"
                        )
                        return list(reversed(flip_results)), None
                return await task_requested
            finally:
                for task in (task_requested, task_flipped):
                    if task is None:
                        continue
                    if not task.done():
                        task.cancel()
                        await asyncio.gather(task, return_exceptions=True)
                    elif not task.cancelled():
                        task.exception()

        tx_id = "transaction_id" if is_eth_like(currency) else "tx_id"

        # Only the columns the links intersection actually reads from the
        # candidate side; full rows are still fetched for the second side
        # (results2), which is what gets returned/normalized.
        candidate_cols = None
        if self.tconfig.links_slim_candidate_columns_enabled:
            candidate_cols = (
                [tx_id, "tx_reference", "currency"]
                if is_eth_like(currency)
                else [tx_id, "value"]
            )

        def fetch_candidates(cand_page, cand_fetch_size):
            return asyncio.ensure_future(
                self.list_address_txs_ordered(
                    network=currency,
                    node_type=node_type,
                    id=first,
                    tx_id_lower_bound=tx_id_lower_bound,
                    tx_id_upper_bound=tx_id_upper_bound,
                    is_outgoing=is_outgoing,
                    include_assets=include_assets,
                    ascending=ascending,
                    page=cand_page,
                    cols=candidate_cols,
                    fetch_size=max(FETCH_SIZE_MIN, cand_fetch_size),
                )
            )

        prefetch = self.tconfig.links_candidate_prefetch_enabled
        candidate_task = fetch_candidates(page, fetch_size)
        # The finally block guarantees an in-flight prefetch never
        # outlives this call, also when probing or verification raises.
        try:
            while len(final_results) < requested_pagesize:
                results1_raw, new_pages, finished = await candidate_task
                candidate_task = None
                final_page1 = new_pages[-1] if new_pages and not finished else None

                # Pipeline: start fetching the next candidate page while this
                # one is probed. Candidate pages are deterministic in
                # (page token, batch size), so results are unchanged; if the
                # loop terminates early the in-flight task is discarded below.
                # A finished scan has no next page even when the last row still
                # carries a token — same gate as final_page1.
                next_page = new_pages[-1] if new_pages and not finished else None
                next_fetch_size = fetch_size
                if adaptive_cap and next_fetch_size < adaptive_cap:
                    next_fetch_size = min(next_fetch_size * 2, adaptive_cap)
                if prefetch and next_page is not None:
                    candidate_task = fetch_candidates(next_page, next_fetch_size)

                self.logger.debug(f"results1 {len(results1_raw)} {final_page1}")

                if is_eth_like(currency):
                    if self.tconfig.links_per_tx_asset_probe_enabled:
                        # A link is one transfer seen from both sides, so the
                        # second side's row has the candidate's own currency —
                        # probe only that asset per tx instead of the batch's
                        # asset union.
                        first_tx_ids = [
                            (row[tx_id], row["tx_reference"], row["currency"])
                            for row in results1_raw
                        ]
                    else:
                        first_tx_ids = [
                            (row[tx_id], row["tx_reference"]) for row in results1_raw
                        ]
                else:
                    first_tx_ids = [(row[tx_id], None) for row in results1_raw]

                if token_currency is not None:
                    # Token-filtered query: only the token's rows on the `second`
                    # side are relevant. Fetching the native asset (or others) here
                    # would (a) let non-token events leak into a token-filtered
                    # result — e.g. the native contract-call trace when `neighbor`
                    # is the token contract, which passes the address-only filter
                    # below but is not a token transfer — and (b) multiply the
                    # per-page fan-out against a possibly huge `second` partition.
                    # It never drops a genuine token link: a real token transfer
                    # id -> neighbor still produces a token row on the second side.
                    assets = [token_currency.upper()]
                else:
                    assets = set([currency.upper()])
                    if is_eth_like(currency):
                        for row in results1_raw:
                            assets.add(row["currency"])

                    assets = list(assets)

                results2, _, _ = await self.list_address_txs_ordered(
                    network=currency,
                    node_type=node_type,
                    id=second,
                    tx_id_lower_bound=None,
                    tx_id_upper_bound=None,
                    # fetch both directions by default, this is needed since for
                    # some transactions the total flow is an inflow but it is an
                    # outflow at the same time (UTXO address_transactions rows
                    # carry only the net direction). If we would not fetch both
                    # directions we would miss these transactions. eth-like may
                    # narrow this to the only possible direction (see
                    # second_is_outgoing above).
                    is_outgoing=second_is_outgoing,
                    include_assets=assets,
                    ascending=ascending,
                    tx_ids=first_tx_ids,  # limit second set by tx ids of first set
                    page=None,
                    fetch_size=len(first_tx_ids),
                )
                self.logger.debug(f"results2 {len(results2)}")

                if is_eth_like(currency):
                    results2 = await self.normalize_address_transactions(
                        currency,
                        results2,
                        ignore_traces_not_found=self.tconfig.ignore_traces_not_found_in_list_txs,
                    )
                else:
                    results1 = {row[tx_id]: row for row in results1_raw}
                    tx_ids = [row[tx_id] for row in results2]
                    txs = await self.list_txs_by_ids(currency, tx_ids)

                    if len(results2) != len(txs):
                        raise DBInconsistencyException(
                            "result sets for txs intersection not equal"
                        )

                    # merge address_transactions and raw transaction sets
                    for row, tx in zip(results2, txs):
                        row[second_value] = row["value"]
                        row[first_value] = results1[row[tx_id]]["value"]

                        for k, v in tx.items():
                            row[k] = v

                    # results2 was indexed by `second`; assert each merged tx
                    # actually has `second` on the side its is_outgoing claims.
                    # Catches address_transactions index misalignments. Only
                    # checked for ADDRESS queries.
                    if node_type == NodeType.ADDRESS:
                        for row in results2:
                            self._verify_address_in_tx_btc(
                                currency, second, row, row.get("is_outgoing")
                            )

                if is_eth_like(currency):
                    # TODO probably this check is no longer necessary
                    # since we filtered on tx_ref level already
                    # in list_address_txs_ordered
                    if node_type == NodeType.CLUSTER:
                        neighbor = dst_node["root_address"]
                        id = src_node["root_address"]

                    # results2 was indexed by `second`; assert each returned row
                    # actually has `second` on the side its is_outgoing claims.
                    # Catches address_transactions index misalignments.
                    second_address = neighbor if is_outgoing else id
                    for row in results2:
                        self._verify_address_in_tx_eth(currency, second_address, row)

                    # Token/Trace transactions might not be between the requested
                    # nodes so only keep the relevant ones
                    before = len(results2)
                    results2 = [
                        tx
                        for tx in results2
                        if tx["to_address"] == neighbor and tx["from_address"] == id
                    ]
                    self.logger.debug(f"pruned {before - len(results2)}")
                if not is_eth_like(currency):
                    # Keep only rows where `id` is in the inputs and `neighbor` in
                    # the outputs — RAW io membership, deliberately NOT the netted
                    # sender/receiver pairing that relations are built from. The
                    # per-(tx, address) netting hides real output receipt for
                    # addresses appearing on both sides of a tx; that is considered
                    # wrong semantics (see the netting desired-semantics test in
                    # tests/regressions) and links must not propagate it. Until the
                    # transform's netting is fixed, /links can therefore list txs
                    # for pairs that have no netted relation edge — which is also
                    # why the relations pre-check above is eth-only.
                    # Filter the FRESH page (results2) BEFORE extending —
                    # re-filtering the whole accumulated `final_results` on every
                    # while-loop iteration would re-run the per-address cluster-id
                    # lookups for already-accepted rows (10^5+ serial queries per
                    # request in the cluster case).
                    if node_type == NodeType.ADDRESS:

                        def has_address_in_ios(address, ios):
                            if ios is None and address == "coinbase":
                                return True
                            if ios is None:
                                return False
                            addresses_io = sum([x.address or [] for x in ios], [])
                            return address in addresses_io

                        results2 = [
                            r
                            for r in results2
                            if has_address_in_ios(id, r["inputs"])
                            and has_address_in_ios(neighbor, r["outputs"])
                        ]
                    else:

                        def get_address_from_io(x):
                            address_wrapped = x.address
                            if address_wrapped is None:
                                return None
                            assert len(address_wrapped) == 1
                            return address_wrapped[0]

                        async def cluster_ids_of(ios):
                            addresses_io = [get_address_from_io(x) for x in ios]
                            addresses_io = [a for a in addresses_io if a is not None]
                            # resolve the io addresses' cluster ids concurrently
                            return set(
                                await asyncio.gather(
                                    *[
                                        self.get_address_entity_id(currency, a)
                                        for a in addresses_io
                                    ]
                                )
                            )

                        async def cluster_row_matches(r):
                            in_ids, out_ids = await asyncio.gather(
                                cluster_ids_of(r["inputs"]),
                                cluster_ids_of(r["outputs"]),
                            )
                            return id in in_ids and neighbor in out_ids

                        keep = await asyncio.gather(
                            *[cluster_row_matches(r) for r in results2]
                        )
                        results2 = [r for r, k in zip(results2, keep) if k]

                final_results.extend(results2)

                # Once every edge tx has been found there is nothing left to page
                # for. Only eth-like queries carry a non-None edge_tx_count (the
                # pre-check above is eth-only): there no_transactions counts
                # transfer rows (native txs plus token transfers), which is >=
                # their distinct tx ids, so the early stop can only over-scan,
                # never truncate. For UTXO the raw links are not bounded by the
                # netted relation row, so edge_tx_count stays None and the scan
                # always walks the full overlap window.
                all_edge_found = (
                    edge_tx_count is not None
                    and len({row[tx_id] for row in final_results}) >= edge_tx_count
                )

                # Check if we have enough results after all filtering
                if len(final_results) >= requested_pagesize:
                    # Truncate to exact requested size and get page token from last result
                    final_results = final_results[:requested_pagesize]
                    # now we know which is the last item from results1 that made it into final_results
                    # so we can use that to get the page token from the last result
                    last_row = final_results[-1]
                    result1_to_page_mapping = {
                        (
                            row[tx_id],
                            row["tx_reference"] if is_eth_like(currency) else None,
                        ): page
                        for row, page in zip(results1_raw, new_pages)
                    }
                    page = result1_to_page_mapping[
                        (
                            last_row[tx_id],
                            last_row["tx_reference"] if is_eth_like(currency) else None,
                        )
                    ]
                    self.logger.debug(
                        f"early termination with {len(final_results)} results, page: {page}"
                    )
                    break

                if all_edge_found:
                    # All edge txs found and they fit within one page: no more
                    # results exist, so there is no next page.
                    page = None
                    self.logger.debug(
                        f"all {edge_tx_count} edge txs found; stopping scan"
                    )
                    break

                page = next_page
                self.logger.debug(f"next page {page}")
                if page is None:
                    break

                # The page is not filled yet: the links are sparse in the first
                # side's history, so widen the next candidate batch. Batch size
                # only changes round-trip count, never results or page tokens.
                fetch_size = next_fetch_size
                if candidate_task is None:
                    candidate_task = fetch_candidates(page, fetch_size)

        finally:
            if candidate_task is not None:
                candidate_task.cancel()
                await asyncio.gather(candidate_task, return_exceptions=True)

        self.logger.debug(f"final_results len {len(final_results)}")

        return final_results, str(page) if page is not None else None

    async def _list_matching_addresses_short_prefix_and_postfix_eth(
        self, currency: str, prefix: str, postfix: str, limit: int
    ):
        res = []
        for c in HEX_ALPHABET:
            results = await self.list_matching_addresses(
                currency, f"{prefix}{c}...{postfix}", limit=None
            )
            res.extend(results)
            if len(res) >= limit:
                break

        return res[:limit]

    async def list_matching_addresses(
        self, currency, expression, limit: Optional[int] = 10
    ):
        # Todo: the new postfix filtering is incomplete in scenarios where the item with the postfix is not in the
        # results within the limit specified. A more complete solution would require a different querying approach.
        # e.g. if a postfix is given we would need to iterate the entire result set.
        # we don't do this now for performance reasons. (some prefixes are huge, eg 0x00000)

        parts = expression.split("...", 1)
        if len(parts) == 2:
            expression, postfix = parts
        else:
            postfix = None
            expression = parts[0]

        prefix_lengths = self.get_prefix_lengths(currency)
        expression_orginal = expression

        postprocess_address = identity1
        currency_for_prefixscrub = currency
        if currency == "trx":
            postprocess_address = try_partial_tron_to_partial_evm
            currency_for_prefixscrub = "eth"

        expression = postprocess_address(expression)

        if is_eth_like(currency):
            # fold unicode to ascii ("ﬀ" U+FB00 -> "ff") before prefix/bound
            # derivation; base58 is case-sensitive so utxo stays as typed
            expression = expression.casefold()
            if postfix is not None:
                postfix = postfix.casefold()

        if (
            currency == "eth"
            and len(strip_0x(expression)) == (prefix_lengths["address"] - 1)
            and postfix is not None
        ):
            # Tools like TRM show addresses in with short prefixes but with postfixes
            # e.g. 0x33d05d...8f65 we have to add special handling to also find these here.
            return await self._list_matching_addresses_short_prefix_and_postfix_eth(
                currency, expression, postfix, limit
            )

        if len(expression) < prefix_lengths["address"]:
            return []
        norm = identity2

        prefix = self.scrub_prefix(currency_for_prefixscrub, expression)
        prefix = prefix[: prefix_lengths["address"]]

        if is_eth_like(currency):
            if not is_hexadecimal(expression):
                return []

            if postfix is not None and not is_hexadecimal(postfix):
                return []

            # eth addresses are case insensitive
            expression = expression.lower()
            norm = address_to_user_format
            prefix = prefix.upper()

            query_expression = expression

        else:
            expression = expression_orginal
            query_expression = expression_orginal

        rows = []

        if len(prefix) < 1:
            return []

        upper_bound = create_upper_bound(
            query_expression, is_string_not_hex=not is_eth_like(currency)
        )

        if is_eth_like(currency) and len(query_expression) % 2 != 0:
            query_expression = query_expression + "0"

        if is_eth_like(currency) and len(upper_bound) % 2 != 0:
            upper_bound = upper_bound + "0"

        query = (
            "SELECT address FROM address_ids_by_address_prefix "
            "WHERE address_prefix = %s AND address >= %s AND address < %s"
        ) + (" LIMIT %s" if limit is not None else "")
        if is_eth_like(currency):
            params = [
                prefix,
                hex_str_to_bytes(strip_0x(query_expression)),
                hex_str_to_bytes(strip_0x(upper_bound)),
            ]
        else:
            params = [prefix, query_expression, upper_bound]

        if limit is not None:
            params.append(limit)

        # get results and use postfilter
        result = await self.execute_async(currency, "transformed", query, params)
        rows.extend([norm(currency, row["address"]) for row in result.current_rows])

        if postfix:
            rows = [r for r in rows if r.lower().endswith(postfix.lower())]

        return rows

    @eth
    async def get_entity(self, currency, entity):
        entity = int(entity)
        if not is_representable_entity_id(entity):
            raise ClusterNotFoundException(currency, entity)
        if is_fresh_cluster_id(entity):
            return await self._get_fresh_entity(currency, entity)
        entity_id_group = self.get_id_group(currency, entity)
        query = "SELECT * FROM cluster WHERE cluster_id_group = %s AND cluster_id = %s "
        result = await self.execute_async(
            currency, "transformed", query, [entity_id_group, entity]
        )
        result = one(result)
        if not result:
            raise ClusterNotFoundException(currency, entity)
        return (await self.finish_entities(currency, [result]))[0]

    @eth
    async def get_entities_by_ids(self, currency, entity_ids):
        """Batched analog of get_entity for a page of neighbor cluster ids.

        list_neighbors' cluster relations tables carry only legacy cluster
        ids (see _legacy_relations_cluster_id: "the fresh tables carry no
        cluster relations"), so unlike get_entity this never needs the
        fresh-cluster or non-representable-id branches. Fetches the page's
        cluster rows with grouped single-partition IN queries instead of one
        independent get_entity chain (cluster row + root address + tx
        summaries) per id, then reuses finish_entities' batched prefetch for
        the rest. Raises ClusterNotFoundException for the first id with no
        matching row, matching get_entity. Returns {entity_id: row}.
        """
        ids = list(dict.fromkeys(entity_ids))
        if not ids:
            return {}
        rows_by_id = await self._get_cluster_rows_by_ids(currency, ids)
        missing = next((id for id in ids if id not in rows_by_id), None)
        if missing is not None:
            raise ClusterNotFoundException(currency, missing)
        finished = await self.finish_entities(currency, [rows_by_id[id] for id in ids])
        return dict(zip(ids, finished))

    async def get_entities_by_ids_eth(self, currency, entity_ids):
        # The eth entity read (get_entity_eth) is a single point read, not
        # the multi-hop chain the UTXO path has, so batching here is just
        # bounding concurrency instead of throttling on the unrelated
        # tagstore semaphore (see list_entity_neighbors).
        ids = list(dict.fromkeys(entity_ids))
        if not ids:
            return {}
        sem = asyncio.Semaphore(MAX_ROW_LOOKUP_CONCURRENCY)

        async def _one(entity_id):
            async with sem:
                return await self.get_entity_eth(currency, entity_id)

        results = await asyncio.gather(*[_one(id) for id in ids])
        for entity_id, row in zip(ids, results):
            if not row:
                raise ClusterNotFoundException(currency, entity_id)
        return dict(zip(ids, results))

    async def _get_cluster_rows_by_ids(self, currency, cluster_ids):
        # Grouped single-partition IN queries instead of one point read per
        # cluster: same pattern as _get_tx_summaries_by_ids /
        # _get_root_addresses_by_ids — cluster_id_group is fixed per
        # partition, so ids sharing a group become one "cluster_id in (...)"
        # statement.
        groups = {}
        for cluster_id in cluster_ids:
            groups.setdefault(self.get_id_group(currency, cluster_id), []).append(
                cluster_id
            )
        statement = (
            "SELECT * FROM cluster WHERE cluster_id_group = %s AND cluster_id in %s"
        )

        async def fetch_chunk(group, chunk):
            result = await self.execute_async(
                currency, "transformed", statement, [group, ValueSequence(chunk)]
            )
            return result.current_rows

        aws = [
            fetch_chunk(group, group_ids[i : i + 200])
            for group, group_ids in groups.items()
            for i in range(0, len(group_ids), 200)
        ]
        rows = [row for chunk_rows in await asyncio.gather(*aws) for row in chunk_rows]
        return {row["cluster_id"]: row for row in rows}

    async def _get_fresh_entity(self, currency, entity):
        """Serve an entity from the fresh tables (public id >= offset).

        Works on the raw table id internally (root resolution and membership
        are keyed by it) and shifts ``cluster_id`` back to the public id space
        on the finished row.
        """
        raw = to_raw_fresh_cluster_id(entity)
        query = (
            "SELECT * FROM fresh_cluster_stats "
            "WHERE cluster_id_group = %s AND cluster_id = %s "
        )
        result = await self.execute_async(
            currency, "transformed", query, [self.get_id_group(currency, raw), raw]
        )
        result = one(result)
        if not result:
            result = await self._fresh_singleton_entity(currency, raw)
            if result is None:
                raise ClusterNotFoundException(currency, entity)
        elif _fresh_degrees_pending(result):
            result = await self._fresh_fill_degrees(currency, result)
        finished = (await self.finish_entities(currency, [result]))[0]
        finished["cluster_id"] = to_public_fresh_cluster_id(finished["cluster_id"])
        return finished

    async def _fresh_singleton_entity(self, currency, cluster_id):
        """Synthesize a one-address entity for a fresh-clustering singleton.

        Fresh clustering stores only multi-member clusters, so a cluster id with
        no ``fresh_cluster_stats`` row is its own singleton
        (``cluster_id == address_id``). Shape that address's row as a
        single-member cluster-stats row. Returns ``None`` when no such address
        exists (a genuinely unknown id).
        """
        address_id_group = self.get_id_group(currency, cluster_id)
        query = "SELECT * FROM address WHERE address_id_group = %s AND address_id = %s"
        row = one(
            await self.execute_async(
                currency, "transformed", query, [address_id_group, cluster_id]
            )
        )
        if not row:
            return None
        return {
            "cluster_id": cluster_id,
            "no_addresses": 1,
            "min_address_id": cluster_id,
            "no_incoming_txs": row["no_incoming_txs"],
            "no_outgoing_txs": row["no_outgoing_txs"],
            "in_degree": row["in_degree"],
            "out_degree": row["out_degree"],
            "first_tx_id": row["first_tx_id"],
            "last_tx_id": row["last_tx_id"],
            "total_received": row["total_received"],
            "total_spent": row["total_spent"],
        }

    def _zero_values(self, currency):
        Values = namedtuple("Values", ["value", "fiat_values"])
        return Values(
            value=0,
            fiat_values=[0.0 for _ in self.parameters[currency]["fiat_currencies"]],
        )

    async def _legacy_relations_cluster_id(self, currency, entity):
        """Map a public entity id to the id keyed in the legacy relations tables.

        The fresh tables carry no cluster relations (neighbors / cluster
        transactions / links), so fresh ids are served from the legacy tables
        via the root-address hop: the fresh root (raw id == min address id)
        still carries its legacy cluster id on its address row. This is the
        same hop that fills degrees, so listed neighbors always match the
        degrees served on the entity. Where fresh merged several legacy
        clusters this is the root's fragment and understates. Returns None
        when the root has no legacy cluster (postdates the last full
        transform) — callers serve an empty result then.
        """
        if not is_fresh_cluster_id(entity):
            return entity
        raw = to_raw_fresh_cluster_id(entity)
        addr = one(
            await self.execute_async(
                currency,
                "transformed",
                "SELECT cluster_id FROM address "
                "WHERE address_id_group = %s AND address_id = %s",
                [self.get_id_group(currency, raw), raw],
            )
        )
        if addr and addr.get("cluster_id") is not None:
            return addr["cluster_id"]
        return None

    async def _fresh_fill_degrees(self, currency, row):
        """Fill missing cluster degrees from the legacy ``cluster`` table.

        ``fresh_cluster_stats`` does not carry degrees (deriving them required
        scanning the address-relations tables). The fresh root address
        (``cluster_id == min(address_id)``) still carries its LEGACY cluster id
        on its address row, so serve that legacy cluster's degrees. Where fresh merged several
        legacy clusters this is the root's fragment and UNDERSTATES — which
        fails open for degree-threshold consumers (gssearch prunes on
        ``degree > N``, so an understated degree never hides results).

        No legacy id/row means the root postdates the last full transform, so
        the whole cluster is post-transform and small: fall back to
        member-summed address degrees, an OVERCOUNT (intra-cluster edges and
        shared counterparties count once per member). Coalesce to 0 — the API
        requires non-null ints.
        """
        cluster_id = row["cluster_id"]
        addr = one(
            await self.execute_async(
                currency,
                "transformed",
                "SELECT cluster_id FROM address "
                "WHERE address_id_group = %s AND address_id = %s",
                [self.get_id_group(currency, cluster_id), cluster_id],
            )
        )
        legacy = None
        if addr and addr.get("cluster_id") is not None:
            legacy_id = addr["cluster_id"]
            legacy = one(
                await self.execute_async(
                    currency,
                    "transformed",
                    "SELECT in_degree, out_degree FROM cluster "
                    "WHERE cluster_id_group = %s AND cluster_id = %s",
                    [self.get_id_group(currency, legacy_id), legacy_id],
                )
            )
        if legacy:
            row["in_degree"] = legacy["in_degree"] or 0
            row["out_degree"] = legacy["out_degree"] or 0
            return row
        query = (
            "SELECT address_id FROM fresh_cluster_addresses "
            "WHERE cluster_id_group = %s AND cluster_id = %s"
        )
        members = await self.execute_async(
            currency,
            "transformed",
            query,
            [self.get_id_group(currency, cluster_id), cluster_id],
        )
        member_ids = [r["address_id"] for r in members.current_rows] or [cluster_id]
        params = [(self.get_id_group(currency, id), id) for id in member_ids]
        query = (
            "SELECT in_degree, out_degree FROM address "
            "WHERE address_id_group = %s AND address_id = %s"
        )
        addrs = await self.concurrent_with_args(currency, "transformed", query, params)
        row["in_degree"] = sum(a["in_degree"] or 0 for a in addrs)
        row["out_degree"] = sum(a["out_degree"] or 0 for a in addrs)
        return row

    async def _fresh_heal_pending_entities(self, currency, rows):
        """Fill legacy degrees on rows in a bulk entity result.

        ``fresh_cluster_stats`` never carries degrees, so every stored row needs
        the legacy degree fill. The stat columns themselves are written complete
        by the incremental updater (member sums) and the recompute, so no
        member-synthesis is needed here anymore.
        """

        async def heal(row):
            if _fresh_degrees_pending(row):
                return await self._fresh_fill_degrees(currency, row)
            return row

        healed = await asyncio.gather(*[heal(row) for row in rows])
        return [row for row in healed if row is not None]

    async def _fresh_fill_singleton_entities(self, currency, ids, rows):
        """Restore singletons dropped from a fresh bulk entity lookup.

        ``list_entities`` reads ``fresh_cluster_stats``, which holds only
        multi-member clusters, so singleton ids return no row. Legacy returned
        one row per stored cluster id, so mirror that by synthesizing the
        one-address entity for each requested id missing from ``rows``,
        preserving input order and dropping only genuinely unknown ids (no
        address) — exactly the ids legacy would also have omitted.
        """
        found = {row["cluster_id"]: row for row in rows if "cluster_id" in row}
        missing = [int(id) for id in ids if int(id) not in found]
        synthesized = await asyncio.gather(
            *[self._fresh_singleton_entity(currency, id) for id in missing]
        )
        singletons = {
            id: entity for id, entity in zip(missing, synthesized) if entity is not None
        }
        result = []
        for id in ids:
            id = int(id)
            if id in found:
                result.append(found[id])
            elif id in singletons:
                result.append(singletons[id])
        return result

    @eth
    async def list_entities(
        self, currency, ids, page=None, pagesize=None, fields=["*"]
    ):
        """List entities by id (mixed legacy/fresh) or page the legacy table.

        Explicit ids are routed per id: ids >= FRESH_CLUSTER_ID_OFFSET are
        served from the fresh tables (with singleton synthesis and pending
        healing), the rest from the legacy ``cluster`` table; input order is
        preserved. The id-less paging form enumerates the legacy table only —
        fresh clusters are not enumerable through this endpoint.
        """
        fetch_size = min(pagesize or SMALL_PAGE_SIZE, SMALL_PAGE_SIZE)
        paging_state = page_from_hex(page)
        flds = ",".join(fields)
        has_ids = isinstance(ids, list)
        if has_ids:
            ids = [int(id) for id in ids]
            fresh_raw = [
                to_raw_fresh_cluster_id(id) for id in ids if is_fresh_cluster_id(id)
            ]
            legacy_ids = [id for id in ids if not is_fresh_cluster_id(id)]
            with_txs = (
                "*" in fields or "first_tx_id" in fields or "last_tx_id" in fields
            )
            by_public_id = {}
            if legacy_ids:
                query = (
                    f"SELECT {flds} FROM cluster"
                    " WHERE cluster_id_group = %s AND cluster_id = %s"
                )
                params = [[self.get_id_group(currency, id), id] for id in legacy_ids]
                rows = await self.concurrent_with_args(
                    currency, "transformed", query, params
                )
                rows = await self.finish_entities(currency, rows, with_txs)
                by_public_id.update(
                    {row["cluster_id"]: row for row in rows if "cluster_id" in row}
                )
            if fresh_raw:
                query = (
                    f"SELECT {flds} FROM fresh_cluster_stats"
                    " WHERE cluster_id_group = %s AND cluster_id = %s"
                )
                params = [[self.get_id_group(currency, id), id] for id in fresh_raw]
                rows = await self.concurrent_with_args(
                    currency, "transformed", query, params
                )
                rows = await self._fresh_fill_singleton_entities(
                    currency, fresh_raw, rows
                )
                rows = await self._fresh_heal_pending_entities(currency, rows)
                # finish on raw ids (root resolution), publish shifted ids
                rows = await self.finish_entities(currency, rows, with_txs)
                for row in rows:
                    row["cluster_id"] = to_public_fresh_cluster_id(row["cluster_id"])
                by_public_id.update(
                    {row["cluster_id"]: row for row in rows if "cluster_id" in row}
                )
            result = [by_public_id[id] for id in ids if id in by_public_id]
            return result, to_hex(None)

        query = f"SELECT {flds} FROM cluster"
        rows = await self.execute_async(
            currency,
            "transformed",
            query,
            paging_state=paging_state,
            fetch_size=fetch_size,
        )
        paging_state = rows.paging_state
        result = rows.current_rows

        with_txs = "*" in fields or "first_tx_id" in fields or "last_tx_id" in fields
        return await self.finish_entities(currency, result, with_txs), to_hex(
            paging_state
        )

    @eth
    async def list_entity_addresses(self, currency, entity, page=None, pagesize=None):
        paging_state = page_from_hex(page)
        entity = int(entity)
        if not is_representable_entity_id(entity):
            return [], None
        fresh = is_fresh_cluster_id(entity)
        if fresh:
            entity = to_raw_fresh_cluster_id(entity)
        entity_id_group = self.get_id_group(currency, entity)
        table = "fresh_cluster_addresses" if fresh else "cluster_addresses"
        query = (
            f"SELECT address_id FROM {table} "
            "WHERE cluster_id_group = %s AND cluster_id = %s"
        )
        fetch_size = min(pagesize or SMALL_PAGE_SIZE, SMALL_PAGE_SIZE)
        results = await self.execute_async(
            currency,
            "transformed",
            query,
            [entity_id_group, entity],
            paging_state=paging_state,
            fetch_size=fetch_size,
        )
        if results is None:
            return []

        params = [
            (self.get_id_group(currency, row["address_id"]), row["address_id"])
            for row in results.current_rows
        ]
        if not params and page is None and fresh:
            # Fresh clustering stores only multi-member clusters, so a cluster
            # id with no membership rows is its own singleton (cluster_id ==
            # address_id). Legacy cluster_addresses had a row for singletons
            # too, so serve that one address; an unknown id still yields an
            # empty result, matching legacy.
            params = [(entity_id_group, entity)]
        # Grouped single-partition IN queries instead of one point read per
        # address: address_id_group is fixed per partition, so ids sharing a
        # group become one "address_id in (...)" statement.
        groups = {}
        for group, address_id in params:
            groups.setdefault(group, []).append(address_id)
        query = "SELECT * FROM address WHERE address_id_group = %s and address_id in %s"

        async def fetch_chunk(group, chunk):
            chunk_result = await self.execute_async(
                currency, "transformed", query, [group, ValueSequence(chunk)]
            )
            return chunk_result.current_rows

        aws = [
            fetch_chunk(group, group_ids[i : i + 200])
            for group, group_ids in groups.items()
            for i in range(0, len(group_ids), 200)
        ]
        rows_by_id = {
            row["address_id"]: row
            for chunk_rows in await asyncio.gather(*aws)
            for row in chunk_rows
        }
        # An IN query returns rows in clustering order, not the cluster
        # membership paging order that concurrent_with_args preserved (input
        # params order); re-order back to it. Ids with no row (a data
        # inconsistency) are dropped, matching concurrent_with_args'
        # filter_empty default.
        result = [
            rows_by_id[address_id]
            for _group, address_id in params
            if address_id in rows_by_id
        ]

        return await self.finish_addresses(currency, result), to_hex(
            results.paging_state
        )

    async def list_neighbors(
        self,
        currency,
        id,
        is_outgoing,
        node_type: NodeType,
        targets,
        page,
        pagesize,
        include_neighbor_rows=True,
    ):
        pagesize = min(pagesize or SMALL_PAGE_SIZE, SMALL_PAGE_SIZE)

        orig_node_type = node_type
        orig_id = id
        if node_type == NodeType.ADDRESS:
            id = await self.get_address_id(currency, id)
            if id is None:
                # check if new address exists
                if await self.get_new_address(currency, orig_id):
                    return [], None
                raise AddressNotFoundException(currency, orig_id)

        elif node_type == NodeType.CLUSTER:
            id = int(id)
            if not is_representable_entity_id(id):
                return [], None
            if is_eth_like(currency):
                node_type = NodeType.ADDRESS
            else:
                id = await self._legacy_relations_cluster_id(currency, id)
                if id is None:
                    return [], None

        if is_outgoing:
            direction, this, that = ("outgoing", "src", "dst")
        else:
            direction, this, that = ("incoming", "dst", "src")

        id_group = self.get_id_group(currency, id)
        base_parameters = [id_group, id]
        has_targets = isinstance(targets, list)
        sec_condition = ""
        if is_eth_like(currency):
            secondary_id_group = await self.get_id_secondary_group_eth(
                currency, f"address_{direction}_relations", id_group
            )
            sec_in = self.sec_in(secondary_id_group)
            sec_condition = f" AND {this}_address_id_secondary_group in %s"
            base_parameters.append(sec_in)

        basequery = (
            f"SELECT * FROM {node_type}_{direction}_relations WHERE "
            f"{this}_{node_type}_id_group = %s AND "
            f"{this}_{node_type}_id = %s {sec_condition}"
        )
        params = base_parameters.copy()
        if has_targets:
            if len(targets) == 0:
                return None, None

            # Single-partition IN query with the full column selection: this
            # side of the relation (this_*_id) is fixed, so an IN clause on
            # the clustering column that_*_id is one round trip against one
            # partition — the previous id-only query plus one point read per
            # matched id was two round trips for no narrower a scan.
            query = basequery + f" AND {that}_{node_type}_id in %s"
            targets = ValueSequence(targets)
            params.append(targets)
        else:
            query = basequery
        fetch_size = min(pagesize or BIG_PAGE_SIZE, BIG_PAGE_SIZE)
        paging_state = page_from_hex(page)
        results = await self.execute_async(
            currency,
            "transformed",
            query,
            params,
            paging_state=paging_state,
            fetch_size=fetch_size,
        )
        paging_state = results.paging_state
        results = results.current_rows

        if orig_node_type == NodeType.CLUSTER and is_eth_like(currency):
            for neighbor in results:
                neighbor["address_id"] = neighbor[that + "_cluster_id"] = neighbor[
                    that + "_address_id"
                ]

        if orig_node_type == NodeType.ADDRESS and include_neighbor_rows:
            ids = [row[that + "_address_id"] for row in results]
            # Full rows, not just the address string: the service layer
            # builds each neighbor Address straight from these instead of
            # re-resolving the address string back to an id via the prefix
            # table and re-reading the same row (see
            # addresses_service.list_address_neighbors). Callers that only
            # need the relation row itself (the links edge pre-check reads
            # just no_transactions) pass include_neighbor_rows=False and
            # skip the address fetch and finishing entirely.
            addresses = await self.get_addresses_by_ids(
                currency, ids, address_only=False
            )

            if len(addresses) != len(ids):
                address_ids = [address["address"] for address in addresses]
                self.log_missing(address_ids, ids, node_type, query, params)

            # finish_addresses adds first/last tx, dirty status and balance —
            # the same work db.get_address() would do per neighbor, batched
            # here into one unbounded Cassandra fan-out instead of N serial
            # per-neighbor round trips.
            addresses = await self.finish_addresses(currency, addresses)

            # Key by address_id instead of zipping: get_addresses_by_ids drops
            # missing rows, so a positional zip would shift every subsequent
            # neighbor onto the wrong address string once one row is absent.
            addr_by_id = {a["address_id"]: a for a in addresses}
            for row in results:
                full = addr_by_id.get(row[that + "_address_id"])
                row[that + "_address"] = full["address"] if full is not None else None
                row[that + "_address_row"] = full

        field = "value" if is_eth_like(currency) else "estimated_value"
        for neighbor in results:
            neighbor["value"] = self.markup_currency(currency, neighbor[field])
            if "token_values" in neighbor and neighbor["token_values"] is not None:
                neighbor["token_values"] = {
                    k: self.markup_currency(currency, v)
                    for k, v in neighbor["token_values"].items()
                }

        if is_eth_like(currency):
            for row in results:
                row["address_id"] = row[that + "_address_id"]

        return results, to_hex(paging_state)

    @eth
    async def get_spending_txs(self, currency, tx_hash, io_index):
        if not self.parameters[currency]["tx_graph_available"]:
            # for value err msg is visible to the user.
            raise BadUserInputException(
                f"{currency} does not yet support transaction linking."
            )
        prefix = self.get_prefix_lengths(currency)
        try:
            tx_hash_bytes = bytearray.fromhex(tx_hash)
        except ValueError:
            raise BadUserInputException(
                f"{tx_hash} does not look like a valid transaction hash."
            )
        if isinstance(io_index, int):
            query = (
                "SELECT * from transaction_spending where "
                "spending_tx_prefix=%s and spending_tx_hash=%s "
                "and spending_input_index=%s"
            )
            params = [tx_hash[: prefix["tx"]], tx_hash_bytes, io_index]
        else:
            query = (
                "SELECT * from transaction_spending where "
                "spending_tx_prefix=%s and spending_tx_hash=%s"
            )
            params = [tx_hash[: prefix["tx"]], tx_hash_bytes]

        result = await self.execute_async(currency, "raw", query, params)
        return result

    async def get_spending_txs_eth(self, currency, tx_hash, io_index):
        # we raise a value error here,
        # that makes the error msg visible to the user.
        raise BadUserInputException(
            f"Currency {currency} does not support transaction level linking"
        )

    @eth
    async def get_spent_in_txs(self, currency, tx_hash, io_index):
        if not self.parameters[currency]["tx_graph_available"]:
            # for value err msg is visible to the user.
            raise BadUserInputException(
                f"{currency} does not yet support transaction linking."
            )
        prefix = self.get_prefix_lengths(currency)
        try:
            tx_hash_bytes = bytearray.fromhex(tx_hash)
        except ValueError:
            raise BadUserInputException(
                f"{tx_hash} does not look like a valid transaction hash."
            )
        if isinstance(io_index, int):
            query = (
                "SELECT * from transaction_spent_in where "
                "spent_tx_prefix=%s and spent_tx_hash=%s "
                "and spent_output_index=%s"
            )
            params = [tx_hash[: prefix["tx"]], tx_hash_bytes, io_index]
        else:
            query = (
                "SELECT * from transaction_spent_in where "
                "spent_tx_prefix=%s and spent_tx_hash=%s"
            )
            params = [tx_hash[: prefix["tx"]], tx_hash_bytes]

        result = await self.execute_async(currency, "raw", query, params)
        return result

    async def get_spent_in_txs_eth(self, currency, tx_hash, io_index):
        # we raise a value error here,
        # that makes the error msg visible to the user.
        raise BadUserInputException(
            f"Currency {currency} does not support transaction level linking"
        )

    @eth
    def get_tx(self, currency, tx_hash):
        return self.get_tx_by_hash(currency, tx_hash)

    @eth
    async def list_token_txs(self, currency, tx_hash, log_index=None, tx=None):
        return []

    async def list_token_txs_eth(self, currency, tx_hash, log_index=None, tx=None):
        if tx is None:
            tx = await self.get_tx(currency, tx_hash)
        return await self.fetch_token_transactions(currency, tx, log_index)

    async def fetch_token_transaction(self, currency, tx, log_index):
        r = await self.fetch_token_transactions(currency, tx, log_index)
        if len(r) != 1:
            raise NotFoundException(
                f"Found {len(r)} logs for token tx {tx['tx_hash']}:{log_index}"
            )
        return r[0]

    async def fetch_token_transactions(self, currency, tx, log_index=None):
        transfer_topic = bytes_from_hex(
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
        )
        token_tx_logs = await self.get_logs_in_block_eth(
            currency,
            tx["block_id"],
            topic=transfer_topic,
            log_index=log_index,
            tx_hash=tx["tx_hash"],
        )
        supported_tokens = {
            v["token_address"]: v
            for v in self.get_token_configuration(currency).values()
        }

        logs_to_decode = [
            tt
            for tt in token_tx_logs.current_rows
            if tt["address"] in supported_tokens and tt["tx_hash"] == tx["tx_hash"]
        ]
        decoded_token_txs = decode_logs_db(logs_to_decode)

        return [
            build_token_tx(
                supported_tokens[log["address"]]["currency_ticker"], tx, token_tx, log
            )
            for (token_tx, log) in decoded_token_txs
        ]

    async def fetch_transaction_trace(
        self, currency, tx, trace_index, get_first_trace=False
    ):
        r = await self.get_traces_in_block(
            currency, tx["block_id"], trace_index, tx_hash=tx["tx_hash"]
        )

        result = r.current_rows

        if len(result) == 0:
            raise NotFoundException(
                f"Found no traces in tx {tx['tx_hash'].hex()}:{trace_index}"
            )

        if get_first_trace:
            return result[0]

        if len(result) > 1:
            raise NotFoundException(
                f"Found {len(result)} traces in tx {tx['tx_hash'].hex()}:{trace_index}"
            )

        return result[0]

    async def fetch_transaction_traces(self, currency, tx):
        result = await self.get_traces_in_block(
            currency, tx["block_id"], tx_hash=tx["tx_hash"]
        )
        return result.current_rows

    async def fetch_transaction_logs(self, currency, tx):
        result = await self.get_logs_in_block_eth(
            currency, tx["block_id"], tx_hash=tx["tx_hash"]
        )
        return result.current_rows

    async def get_logs_in_block_eth(
        self, currency, block_id, topic=None, log_index=None, tx_hash=None
    ):
        block_group = self.get_block_id_group(currency, block_id)
        query = "SELECT * from log where block_id_group=%s and block_id=%s"
        params = [block_group, block_id]

        if topic is not None:
            query += " and topic0=%s"
            params += [topic]

        if log_index is not None:
            query += " and log_index=%s"
            params += [log_index]

        if tx_hash is not None:
            query += " and tx_hash=%s ALLOW FILTERING"
            params += [tx_hash]

        return await self.execute_async(currency, "raw", query, params)

    async def get_traces_in_block(
        self, currency, block_id, trace_index=None, tx_hash=None
    ):
        block_group = self.get_block_id_group(currency, block_id)
        query = "SELECT * from trace where block_id_group=%s and block_id=%s"

        params = [block_group, block_id]
        if trace_index is not None:
            query += " and trace_index=%s"
            params += [trace_index]

        if tx_hash is not None:
            query += " and tx_hash=%s ALLOW FILTERING"
            params += [tx_hash]

        return await self.execute_async(currency, "raw", query, params)

    async def list_matching_txs(
        self, currency, expression, limit, include_sub_tx_identifiers: bool = True
    ):
        expression_original = expression
        expression = expression.split("_")[0]

        prefix_lengths = self.get_prefix_lengths(currency)

        # should be safe for btc txs too. They are hex encoded.
        # so 0x should never be content. For base58 encoded btc adresses
        # there also no 0 character used.
        expression = strip_0x(expression)

        # fold unicode to ascii before prefix/bound derivation: pdf
        # copy-paste renders "ff" as the ligature "ﬀ" (U+FB00), which
        # casefold maps back; is_hexadecimal is ascii-strict
        expression = expression.casefold()

        if not is_hexadecimal(expression):
            return []

        if len(expression) < prefix_lengths["tx"]:
            return []

        expression_normalized = expression.lower()

        lower_bound = expression_normalized
        upper_bound = create_upper_bound(expression_normalized)

        if len(lower_bound) % 2 != 0:
            lower_bound = lower_bound + "0"

        if len(upper_bound) % 2 != 0:
            upper_bound = upper_bound + "0"

        if is_eth_like(currency):
            prefix = expression[: prefix_lengths["tx"]].upper()
            kind = "transformed"
            key = "transaction"

            query = (
                "SELECT transaction from transaction_ids_by_transaction_"
                "prefix WHERE transaction_prefix = %s AND transaction >= %s AND transaction < %s LIMIT %s"
            )
            params = [
                prefix,
                hex_str_to_bytes(strip_0x(lower_bound)),
                hex_str_to_bytes(strip_0x(upper_bound)),
                limit,
            ]
        else:
            prefix = expression[: prefix_lengths["tx"]]
            kind = "raw"
            key = "tx_hash"

            query = (
                "SELECT tx_hash from transaction_by_tx_prefix WHERE "
                "tx_prefix = %s AND tx_hash >= %s AND tx_hash < %s LIMIT %s"
            )
            params = [
                prefix,
                hex_str_to_bytes(strip_0x(lower_bound)),
                hex_str_to_bytes(strip_0x(upper_bound)),
                limit,
            ]

        result = await self.execute_async(currency, kind, query, params)

        if result.is_empty():
            return []

        # fix leading zero handling, assumption all tx hashes are 32 bytes
        # which is true for btc-like currencies and ethereum
        rows = [row[key].rjust(32, b"\x00").hex() for row in result.current_rows]

        # also show internal txs and token txs when only on result is left
        if is_eth_like(currency) and len(rows) == 1 and include_sub_tx_identifiers:
            tx_hash = bytearray.fromhex(rows[0])
            tx = await self.get_tx_by_hash_eth(currency, tx_hash)
            token_txs = await self.fetch_token_transactions(currency, tx)
            # smallest trace is equivalent to tx itself so filter
            traces = (await self.fetch_transaction_traces(currency, tx))[1:]
            ids = list(
                {get_tx_identifier(x, currency) for x in token_txs}.union(
                    {
                        get_tx_identifier(x, currency, type_overwrite="internal")
                        for x in traces
                    }
                )
            )
            rows.extend(ids)

        if "_" in expression_original:
            postfix = expression_original.split("_")[1]
            expression_normalized_postfix = (
                expression_normalized + "_" + postfix.lower()
            )
            len_expression = len(expression_normalized_postfix)
            rows = [
                row
                for row in rows
                if row[:len_expression].lower() == expression_normalized_postfix
            ]

        return rows

    def scrub_prefix(self, currency, expression):
        if isinstance(expression, bytes):
            # bytes_to_hex returns None for empty input (e.g. an invalid trx
            # address canonicalized with validate=False yields b""). Treat it as
            # an empty prefix so the lookup simply finds nothing instead of
            # raising AttributeError on None.startswith below.
            expression = bytes_to_hex(expression) or ""

        if currency == "eth":
            expression = strip_0x(expression)

        if currency not in self.parameters:
            raise NetworkNotFoundException(currency)

        bech32_prefix = self.parameters[currency].get("bech_32_prefix", "")
        return (
            expression[len(bech32_prefix) :]
            if expression.startswith(bech32_prefix)
            else expression
        )

    @eth
    async def list_txs_by_hashes(self, currency, hashes, include_token_txs=False):
        prefix = self.get_prefix_lengths(currency)
        params = [[hash[: prefix["tx"]], bytearray.fromhex(hash)] for hash in hashes]
        statement = (
            "SELECT tx_id from transaction_by_tx_prefix where "
            "tx_prefix=%s and tx_hash=%s"
        )
        result = await self.concurrent_with_args(currency, "raw", statement, params)
        ids = (tx["tx_id"] for tx in result)
        return await self.list_txs_by_ids(
            currency, ids, include_token_txs=include_token_txs
        )

    @eth
    async def get_tx_by_hash(self, currency, tx_hash: bytes):
        prefix = self.get_prefix_lengths(currency)
        try:
            params = [tx_hash[: prefix["tx"]], bytearray.fromhex(tx_hash)]
        except ValueError:
            raise BadUserInputException(
                f"{tx_hash} does not look like a valid transaction hash."
            )
        statement = (
            "SELECT tx_id from transaction_by_tx_prefix where "
            "tx_prefix=%s and tx_hash=%s"
        )
        result = await self.execute_async(currency, "raw", statement, params)
        result = one(result)
        if not result:
            raise TransactionNotFoundException(currency, tx_hash)
        result = await self.get_tx_by_id(currency, result["tx_id"])
        if not result:
            raise DBInconsistencyException(
                f"transaction {tx_hash} with id {result['tx_id']} in network "
                f"{currency} not found"
            )
        return result

    @eth
    async def list_txs_by_ids(
        self, currency, ids, filter_empty=True, include_token_txs=False
    ):
        params = ([self.get_tx_id_group(currency, id), id] for id in ids)
        statement = "SELECT * FROM transaction WHERE tx_id_group = %s and tx_id = %s"
        return await self.concurrent_with_args(
            currency, "raw", statement, params, filter_empty=filter_empty
        )

    @eth
    async def get_tx_by_id(self, currency, id):
        params = [self.get_tx_id_group(currency, id), id]
        statement = "SELECT * FROM transaction WHERE tx_id_group = %s and tx_id = %s"
        return (await self.execute_async(currency, "raw", statement, params)).one()

    async def _get_tx_summaries_by_ids(
        self, currency, tx_ids, columns="tx_id, tx_hash, block_id, timestamp"
    ):
        # Slim counterpart of get_tx_by_id for finish_address's first/last tx
        # lookups: UTXO transaction rows carry full inputs/outputs (hundreds
        # of entries for busy addresses) but only tx_hash/timestamp/block_id
        # are used to build a TxSummary, so project those columns and batch
        # same-partition ids into one IN query instead of one SELECT * per id.
        # tx_id is always included below since callers key the result dict by it.
        ids = {id for id in tx_ids if id is not None}
        if not ids:
            return {}
        groups = {}
        for id in ids:
            groups.setdefault(self.get_tx_id_group(currency, id), []).append(id)
        statement = (
            f"SELECT {columns} FROM transaction WHERE tx_id_group = %s AND tx_id in %s"
        )

        async def fetch_chunk(group, chunk):
            result = await self.execute_async(
                currency, "raw", statement, [group, ValueSequence(chunk)]
            )
            return result.current_rows

        aws = [
            fetch_chunk(group, group_ids[i : i + 200])
            for group, group_ids in groups.items()
            for i in range(0, len(group_ids), 200)
        ]
        rows = [row for chunk_rows in await asyncio.gather(*aws) for row in chunk_rows]
        return {row["tx_id"]: row for row in rows}

    async def finish_entities(self, currency, rows, with_txs=True):
        tx_summaries = await self._prefetch_tx_summaries(currency, rows, with_txs)
        root_addresses = await self._prefetch_root_addresses(currency, rows)
        aws = [
            self.finish_entity(
                currency,
                row,
                with_txs=with_txs,
                tx_summaries=tx_summaries,
                root_addresses=root_addresses,
            )
            for row in rows
        ]
        return await asyncio.gather(*aws)

    @eth
    async def finish_entity(
        self, currency, row, with_txs=True, tx_summaries=None, root_addresses=None
    ):
        if root_addresses is not None:
            # Batched prefetch from finish_entities: no per-row point read.
            row["root_address"] = root_addresses[row["cluster_id"]]
        else:
            a = await self.get_addresses_by_ids(
                currency, [row["cluster_id"]], address_only=True
            )
            row["root_address"] = a[0]["address"]
        return await self.finish_address(
            currency, row, with_txs, tx_summaries=tx_summaries
        )

    async def finish_entity_eth(
        self, currency, row, with_txs=True, tx_summaries=None, root_addresses=None
    ):
        row["root_address"] = row["address"]
        return await self.finish_address(currency, row, with_txs)

    async def finish_addresses(self, currency, rows, with_txs=True):
        tx_summaries = await self._prefetch_tx_summaries(currency, rows, with_txs)
        aws = [
            self.finish_address(
                currency, row, with_txs=with_txs, tx_summaries=tx_summaries
            )
            for row in rows
        ]
        return await asyncio.gather(*aws)

    async def _prefetch_tx_summaries(self, currency, rows, with_txs):
        # finish_address's eth path (finish_address_eth) uses a different
        # two-hop projected read and ignores this prefetch, so only collect
        # it for the UTXO path.
        if not with_txs or is_eth_like(currency):
            return None
        tx_ids = [id for row in rows for id in (row["first_tx_id"], row["last_tx_id"])]
        return await self._get_tx_summaries_by_ids(currency, tx_ids)

    async def _prefetch_root_addresses(self, currency, rows):
        # finish_entity_eth carries its root address on the row already
        # (entity == address for account-model chains), so only the
        # legacy/fresh cluster path needs this prefetch.
        if is_eth_like(currency):
            return None
        cluster_ids = [row["cluster_id"] for row in rows if "cluster_id" in row]
        return await self._get_root_addresses_by_ids(currency, cluster_ids)

    async def _get_root_addresses_by_ids(self, currency, address_ids):
        # finish_entity resolves each cluster's root address string (its
        # cluster_id doubles as the root address's address_id) via one point
        # read; batch that into grouped IN reads for the whole page, same
        # shape as _get_tx_summaries_by_ids.
        ids = {id for id in address_ids if id is not None}
        if not ids:
            return {}
        groups = {}
        for id in ids:
            groups.setdefault(self.get_id_group(currency, id), []).append(id)
        statement = (
            "SELECT address, address_id FROM address "
            "WHERE address_id_group = %s AND address_id in %s"
        )

        async def fetch_chunk(group, chunk):
            result = await self.execute_async(
                currency, "transformed", statement, [group, ValueSequence(chunk)]
            )
            return result.current_rows

        aws = [
            fetch_chunk(group, group_ids[i : i + 200])
            for group, group_ids in groups.items()
            for i in range(0, len(group_ids), 200)
        ]
        rows = [row for chunk_rows in await asyncio.gather(*aws) for row in chunk_rows]
        return {row["address_id"]: row["address"] for row in rows}

    @eth
    async def finish_address(self, currency, row, with_txs=True, tx_summaries=None):
        # Backstop for stats-pending fresh cluster rows that slipped past
        # synthesis: zero-fill instead of 500ing on values._fields.
        if row["total_received"] is None:
            row["total_received"] = self._zero_values(currency)
        if row["total_spent"] is None:
            row["total_spent"] = self._zero_values(currency)
        row["total_received"] = self.markup_currency(currency, row["total_received"])
        row["total_spent"] = self.markup_currency(currency, row["total_spent"])

        if not with_txs:
            await self.add_balance(currency, row)
            return row

        balance_task = self.add_balance(currency, row)

        async def _tx_summaries():
            # When the caller prefetched summaries (finish_addresses /
            # finish_entities), use those instead of issuing a read here.
            # Otherwise (the single-address path) fetch just the columns a
            # TxSummary needs via the same slim, batched helper the list
            # paths use — get_tx_by_id's `SELECT *` drags full inputs/
            # outputs across the wire for a busy UTXO tx just to keep three
            # scalars. An absent key means the tx is genuinely missing,
            # same as get_tx_by_id returning no row.
            if tx_summaries is not None:
                return tx_summaries
            return await self._get_tx_summaries_by_ids(
                currency, [row["first_tx_id"], row["last_tx_id"]]
            )

        summaries_task = _tx_summaries()

        has_address = "address" in row
        if has_address:
            dirty_task = self.is_address_dirty(currency, row["address"])
            results = await asyncio.gather(balance_task, summaries_task, dirty_task)
            summaries, is_dirty = results[1], results[2]
        else:
            results = await asyncio.gather(balance_task, summaries_task)
            summaries = results[1]

        tx1 = summaries.get(row["first_tx_id"])
        tx2 = summaries.get(row["last_tx_id"])

        if not tx1 or not tx2:
            raise DBInconsistencyException(
                f"first or last transaction not found as referenced by {row}"
            )

        row["first_tx"] = TxSummary(
            tx_hash=tx1["tx_hash"], timestamp=tx1["timestamp"], height=tx1["block_id"]
        )

        row["last_tx"] = TxSummary(
            tx_hash=tx2["tx_hash"], timestamp=tx2["timestamp"], height=tx2["block_id"]
        )

        if has_address:
            row["status"] = "dirty" if is_dirty else "clean"

        return row

    async def finish_address_eth(self, currency, row, with_txs=True, tx_summaries=None):
        row["cluster_id"] = row["address_id"]
        row["total_received"] = self.markup_currency(currency, row["total_received"])
        row["total_spent"] = self.markup_currency(currency, row["total_spent"])

        tr = row["total_tokens_received"]
        if tr is not None:
            row["total_tokens_received"] = {
                k: self.markup_currency(currency, v) for k, v in tr.items()
            }

        ts = row["total_tokens_spent"]
        if ts is not None:
            row["total_tokens_spent"] = {
                k: self.markup_currency(currency, v) for k, v in ts.items()
            }

        if not with_txs:
            await self.add_balance(currency, row)
            return row

        balance_task = self.add_balance(currency, row)
        dirty_task = self.is_address_dirty(currency, row["address"])

        # first_tx_id == -1 is the sentinel for "address has no transactions of
        # its own" (e.g. an account address that only paid a failed-tx gas fee, or
        # a coinbase/miner-reward-only address). Don't try to resolve it — that
        # would find nothing and trip the inconsistency guard below.
        if row["first_tx_id"] is None or row["first_tx_id"] == -1:
            _, is_dirty = await asyncio.gather(balance_task, dirty_task)
            row["first_tx"] = None
            row["last_tx"] = None
            row["status"] = "dirty" if is_dirty else "clean"
            return row

        tx_tasks = [
            self.get_tx_by_id(currency, id)
            for id in [row["first_tx_id"], row["last_tx_id"]]
        ]

        results = await asyncio.gather(balance_task, *tx_tasks, dirty_task)
        tx1, tx2, is_dirty = results[1], results[2], results[3]

        if not tx1 or not tx2:
            raise DBInconsistencyException(
                f"first or last transaction not found as referenced by {row}"
            )

        row["first_tx"] = TxSummary(
            tx_hash=tx1["tx_hash"],
            timestamp=tx1["block_timestamp"],
            height=tx1["block_id"],
        )

        row["last_tx"] = TxSummary(
            tx_hash=tx2["tx_hash"],
            timestamp=tx2["block_timestamp"],
            height=tx2["block_id"],
        )

        row["status"] = "dirty" if is_dirty else "clean"

        return row

    async def is_address_dirty(self, currency, address):
        if not self.parameters[currency]["use_delta_updater_v1"]:
            return False

        prefix = self.scrub_prefix(currency, address)
        if is_eth_like(currency):
            prefix = prefix.upper()
        prefix_length = self.get_prefix_lengths(currency)["address"]
        query = (
            "SELECT address FROM dirty_addresses "
            "WHERE address_prefix = %s AND address = %s"
        )
        try:
            result = await self.execute_async(
                currency, "transformed", query, [prefix[:prefix_length], address]
            )

            result = one(result)
            if result:
                return True
        except InvalidRequest as e:
            if "dirty_addresses" not in str(e):
                raise e

        return False

    @eth
    async def add_balance(self, currency, row):
        row["balance"] = row["total_received"].value - row["total_spent"].value

    async def add_balance_eth(self, currency, row):
        token_config = self.get_token_configuration(currency)
        token_currencies = list(token_config.keys())
        balance_currencies = [currency.upper()] + token_currencies

        balance_provider = self.get_balance_provider(currency)

        results = None
        if balance_provider is not None:
            # load balance from alternative provider.
            try:
                results = await balance_provider(currency, row["address"], token_config)
            except Exception as e:
                self.logger.warning(
                    f"Could not fetch balances over alternative provider: {e}"
                )

        if results is None:
            # load results from gs database. currency is a clustering column of
            # the balance table, so a single partition read returns every
            # currency's balance at once - no per-token query fan-out.
            if "address_id_group" not in row:
                row["address_id_group"] = self.get_id_group(currency, row["address_id"])
            query = (
                "SELECT currency, balance FROM balance "
                "WHERE address_id=%s AND address_id_group=%s"
            )
            balance_rows = await self.execute_async(
                currency,
                "transformed",
                query,
                [row["address_id"], row["address_id_group"]],
                autopaging=True,
            )
            by_currency = {r["currency"]: r for r in balance_rows.current_rows}
            results = {c: by_currency.get(c) for c in balance_currencies}

        if results[currency.upper()] is None:
            results[currency.upper()] = {
                "balance": row["total_received"].value - row["total_spent"].value
            }
        row["balance"] = results[currency.upper()]["balance"]

        if currency == "trx":
            # our self compute balances can get negative for now
            # since we have not implemented all special tx types
            # in our logic yet
            row["balance"] = max(row["balance"], 0)

        # TODO: Some accounts have negative balances, this does not make sense.
        # for now we cap with 0 in case of negative
        # Exp. for now is that we either lost some token txs somewhere or
        # the events do not represent all transfers
        # (e.g. the initial distribution) was hardcoded in the token contract
        # so no events exist. Future solution to have accurate balances
        # would be to query the node directly
        token_balances = {
            c: max(b["balance"], 0)
            for c, b in results.items()
            if c in token_config and b is not None
        }
        row["token_balances"] = None if len(token_balances) == 0 else token_balances

        # For unpegged tokens (no USD/EUR/ETH peg) the fiat value of a balance
        # comes from the latest fetched per-token rate; resolve them here so the
        # service layer can convert. Missing rate -> None -> zero fiat fallback.
        row["token_balance_rates"] = await self._resolve_token_balance_rates(
            currency, token_config, token_balances
        )

    async def _resolve_token_balance_rates(
        self, currency, token_config, token_balances
    ):
        def is_unpegged(cfg):
            peg = cfg["peg_currency"]
            return peg is None or (isinstance(peg, str) and peg.strip() == "")

        unpegged = [
            c
            for c in token_balances
            if c in token_config and is_unpegged(token_config[c])
        ]
        if not unpegged:
            return None
        rates = await asyncio.gather(
            *[self.get_latest_token_rate(currency, c) for c in unpegged]
        )
        resolved = {c: r for c, r in zip(unpegged, rates) if r is not None}
        return resolved or None

    # ETH Variants

    def scrub_prefix_eth(self, currency, expression):
        # remove 0x prefix
        expression = bytes_to_hex(expression)
        if expression.startswith("0x"):
            return expression[2:]
        else:
            return expression

    async def get_block_eth(self, currency, height):
        block_group = self.get_block_id_group(currency, height)
        query = "SELECT * FROM block WHERE block_id_group = %s and block_id = %s"
        return (
            await self.execute_async(currency, "raw", query, [block_group, height])
        ).one()

    # entity = address_id

    async def get_entity_eth(self, currency, entity):
        # mockup entity by address
        entity = int(entity)
        if not is_representable_entity_id(entity):
            return None
        id_group = self.get_id_group(currency, entity)
        query = "SELECT * FROM address WHERE address_id_group = %s AND address_id = %s"
        result = await self.execute_async(
            currency, "transformed", query, [id_group, entity]
        )
        result = one(result)
        if not result:
            return None

        entity = (await self.finish_entities(currency, [result]))[0]
        entity["cluster_id"] = entity["address_id"]
        entity["no_addresses"] = 1
        entity.pop("address", None)
        return entity

    async def list_entities_eth(
        self, currency, ids, page=None, pagesize=None, fields=["*"]
    ):
        fields = ["address_id" if i == "cluster_id" else i for i in fields]
        if "*" not in fields:
            fields += ["address_id", "address_id_group"]
        flds = ",".join(fields)
        query = f"SELECT {flds} FROM address"
        has_ids = isinstance(ids, list)
        if has_ids:
            query += " WHERE address_id_group = %s AND address_id = %s"
            params = [[self.get_id_group(currency, id), id] for id in ids]
            result = await self.concurrent_with_args(
                currency, "transformed", query, params
            )
            paging_state = None
        else:
            fetch_size = min(pagesize or SMALL_PAGE_SIZE, SMALL_PAGE_SIZE)
            result = await self.execute_async(
                currency,
                "transformed",
                query,
                paging_state=page_from_hex(page),
                fetch_size=fetch_size,
            )
            paging_state = result.paging_state
            result = result.current_rows

        with_txs = "*" in fields or "first_tx_id" in fields or "last_tx_id" in fields
        result = await self.finish_addresses(currency, result, with_txs)

        for address in result:
            address["cluster_id"] = address["address_id"]
            address["no_addresses"] = 1
        return result, to_hex(paging_state)

    async def get_address_entity_id_eth(self, currency, address):
        address_id = await self.get_address_id(currency, address)
        if address_id is None:
            raise AddressNotFoundException(currency, address, no_external_txs=True)
        return address_id

    async def get_id_secondary_group_eth(self, currency, table, id_group):
        column_prefix = ""
        if table == "address_incoming_relations":
            column_prefix = "dst_"
        elif table == "address_outgoing_relations":
            column_prefix = "src_"

        query = (
            f"SELECT max_secondary_id FROM {table}_"
            f"secondary_ids WHERE {column_prefix}address_id_group = %s"
        )
        result = (
            await self.execute_async(currency, "transformed", query, [id_group])
        ).one()
        return 0 if result is None else result["max_secondary_id"]

    async def list_address_txs_ordered(
        self,
        network: str,
        node_type: NodeType,
        id,
        tx_id_lower_bound: Optional[int],
        tx_id_upper_bound: Optional[int],
        is_outgoing: Optional[bool],
        include_assets: Sequence[Tuple[str, bool]],
        page: Optional[str],
        fetch_size: int,
        cols: Optional[Sequence[str]] = None,
        tx_ids: Optional[Sequence[Tuple[int, Optional[dict]]]] = None,
        ascending: bool = False,
    ) -> Tuple[Sequence[dict], List[Optional[str]]]:
        """Loads a address transactions in execution order
        it allows to only get out- or incoming transaction or only
        transactions of a certain asset (token), for a given address id

        Args:
            network (str): base currency / network
            node_type (str): NodeType (ADDRESS/CLUSTER)
            item_id (int): address/cluster id
            item_id_group (int): address/cluster id group
            tx_id_lower_bound (Optional[int]): tx id lower bound
            tx_id_upper_bound (Optional[int]): tx id upper bound
            is_outgoing (Optional[bool]): if True fetch only outgoing, if False
                fetch only incoming, if None fetch both directions
            include_assets (Sequence[Tuple[str, bool]]): a list of tuples with
                assets to include
            page (Optional[int]): a page id (tx id bound)
            fetch_size (int): how much to fetch per page
            cols (Optional[Sequence[str]], optional): which columns to select
                None means *
            tx_ids (Optional[Sequence[int]]): limit result to given tx_ids
            ascending (Optional[bool]): sort list ascending if True or
                descending if False
        """

        if node_type == NodeType.ADDRESS:
            data = await self.get_address_tx_range(network, id)
        elif node_type == NodeType.CLUSTER:
            data = await self.get_entity(network, id)
        else:
            raise BadUserInputException(
                f"Node type {node_type} not supported for address transactions"
            )

        first_tx = data.get("first_tx_id")
        last_tx = data.get("last_tx_id")

        def get_secondary_id_group_from_block(block):
            return block // self.parameters[network]["block_bucket_size_address_txs"]

        def secondary_id_from_tx_id(tx_id):
            block = get_block_from_tx_id(tx_id)
            return get_secondary_id_group_from_block(block)

        try:
            if is_eth_like(network) and tx_ids is None:
                (page, secondary_id, offset) = (
                    page.split(":") if page is not None else (None, None, None)
                )
                page = int(page) if page is not None else None
                secondary_id = int(secondary_id) if secondary_id is not None else None
                offset = int(offset) if offset is not None else None
            else:
                (page, offset) = page.split(":") if page is not None else (None, None)
                page = int(page) if page is not None else None
                offset = int(offset) if offset is not None else None
                secondary_id = None
        except ValueError:
            raise BadUserInputException(f"Page {page} is not in the correct format")

        if node_type == NodeType.ADDRESS:
            item_id, item_id_group = await self.get_address_id_id_group(network, id)
        else:
            if is_eth_like(network):
                node_type = NodeType.ADDRESS
                item_id = id
            else:
                item_id = await self._legacy_relations_cluster_id(network, int(id))
                if item_id is None:
                    return [], [], True
            item_id_group = self.get_id_group(network, item_id)

        item_id_secondary_group = [0]
        if is_eth_like(network):
            sec_max = await self.get_id_secondary_group_eth(
                network, "address_transactions", item_id_group
            )
            sec_min = 0

            # restrict to first and last tx
            sec_min = max(sec_min, secondary_id_from_tx_id(first_tx))
            sec_max = min(sec_max, secondary_id_from_tx_id(last_tx))

            # restrict to border tx_id parameters given
            if tx_id_lower_bound:
                sec_min = max(sec_min, secondary_id_from_tx_id(tx_id_lower_bound))
            if tx_id_upper_bound:
                sec_max = min(sec_max, secondary_id_from_tx_id(tx_id_upper_bound))

            if tx_ids is None:
                # For pagination, we only need the current secondary_id
                if secondary_id is not None:
                    item_id_secondary_group = [secondary_id]
                else:
                    # Start with the appropriate secondary_id based on sort order
                    item_id_secondary_group = [sec_max if not ascending else sec_min]
            else:
                item_id_secondary_group = list(range(sec_min, sec_max + 1))

        directions = [is_outgoing] if is_outgoing is not None else [False, True]
        results = []
        pages_results = []  # each result gets a page so we can truncate and still know the page
        finished = False

        # tx_ids entries may be (tx_id, tx_ref) or (tx_id, tx_ref, asset); a
        # per-tx asset narrows the probe to that asset instead of the whole
        # include_assets fan-out.
        tx_items = (
            [(t[0], t[1], t[2] if len(t) > 2 else None) for t in tx_ids]
            if tx_ids is not None
            else None
        )

        # Concurrent secondary-group scan window (eth-like history walks
        # only): starts at 1, doubles after every round that fails to fill
        # its batch, so sparse histories cross empty block buckets in
        # logarithmically many round trips.
        group_window = 1
        group_window_cap = max(1, self.tconfig.txs_secondary_group_scan_window)

        # Track the current secondary_id for eth-like networks
        current_secondary_id = (
            item_id_secondary_group[0]
            if is_eth_like(network) and tx_ids is None
            else None
        )

        """
            Keep retrieving pages until the demanded fetch_size is fulfilled
            or there are no more pages
        """
        while len(results) < fetch_size:
            fs_it = fetch_size - len(results)

            if not ascending:
                this_tx_id_lower_bound = tx_id_lower_bound
                if page is not None and tx_id_upper_bound is not None:
                    this_tx_id_upper_bound = min(page, tx_id_upper_bound)
                elif tx_id_upper_bound is not None:
                    this_tx_id_upper_bound = tx_id_upper_bound
                else:
                    this_tx_id_upper_bound = page
            else:
                this_tx_id_upper_bound = tx_id_upper_bound
                if page is not None and tx_id_lower_bound is not None:
                    this_tx_id_lower_bound = max(page, tx_id_lower_bound)
                elif tx_id_lower_bound is not None:
                    this_tx_id_lower_bound = tx_id_lower_bound
                else:
                    this_tx_id_lower_bound = page

            # prebuild useful conditions, dependent on loop
            has_upper_bound = this_tx_id_upper_bound is not None
            has_lower_bound = this_tx_id_lower_bound is not None

            fs_chunk = max(FETCH_SIZE_MIN, (offset or 0) + fetch_size)

            cql_stmt = build_select_address_txs_statement(
                network,
                node_type,
                cols,
                with_lower_bound=has_lower_bound,
                with_upper_bound=has_upper_bound,
                limit=fs_chunk if tx_ids is None else None,
                ascending=ascending,
                with_tx_id=(tx_ids is not None),
            )

            # Use a window of consecutive secondary ids for eth-like
            # networks without tx_ids, starting at current_secondary_id and
            # extending in scan direction (window size 1 = previous behavior)
            if is_eth_like(network) and tx_ids is None:
                # current_secondary_id comes from a client-supplied page token
                # and may sit outside [sec_min, sec_max] — a token minted before
                # the address's first tx, or against another data generation.
                # Clamping the window end to sec_min/sec_max alone would then
                # invert the range and yield an EMPTY window, which the scan
                # loop cannot advance from (it reads [-1] to pick the next
                # group). Keep current_secondary_id in the window so an
                # out-of-range token degrades to the window-size-1 behaviour:
                # the round finds nothing and the loop retires the group.
                if ascending:
                    window_end = min(current_secondary_id + group_window - 1, sec_max)
                    window_end = max(window_end, current_secondary_id)
                    current_item_id_secondary_group = list(
                        range(current_secondary_id, window_end + 1)
                    )
                else:
                    window_end = max(current_secondary_id - group_window + 1, sec_min)
                    window_end = min(window_end, current_secondary_id)
                    current_item_id_secondary_group = list(
                        range(current_secondary_id, window_end - 1, -1)
                    )
            else:
                current_item_id_secondary_group = item_id_secondary_group

            # We have create separate queries for the directions and assets
            # because in Cassandra the first cluster keys are direction and asset
            # If we did this in one query, we would potentially only progress in
            # one asset and direction wrt tx_id (our pagination key), but we want
            # results orderd by tx_id, so we need to query all directions and assets
            if self.parameters[network].get("block_bucket_size_address_txs") is None:
                params_chunks = [
                    {
                        "id": item_id,
                        "g_id": item_id_group,
                        "tx_id_lower_bound": this_tx_id_lower_bound,
                        "tx_id_upper_bound": this_tx_id_upper_bound,
                        "s_d_group": s_d_group,
                        "currency": asset,
                        "is_outgoing": is_outgoing,
                        "tx_id": tx_id,
                        "tx_ref": tx_ref,
                    }
                    for is_outgoing, s_d_group, (tx_id, tx_ref, tx_asset) in product(
                        directions,
                        current_item_id_secondary_group,
                        [(0, None, None)] if tx_items is None else tx_items,
                    )
                    for asset in (
                        [tx_asset] if tx_asset is not None else include_assets
                    )
                ]
            else:
                if tx_items:
                    secondary_ids_with_tx_ids = [
                        (
                            secondary_id_from_tx_id(tx_id),
                            tx_id,
                            tx_ref,
                            tx_asset,
                        )
                        for (tx_id, tx_ref, tx_asset) in tx_items
                    ]
                else:
                    secondary_ids_with_tx_ids = [
                        (
                            secondary_id,
                            0,
                            None,
                            None,
                        )
                        for secondary_id in current_item_id_secondary_group
                    ]
                params_chunks = [
                    {
                        "id": item_id,
                        "g_id": item_id_group,
                        "tx_id_lower_bound": this_tx_id_lower_bound,
                        "tx_id_upper_bound": this_tx_id_upper_bound,
                        "s_d_group": s_d_group,
                        "currency": asset,
                        "is_outgoing": is_outgoing,
                        "tx_id": tx_id,
                        "tx_ref": tx_ref,
                    }
                    for is_outgoing, (
                        s_d_group,
                        tx_id,
                        tx_ref,
                        tx_asset,
                    ) in product(
                        directions,
                        secondary_ids_with_tx_ids,
                    )
                    for asset in (
                        [tx_asset] if tx_asset is not None else include_assets
                    )
                ]

            def tx_ref_match(a, b):
                return a[0] == b[0] and a[1] == b[1]

            # Bound the number of in-flight statements: the tx_ids probe fans
            # out per (direction, asset, tx) and large candidate batches would
            # otherwise fire tens of thousands of concurrent point reads,
            # starving other requests on the shared session.
            probe_sem = asyncio.Semaphore(ADDRESS_TXS_SUBQUERY_CONCURRENCY)

            async def fetch(stmt, params):
                async with probe_sem:
                    res = await self.execute_async(
                        network, "transformed", cql_stmt, params
                    )
                if params["tx_ref"] is None:
                    return res

                # Filtering on tx_ids in the cql query was very slow once and killed
                # cassandra nodes the second time, so we filter here
                res.current_rows = [
                    r for r in res if tx_ref_match(r["tx_reference"], params["tx_ref"])
                ]
                return res

            tx_id_keys = "transaction_id" if is_eth_like(network) else "tx_id"

            probe_batch = (
                self.tconfig.links_probe_in_batch_size if tx_items is not None else 0
            )
            # Only batch when the round is too large to fly fully
            # concurrently as point reads: n parallel point reads spread
            # over all replicas and cost ~one round trip, while an IN(n)
            # runs its n slices serially on one coordinator. Batching wins
            # only once the statement count exceeds the concurrency window
            # (client-side per-query overhead then dominates).
            if (
                probe_batch
                and probe_batch > 1
                and len(params_chunks) > self.tconfig.links_probe_in_min_statements
            ):
                # Transport-level batching of the candidate probes: tx ids
                # sharing a (direction, partition, asset) become one
                # single-partition "transaction_id IN (...)" named-slice
                # query. The rows are redistributed into the exact
                # per-candidate sub-result lists (params_chunks order,
                # per-candidate tx_ref filter) that per-candidate point
                # probes would produce, so the merge below is unaffected.
                in_stmt = build_select_address_txs_statement(
                    network,
                    node_type,
                    cols,
                    with_lower_bound=has_lower_bound,
                    with_upper_bound=has_upper_bound,
                    limit=None,
                    ascending=ascending,
                    with_tx_id=True,
                    tx_id_in=True,
                )

                probe_groups = {}
                for p in params_chunks:
                    key = (p["is_outgoing"], p["s_d_group"], p["currency"])
                    # dict as ordered set: the same tx can be a candidate
                    # twice (distinct tx_references) but is fetched once
                    probe_groups.setdefault(key, {})[p["tx_id"]] = None

                async def fetch_batch(key, tx_id_chunk):
                    group_is_outgoing, s_d_group, asset = key
                    params = {
                        "id": item_id,
                        "g_id": item_id_group,
                        "s_d_group": s_d_group,
                        "currency": asset,
                        "is_outgoing": group_is_outgoing,
                        "tx_ids": ValueSequence(tx_id_chunk),
                    }
                    async with probe_sem:
                        res = await self.execute_async(
                            network, "transformed", in_stmt, params
                        )
                    return key, res.current_rows

                batch_aws = [
                    fetch_batch(key, tx_id_list[i : i + probe_batch])
                    for key, txs in probe_groups.items()
                    for tx_id_list in [list(txs)]
                    for i in range(0, len(tx_id_list), probe_batch)
                ]

                rows_by_candidate = {}
                for key, rows in await asyncio.gather(*batch_aws):
                    for r in rows:
                        rows_by_candidate.setdefault(key + (r[tx_id_keys],), []).append(
                            r
                        )

                sub_rows = []
                for p in params_chunks:
                    rows = rows_by_candidate.get(
                        (
                            p["is_outgoing"],
                            p["s_d_group"],
                            p["currency"],
                            p["tx_id"],
                        ),
                        [],
                    )
                    if p["tx_ref"] is not None:
                        rows = [
                            r
                            for r in rows
                            if tx_ref_match(r["tx_reference"], p["tx_ref"])
                        ]
                    sub_rows.append(rows)
            else:
                aws = [fetch(cql_stmt, p) for p in params_chunks]
                sub_rows = [r.current_rows for r in await asyncio.gather(*aws)]

            # collect and merge results
            more_results, more_pages, more_offsets = merge_address_txs_subquery_results(
                self.logger,
                sub_rows,
                ascending,
                fs_it,
                tx_id_keys,
                fetched_limit=fs_chunk,
                page=page,
                offset=offset,
            )

            page = more_pages[-1] if more_pages else None
            offset = more_offsets[-1] if more_offsets else None

            self.logger.debug(f"tx_id_lower_bound {tx_id_lower_bound}")
            self.logger.debug(f"tx_id_upper_bound {tx_id_upper_bound}")

            more_results_mask = [  # True or False to filter out results that are not in the range
                (tx_id_lower_bound is None or r[tx_id_keys] >= tx_id_lower_bound)
                and (tx_id_upper_bound is None or r[tx_id_keys] <= tx_id_upper_bound)
                for r in more_results
            ]
            more_results = [
                r for r, mask in zip(more_results, more_results_mask) if mask
            ]
            more_pages = [p for p, mask in zip(more_pages, more_results_mask) if mask]
            more_offsets = [
                o for o, mask in zip(more_offsets, more_results_mask) if mask
            ]

            self.logger.debug(f"list tx ordered page {page}:{offset}")
            self.logger.debug(f"more_results len {len(more_results)}")

            results.extend(more_results)

            if tx_ids:
                # tx_ids case - no pagination needed
                break

            def get_next_secondary_id(
                current_secondary_id, ascending, sec_min, sec_max
            ):
                if not ascending:
                    next_secondary_id = current_secondary_id - 1
                    if next_secondary_id < sec_min:
                        return None
                    return next_secondary_id
                else:
                    next_secondary_id = current_secondary_id + 1
                    if next_secondary_id > sec_max:
                        return None
                    return next_secondary_id

            if is_eth_like(network):
                # a row's secondary group is derived from its own tx id, so
                # tokens stay correct when a round spans multiple groups
                more_pages_results = [
                    f"{page}:{secondary_id_from_tx_id(page)}:{offset}"
                    if page is not None
                    else None
                    for page, offset in zip(more_pages, more_offsets)
                ]
            else:
                more_pages_results = [
                    f"{page}:{offset}" if page is not None else None
                    for page, offset in zip(more_pages, more_offsets)
                ]

            pages_results.extend(more_pages_results)

            if is_eth_like(network):
                # widen the scan window after a round that could not fill
                # its batch (sparse region), reset it in dense regions
                if len(more_results) < fs_it:
                    group_window = min(group_window * 2, group_window_cap)
                else:
                    group_window = 1

            if page is None:
                # The whole fetched secondary group window is exhausted
                if is_eth_like(network):
                    current_secondary_id = get_next_secondary_id(
                        current_item_id_secondary_group[-1],
                        ascending,
                        sec_min,
                        sec_max,
                    )
                    if current_secondary_id is None:
                        finished = True
                        break

                    offset = None
                else:
                    # No more data expected for non-eth networks
                    finished = True
                    break
            elif is_eth_like(network):
                # resume inside the group that produced the border row; rows
                # past it (including ones in later window groups) are
                # refetched next round bounded by the page tx id
                current_secondary_id = secondary_id_from_tx_id(page)

        return results, pages_results, finished

    async def list_txs_by_node_type_eth(
        self,
        currency,
        node_type,
        address,
        direction,
        min_height=None,
        max_height=None,
        order=None,
        token_currency=None,
        page=None,
        pagesize=None,
    ):
        ascending = order == "asc"

        if direction is not None and direction not in ["in", "out"]:
            raise BadUserInputException(
                f"Direction {direction} not supported, use 'in' or 'out' or None for both"
            )

        if node_type == NodeType.CLUSTER:
            node_type = NodeType.ADDRESS
            address = await self.get_address_by_address_id(currency, address)

        is_outgoing = direction == "out" if direction is not None else None

        if not token_currency:
            # Bound the per-token query fan-out to the tokens this address
            # actually used (direction-aware), instead of every supported token.
            token_config = self.get_token_configuration(currency)
            address_assets = await self.get_address_token_assets(
                currency, address, is_outgoing
            )
            self._warn_unconfigured_tokens(
                currency, token_config.keys(), address_assets, f"address {address}"
            )
            if self.tconfig.fanout_bounding_and_links_precheck_enabled:
                include_assets = [a for a in token_config.keys() if a in address_assets]
            else:
                include_assets = list(token_config.keys())
            include_assets.append(currency.upper())
        else:
            include_assets = [token_currency.upper()]

        first_tx_id, upper_bound = await self.resolve_tx_id_range_by_block(
            currency, min_height, max_height
        )

        fetch_size = min(pagesize or BIG_PAGE_SIZE, BIG_PAGE_SIZE)

        results, paging_states, finished = await self.list_address_txs_ordered(
            network=currency,
            node_type=node_type,
            id=address,
            tx_id_lower_bound=first_tx_id,
            tx_id_upper_bound=upper_bound,
            is_outgoing=is_outgoing,
            include_assets=include_assets,
            ascending=ascending,
            page=page,
            fetch_size=fetch_size,
        )
        paging_state = paging_states[-1] if paging_states and not finished else None

        results = await self.normalize_address_transactions(
            currency,
            results,
            ignore_traces_not_found=self.tconfig.ignore_traces_not_found_in_list_txs,
        )

        for row in results:
            self._verify_address_in_tx_eth(currency, address, row)
            row["value"] *= -1 if row["is_outgoing"] else 1

        return results, str(paging_state) if paging_state is not None else None

    async def normalize_address_transactions(
        self, currency, txs, ignore_traces_not_found=False
    ):
        use_legacy_log_index = self.parameters[currency]["use_legacy_log_index"]

        tx_ids = list({tx["transaction_id"] for tx in txs})

        full_txs = {
            tx_id: tx_row
            for tx_id, tx_row in zip(
                tx_ids, await self.list_txs_by_ids(currency, tx_ids)
            )
        }

        # the resolver must return one row per requested (unique) tx id.
        # Note: len(txs) can exceed len(tx_ids) when one tx contributes
        # several rows to a page (e.g. multiple token transfers / traces in
        # the same tx), so validate against the deduped id set, not row count.
        if self.tconfig.strict_data_validation:
            assert len(full_txs) == len(tx_ids), (
                f"Expected {len(tx_ids)} results, got {len(full_txs)}."
            )

        async def _normalize_one(addr_tx):
            # fix log index field with new tx_refstruct
            if not use_legacy_log_index:
                addr_tx["log_index"] = addr_tx["tx_reference"].log_index
                addr_tx["trace_index"] = addr_tx["tx_reference"].trace_index

            full_tx = full_txs[addr_tx["transaction_id"]]
            if full_tx is None:
                # tx id not yet resolvable to a hash (delta-updater in-flight,
                # see list_txs_by_ids_eth); drop the row instead of failing
                addr_tx["error"] = "transaction not yet resolvable to a hash"
                return
            contract_creation = full_tx.get("contract_creation", None)

            addr_tx["contract_creation"] = contract_creation

            if addr_tx["log_index"] is not None:
                token_tx = await self.fetch_token_transaction(
                    currency, full_tx, addr_tx["log_index"]
                )

                addr_tx["to_address"] = token_tx["to_address"]
                addr_tx["from_address"] = token_tx["from_address"]
                addr_tx["currency"] = token_tx["currency"]
                addr_tx["token_tx_id"] = addr_tx["log_index"]
                addr_tx["type"] = "erc20"
                addr_tx["contract_creation"] = False
                value = token_tx["value"]

            elif currency == "trx" and addr_tx["trace_index"] is not None:
                try:
                    trace = await self.fetch_transaction_trace(
                        currency, full_tx, addr_tx["trace_index"]
                    )
                except NotFoundException as e:
                    if not ignore_traces_not_found:
                        raise e
                    self.logger.error(
                        f"Trace index {addr_tx['trace_index']} for tx "
                        f"{full_tx['tx_hash'].hex()} not found"
                    )
                    addr_tx["error"] = e

                if "error" not in addr_tx:
                    addr_tx["from_address"] = trace["caller_address"]
                    addr_tx["to_address"] = (
                        replace_tron_dummy_address_with_valid_null_address(
                            trace["transferto_address"]
                        )
                    )
                    addr_tx["type"] = "internal"
                    value = trace["call_value"]
                else:
                    value = 0
                    addr_tx["type"] = "Error"
            elif currency == "eth" and addr_tx["trace_index"] is not None:
                try:
                    trace = await self.fetch_transaction_trace(
                        currency, full_tx, addr_tx["trace_index"]
                    )
                except NotFoundException as e:
                    #### TODO: remove again after data consistency is fixes
                    #### issue arose since erigon returned different number of traces switching from on version to another.

                    if not ignore_traces_not_found:
                        raise e
                    self.logger.error(
                        f"Trace index {addr_tx['trace_index']} for tx "
                        f"{full_tx['tx_hash'].hex()} not found"
                    )
                    addr_tx["error"] = e

                if "error" not in addr_tx:
                    addr_tx["from_address"] = trace["from_address"]
                    addr_tx["to_address"] = trace["to_address"]
                    is_external = (
                        trace["trace_address"] is None
                        or trace["trace_address"].strip() == ""
                    )

                    # if they are the same, then we know it is external
                    if is_external:
                        addr_tx["type"] = "external"
                    else:
                        addr_tx["type"] = "internal"

                    addr_tx["contract_creation"] = trace["trace_type"] == "create"
                    addr_tx["input"] = trace["input"]
                    addr_tx["input_parsed"] = parse_function_call(
                        trace["input"], function_call_signatures
                    )
                    value = trace["value"]
                else:
                    value = 0
                    addr_tx["type"] = "Error"
            else:
                addr_tx["to_address"] = full_tx["to_address"]
                addr_tx["from_address"] = full_tx["from_address"]
                addr_tx["currency"] = currency
                addr_tx["type"] = "external"
                addr_tx["input"] = full_tx["input"]
                addr_tx["input_parsed"] = parse_function_call(
                    full_tx["input"], function_call_signatures
                )
                value = full_tx["value"]

            addr_tx["tx_hash"] = full_tx["tx_hash"]
            addr_tx["height"] = full_tx["block_id"]

            addr_tx["timestamp"] = full_tx["block_timestamp"]
            addr_tx["value"] = value
            addr_tx.pop("log_index")

            if "error" not in addr_tx and addr_tx["type"] == "external":
                # do we need to use effective gas price here?
                addr_tx["fee"] = account_calc_tx_fee(full_tx)

            await self.fix_timestamp(
                currency, addr_tx, timestamp_col="timestamp", block_id_col="height"
            )

        # Process rows concurrently (bounded) rather than one sequential round-trip
        # per row: this hot endpoint issued up to `pagesize` serial trace/log/
        # timestamp lookups per page. Each row mutates only its own dict and
        # `full_txs` is read-only, so ordering is preserved and results identical.
        # A row that raises (e.g. trace-not-found without ignore) still propagates
        # via gather, exactly as the sequential loop did.
        sem = asyncio.Semaphore(MAX_ROW_LOOKUP_CONCURRENCY)

        async def _bounded(addr_tx):
            async with sem:
                await _normalize_one(addr_tx)

        await asyncio.gather(*(_bounded(addr_tx) for addr_tx in txs))

        await self._attach_token_tx_rates(currency, txs)
        return [tx for tx in txs if "error" not in tx]  # remove errored txs

    async def _check_unresolvable_tx_ids_tolerable(self, currency, missing_ids):
        """Decide if tx ids missing in transaction_ids_by_transaction_id_group
        are tolerable or a real inconsistency.

        While the delta-updater persists a batch, its data writes are sharded
        without cross-table ordering, so address_transactions rows can become
        visible before the corresponding tx-id mapping. Summary statistics are
        only committed after all data writes, therefore such in-flight txs
        always lie in blocks above the last committed block. Misses at or
        below it cannot be that race and raise instead of being masked.
        """
        stats = await self.get_currency_statistics(currency)
        last_committed_block = stats["no_blocks"] - 1 if stats else -1
        stale = [
            id for id in missing_ids if get_block_from_tx_id(id) <= last_committed_block
        ]
        if stale:
            raise DBInconsistencyException(
                f"transaction ids {stale} in network {currency} not found in "
                "transaction_ids_by_transaction_id_group although at or below "
                f"the last committed block {last_committed_block}"
            )
        self.logger.warning(
            f"Dropping {len(missing_ids)} txs of network {currency} not yet "
            f"resolvable to hashes (ids {missing_ids}): above last committed "
            f"block {last_committed_block}, delta-updater presumably in-flight."
        )

    async def _attach_token_tx_rates(self, currency, txs):
        """Attach per-tx fetched fiat rates for unpegged token transfers.

        Resolves get_token_rate(asset, block) for the distinct (asset, block)
        pairs of unpegged erc20 rows (bounded by page size, not the token set)
        and stores the labeled rate on each row for the service layer to price.
        """
        token_config = self.get_token_configuration(currency)
        if not token_config:
            return

        def is_unpegged(ticker):
            cfg = token_config.get(ticker) or token_config.get(ticker.upper())
            if cfg is None:
                return False
            peg = cfg["peg_currency"]
            return peg is None or (isinstance(peg, str) and peg.strip() == "")

        pairs = {
            (tx["currency"], tx["height"])
            for tx in txs
            if tx.get("type") == "erc20" and is_unpegged(tx.get("currency"))
        }
        if not pairs:
            return
        pairs = list(pairs)
        rates = await asyncio.gather(
            *[self.get_token_rate(currency, asset, block) for asset, block in pairs]
        )
        rate_map = {p: r for p, r in zip(pairs, rates)}
        for tx in txs:
            if tx.get("type") == "erc20":
                tx["token_rate"] = rate_map.get((tx["currency"], tx["height"]))

    async def list_txs_by_ids_eth(self, currency, ids, include_token_txs=False):
        ids = list(ids)
        params = [[self.get_tx_id_group(currency, id), id] for id in ids]
        statement = (
            "SELECT transaction from transaction_ids_by_transaction_id_group"
            " where transaction_id_group = %s and transaction_id = %s"
        )
        result = await self.concurrent_with_args(
            currency, "transformed", statement, params, filter_empty=False
        )

        any_missing = any(row is None for row in result)
        if any_missing:
            missing_ids = [id for id, row in zip(ids, result) if row is None]
            await self._check_unresolvable_tx_ids_tolerable(currency, missing_ids)

        found = await self.list_txs_by_hashes(
            currency,
            [row["transaction"] for row in result if row is not None],
            include_token_txs=include_token_txs,
        )
        if not any_missing or include_token_txs:
            # with include_token_txs the result interleaves token txs and is
            # never positionally aligned with ids, so missing ids are dropped
            return found
        # keep the result aligned with ids: None placeholder per missing id
        found_iter = iter(found)
        return [None if row is None else next(found_iter) for row in result]

    async def get_tx_by_id_eth(self, currency, id):
        params = [self.get_tx_id_group(currency, id), id]
        statement = (
            "SELECT transaction from transaction_ids_by_transaction_id_group"
            " where transaction_id_group = %s and transaction_id = %s"
        )
        result = await self.execute_async(currency, "transformed", statement, params)
        result = one(result)
        if not result:
            return None
        try:
            return await self.get_tx_by_hash_eth(currency, result["transaction"])
        except TransactionNotFoundException:
            raise DBInconsistencyException(
                f"transaction {bytes_to_hex(result['transaction'])} "
                f"with id {id} in network {currency} not found')"
            )

    async def list_txs_by_hashes_eth(self, currency, hashes, include_token_txs=False):
        prefix = self.get_prefix_lengths(currency)
        params = [[hash.hex()[: prefix["tx"]], hash] for hash in hashes]
        statement = (
            "SELECT tx_hash, block_id, block_timestamp, value, "
            "from_address, to_address, receipt_contract_address, input, transaction_type, "
            "receipt_gas_used, gas_price, receipt_effective_gas_price from "
            "transaction where tx_hash_prefix=%s and tx_hash=%s"
        )
        result = await self.concurrent_with_args(
            currency, "raw", statement, params, filter_empty=False
        )
        missing_hashes = [
            hash_.hex() for hash_, value in zip(hashes, result) if value is None
        ]
        assert len(missing_hashes) == 0, (
            f"Expected {len(hashes)} results, got {len(result)}. Missing hashes: {missing_hashes}"
        )

        result_with_tokens = []
        for row in result:
            to_address = row["to_address"]
            row["type"] = "external"
            if to_address is None:
                # this is a contract creation transaction
                # set recipient to newly created contract
                # and mark tx as creation
                row["to_address"] = row["receipt_contract_address"]
                row["contract_creation"] = True
            else:
                # normal transaction
                row["to_address"] = to_address
                # result['contract_creation'] = False

            row["input_parsed"] = parse_function_call(
                row["input"], function_call_signatures
            )
            row["fee"] = account_calc_tx_fee(row)

            if (
                currency == "trx"
                and row.get("transaction_type") == 13
                and row["from_address"] is None
            ):
                row["from_address"] = row["to_address"]

            result_with_tokens.append(row)
            if include_token_txs:
                token_txs = await self.fetch_token_transactions(currency, row)
                for ttx in token_txs:
                    ttx["type"] = "erc20"
                    result_with_tokens.append(ttx)

        return result_with_tokens

    async def get_tx_by_hash_eth(self, currency, tx_hash):
        prefix = self.get_prefix_lengths(currency)
        try:
            params = [tx_hash.hex()[: prefix["tx"]], tx_hash]
        except ValueError:
            raise BadUserInputException(
                f"{tx_hash} does not look like a valid transaction hash."
            )
        statement = (
            "SELECT tx_hash, block_id, block_timestamp, value, "
            "from_address, to_address, receipt_contract_address, input, transaction_type, "
            "receipt_gas_used, gas_price, receipt_effective_gas_price from "
            "transaction where tx_hash_prefix=%s and tx_hash=%s"
        )

        result = await self.execute_async(currency, "raw", statement, params)
        result = one(result)

        if not result:
            raise TransactionNotFoundException(currency, tx_hash)

        await self.fix_timestamp(currency, result)

        to_address = result["to_address"]
        if to_address is None:
            # this is a contract creation transaction
            # set recipient to newly created contract and mark tx as creation
            result["to_address"] = result["receipt_contract_address"]
            result["contract_creation"] = True
        else:
            # normal transaction
            result["to_address"] = to_address
            # result['contract_creation'] = False

        result["input_parsed"] = parse_function_call(
            result["input"], function_call_signatures
        )

        if (
            currency == "trx"
            and result.get("transaction_type") == 13
            and result["from_address"] is None
        ):
            result["from_address"] = result["to_address"]

        result["fee"] = account_calc_tx_fee(result)

        return result

    def get_tx_eth(self, currency, tx_hash: str):
        return self.get_tx_by_hash(currency, tx_hash_from_hex(tx_hash))

    async def list_entity_addresses_eth(
        self, currency, entity, page=None, pagesize=None
    ):
        if not is_representable_entity_id(int(entity)):
            return [], None
        addresses = await self.get_addresses_by_ids(currency, [entity])
        return await self.finish_addresses(currency, addresses), None

    async def get_cross_chain_pubkey_related_addresses(
        self, address: str, currency: Optional[str] = None, only_existing: bool = True
    ) -> List[Any]:
        if currency is not None and currency not in self.parameters:
            raise NetworkNotFoundException(currency)

        active_networks = self.parameters.keys()

        if not self.get_cross_chain_pubkey_related_addresses_available:
            return []

        # The queried address may be present in more than one configured pubkey
        # keyspace (e.g. the new pubkey_v2 plus the legacy pubkey, which still
        # holds keys the new pipeline cannot reproduce such as doge-sourced ones).
        # Look it up in each and collect the distinct pubkey blobs.
        keys = []
        seen_keys = set()
        for keyspace in self.cross_chain_pubkey_keyspaces:
            row = one(
                await self.execute_async_core(
                    f"SELECT pubkey FROM {keyspace}.pubkey_by_address WHERE address = ?",
                    {"address": address},
                )
            )
            if row is None or row["pubkey"] is None:
                continue
            key = row["pubkey"]
            kb = bytes(key)
            if kb in seen_keys:
                continue
            seen_keys.add(kb)
            keys.append(key)

        if not keys:
            return []

        # Derive every pubkey to addresses and union the rows. Two things can
        # produce different strings for the *same* graph node:
        #   * different encodings of the same key (legacy uncompressed vs new
        #     compressed) resolve to the same addresses, and
        #   * BCH is derived in the modern ``bitcoincash:`` CashAddr encoding,
        #     while the rest of the graph keys BCH addresses by their legacy
        #     base58 form (the materialised dataset still holds CashAddr rows).
        # Normalise every derived address to its canonical user form (a no-op
        # for networks already in canonical form; CashAddr -> legacy base58 for
        # BCH) and dedupe on (currency, address) so the two encodings collapse
        # to a single node instead of surfacing as duplicates.
        result = []
        seen_rows = set()
        for key in keys:
            addresses = convert_pubkey_to_addresses(
                key.hex(), currencies=active_networks
            )
            for cur, addressesInC in addresses.items():
                for addr_type, addr in addressesInC.items():
                    if addr_type == "error":
                        continue
                    norm_addr = address_to_user_format(
                        cur, cannonicalize_address(cur, addr)
                    )
                    dedup = (cur, norm_addr)
                    if dedup in seen_rows:
                        continue
                    seen_rows.add(dedup)
                    result.append(
                        {
                            "address": norm_addr,
                            "type": addr_type,
                            "currency": cur,
                            "pubkey": key,
                        }
                    )

        async def try_get_address(currency, address):
            try:
                return await self.get_address(currency, address)
            except AddressNotFoundException:
                return None

        if only_existing:
            requests = [
                try_get_address(
                    x["currency"],
                    cannonicalize_address(x["currency"], x["address"]),
                )
                for x in result
            ]
            addresses = await asyncio.gather(*requests)

            return [
                address for address, req in zip(result, addresses) if req is not None
            ]
        else:
            return result

    def markup_values(self, currency, fiat_values):
        values = []
        fcurs = self.parameters[currency]["fiat_currencies"]

        if fiat_values is None:
            fiat_values = [0.0 for _ in fcurs]

        for fiat, curr in zip(fiat_values, fcurs):
            values.append({"code": curr.lower(), "value": fiat})
        return values

    def markup_currency(self, currency, values):
        Values = namedtuple("Values", values._fields)
        values = values._asdict()
        values["fiat_values"] = self.markup_values(currency, values["fiat_values"])
        return Values(**values)

    def markup_rates(self, currency, row):
        row["rates"] = self.markup_values(currency, row["fiat_values"])
        return row

    def sec_in(self, id):
        return ValueSequence(range(0, id + 1))

    def log_missing(self, ids1, ids2, node_type, query, params):
        missing = []
        for id in ids2:
            if id not in ids1:
                missing.append(id)
        self.logger.critical(
            f"nodes existing in `{query}` {params} but not "
            f"in {node_type} table: {missing}"
        )
