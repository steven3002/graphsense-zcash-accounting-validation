# -*- coding: utf-8 -*-
# flake8: noqa: T201
from typing import Optional

import numpy as np
from cassandra.auth import PlainTextAuthProvider
from cassandra.cluster import Cluster
from cassandra.concurrent import execute_concurrent_with_args
from cassandra.query import dict_factory
from pandas import DataFrame
from pandas import pandas as pd
from tenacity import (
    before_sleep_log,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
)
from tenacity.wait import wait_exponential

from cassandra import InvalidRequest

from graphsenselib.utils.cassandra import split_nodes_and_port
from graphsenselib.utils.tron import tron_address_to_evm, evm_to_tron_address_string
from graphsenselib.utils.rest_utils import is_eth_like
from graphsenselib.db.state import FRESH_CLUSTERING_ACTIVE_KEY, STATE_TABLE
import logging

logger = logging.getLogger(__name__)


def _cluster_id_query(fresh: bool) -> str:
    """address_id -> cluster_id lookup for one clustering regime.

    Fresh: membership lives in ``fresh_address_cluster`` (same
    ``(address_id_group, address_id)`` key as ``address``). Legacy: the Scala
    ``address.cluster_id`` column.
    """
    if fresh:
        return (
            "SELECT address_id, cluster_id "
            "FROM fresh_address_cluster WHERE address_id_group=? and address_id=?"
        )
    return (
        "SELECT address_id, cluster_id "
        "FROM address WHERE address_id_group=? and address_id=?"
    )


def _cluster_stats_query(fresh: bool) -> str:
    """cluster_id -> no_addresses lookup for one clustering regime.

    Fresh: ``fresh_cluster_stats`` (only ``no_addresses`` is needed downstream).
    Legacy: the Scala ``cluster`` table.
    """
    if fresh:
        return (
            "SELECT cluster_id, no_addresses FROM fresh_cluster_stats "
            "WHERE cluster_id_group=? and cluster_id=?"
        )
    return "SELECT * FROM cluster WHERE cluster_id_group=? and cluster_id=?"


def try_convert_tron_to_eth(x):
    try:
        if x.startswith("0x"):
            return x
        return eth_address_to_hex_str(tron_address_to_evm(x))
    except Exception as e:
        logger.warning(f"Can't convert address {x} to eth format; {e}")
        return None


def try_convert_to_tron(x):
    try:
        if x is None:
            return None
        else:
            return evm_to_tron_address_string(eth_address_to_hex_str(x))
    except Exception as e:
        logger.warning(f"Can't convert address {x} to tron format; {e}")
        return None


def eth_address_to_hex(address):
    if type(address) is bytes:
        return address
    return "0x" + address.hex()


def eth_address_to_hex_str(address):
    return "0x" + address.hex()


def eth_address_from_hex(address):
    # eth addresses are case insensitive
    try:
        b = bytes.fromhex(address[2:].lower())
    except Exception as e:
        logger.warning(f"can't convert to hex {address}; {e}")
        return None
    return b


_CONCURRENCY = 100
_MAX_QUERY_EXECUTION_ATTEMPTS = 3


class QueryExecutionError(Exception):
    pass


class GraphSense(object):
    def __init__(
        self,
        hosts: list,
        ks_map: dict,
        username: Optional[str] = None,
        password: Optional[str] = None,
    ):
        # Accept "host:port" entries, as cassandra_nodes does everywhere else.
        self.hosts, self.port = split_nodes_and_port(hosts)
        self.ks_map = ks_map
        self._fresh_network_cache = {}

        auth_provider = None
        if username is not None:
            auth_provider = PlainTextAuthProvider(username=username, password=password)

        self.cluster = Cluster(self.hosts, port=self.port, auth_provider=auth_provider)
        self.session = self.cluster.connect()
        self.session.row_factory = dict_factory

    def close(self):
        self.cluster.shutdown()
        logger.info(f"Disconnected from {self.hosts}")

    @retry(
        retry=retry_if_exception_type(QueryExecutionError),
        wait=wait_exponential(multiplier=0.2, min=0.2, max=2),
        stop=stop_after_attempt(_MAX_QUERY_EXECUTION_ATTEMPTS),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True,
    )
    def _execute_query_with_retry(self, statement, parameters):
        results = execute_concurrent_with_args(
            self.session, statement, parameters, concurrency=_CONCURRENCY
        )

        failed_results = []
        all_results = []
        for success, result in results:
            if not success:
                failed_results.append(result)
                continue

            for row in result:
                all_results.append(row)

        if failed_results:
            first_error = failed_results[0]
            raise QueryExecutionError(
                f"{len(failed_results)} statement(s) failed; first error: {first_error}"
            )

        return all_results

    def _execute_query(self, statement, parameters):
        """Generic query execution"""
        all_results = self._execute_query_with_retry(statement, list(parameters))
        return pd.DataFrame.from_dict(all_results)

    def contains_keyspace_mapping(self, network: str) -> bool:
        return network in self.ks_map

    def is_fresh_network(self, network: str) -> bool:
        """Whether the network's transformed keyspace runs fresh clustering.

        The clustering bootstrap writes the ``fresh_clustering_active`` row
        into the keyspace's ``state`` table as its final step; that marker —
        not table existence (migrations create the fresh tables empty
        everywhere) — signals that the fresh membership tables are
        authoritative. A missing ``state`` table (pre-migration keyspace)
        counts as inactive. Mirrors
        ``db.analytics.TransformedDb.is_fresh_clustering_active``.
        """
        if is_eth_like(network) or not self.contains_keyspace_mapping(network):
            return False
        cached = self._fresh_network_cache.get(network)
        if cached is not None:
            return cached
        keyspace = self.ks_map[network]["transformed"]
        try:
            result = self.session.execute(
                f"SELECT key FROM {keyspace}.{STATE_TABLE} WHERE key = %s",
                [FRESH_CLUSTERING_ACTIVE_KEY],
            )
            active = result.one() is not None
        except InvalidRequest:
            active = False
        self._fresh_network_cache[network] = active
        return active

    def _check_passed_params(self, df: DataFrame, network: str, req_column: str):
        if df.empty:
            raise Exception(f"Received empty dataframe for network {network}")
        if req_column not in df.columns:
            raise Exception(f"Missing column {req_column}")
        if not self.contains_keyspace_mapping(network):
            raise Exception(f"Network {network} not in keyspace mapping")

    def _query_keyspace_config(self, keyspace: str) -> dict:
        self.session.set_keyspace(keyspace)
        query = "SELECT * FROM configuration"
        result = self.session.execute(query)
        return result[0]

    def keyspace_for_network_exists(self, network: str) -> bool:
        if self.contains_keyspace_mapping(network):
            for k, keyspace in self.ks_map[network].items():
                query = "SELECT keyspace_name FROM system_schema.keyspaces"
                result = self.session.execute(query)
                keyspaces = [row["keyspace_name"] for row in result]

                if keyspace not in keyspaces:
                    return False

            return True
        else:
            return False

    def get_address_ids(self, df: DataFrame, network: str) -> DataFrame:
        """Get address ids for all passed addresses"""
        self._check_passed_params(df, network, "address")

        keyspace = self.ks_map[network]["transformed"]
        ks_config = self._query_keyspace_config(keyspace)
        self.session.set_keyspace(keyspace)

        df_temp = df[["address"]].copy()
        df_temp = df_temp.drop_duplicates()

        if network == "TRX":
            # convert t-style to evm
            df_temp["address"] = df_temp["address"].apply(try_convert_tron_to_eth)

            # filter non convertible addresses
            df_temp = df_temp[df_temp["address"].notnull()]

            df_temp["address_prefix"] = df_temp["address"].str[
                2 : 2 + ks_config["address_prefix_length"]
            ]
            df_temp["address_prefix"] = df_temp["address_prefix"].apply(
                lambda x: x.upper()
            )
            df_temp["address"] = df_temp["address"].apply(
                lambda x: eth_address_from_hex(x)
            )

            # the last step can fail two, eg, wrongly encoded addresses
            # so we filter again filter non convertible addresses
            df_temp = df_temp[df_temp["address"].notnull()]

        elif network == "ETH":
            df_temp["address_prefix"] = df_temp["address"].str[
                2 : 2 + ks_config["address_prefix_length"]
            ]
            df_temp["address_prefix"] = df_temp["address_prefix"].apply(
                lambda x: x.upper()
            )

            df_temp["address"] = df["address"].apply(lambda x: eth_address_from_hex(x))

            # the last step can fail two, eg, wrongly encoded addresses
            # so we filter again filter non convertible addresses
            df_temp = df_temp[df_temp["address"].notnull()]
        else:
            if "bech_32_prefix" in ks_config:
                df_temp["a"] = df_temp["address"].apply(
                    lambda x: x.replace(ks_config["bech_32_prefix"], "")
                )

            df_temp["address_prefix"] = df_temp["a"].str[
                : ks_config["address_prefix_length"]
            ]

        query = (
            "SELECT address, address_id "
            + "FROM address_ids_by_address_prefix "
            + "WHERE address_prefix=? and address=?"
        )

        statement = self.session.prepare(query)
        parameters = df_temp[["address_prefix", "address"]].to_records(index=False)

        result = self._execute_query(statement, parameters)

        if len(result) > 0:
            if network == "ETH":
                result["address"] = result["address"].apply(eth_address_to_hex_str)
            elif network == "TRX":
                # convert evm to t-style address
                result["address"] = result["address"].apply(try_convert_to_tron)

        return result

    def get_cluster_ids(
        self, df: DataFrame, network: str, fresh: bool = False
    ) -> DataFrame:
        """Get cluster ids for all passed address ids"""
        self._check_passed_params(df, network, "address_id")

        if is_eth_like(network):
            raise Exception(f"{network} does not have clusters")

        keyspace = self.ks_map[network]["transformed"]
        ks_config = self._query_keyspace_config(keyspace)
        self.session.set_keyspace(keyspace)

        df_temp = df[["address_id"]].copy()
        df_temp = df_temp.drop_duplicates()
        df_temp["address_id_group"] = np.floor(
            df_temp["address_id"] / ks_config["bucket_size"]
        ).astype(int)

        query = _cluster_id_query(fresh)
        statement = self.session.prepare(query)
        parameters = df_temp[["address_id_group", "address_id"]].to_records(index=False)

        return self._execute_query(statement, parameters)

    def get_clusters(
        self, df: DataFrame, network: str, fresh: bool = False
    ) -> DataFrame:
        """Get clusters for all passed cluster ids"""
        self._check_passed_params(df, network, "cluster_id")

        if is_eth_like(network):
            raise Exception(f"{network} does not have clusters")

        keyspace = self.ks_map[network]["transformed"]
        ks_config = self._query_keyspace_config(keyspace)
        self.session.set_keyspace(keyspace)

        df_temp = df[["cluster_id"]].copy()
        df_temp = df_temp.drop_duplicates()
        df_temp["cluster_id_group"] = np.floor(
            df_temp["cluster_id"] / ks_config["bucket_size"]
        ).astype(int)

        query = _cluster_stats_query(fresh)
        statement = self.session.prepare(query)
        parameters = df_temp[["cluster_id_group", "cluster_id"]].to_records(index=False)

        return self._execute_query(statement, parameters)

    def _get_cluster_definers(self, df: DataFrame, network: str) -> DataFrame:
        keyspace = self.ks_map[network]["transformed"]
        ks_config = self._query_keyspace_config(keyspace)
        self.session.set_keyspace(keyspace)

        df_temp = df[["cluster_id"]].copy()
        df_temp.rename(columns={"cluster_id": "address_id"}, inplace=True)
        df_temp = df_temp.drop_duplicates()
        df_temp["address_id_group"] = np.floor(
            df_temp["address_id"] / ks_config["bucket_size"]
        ).astype(int)

        query = (
            "SELECT address_id as cluster_id, "
            "address as cluster_defining_address FROM address "
            + "WHERE address_id_group=? and address_id=?"
        )
        statement = self.session.prepare(query)
        parameters = df_temp[["address_id_group", "address_id"]].to_records(index=False)

        return self._execute_query(statement, parameters)

    def get_address_clusters(
        self, df: DataFrame, network: str, fresh: bool = False
    ) -> DataFrame:
        """Resolve tagged addresses to their clusters in one regime.

        ``fresh=False`` reads the legacy ``address.cluster_id`` / ``cluster``
        tables, ``fresh=True`` the ``fresh_address_cluster`` /
        ``fresh_cluster_stats`` ones. Callers dual-write marked networks by
        invoking this once per regime — see ``insert_cluster_mapping_wp``.
        """
        self._check_passed_params(df, network, "address")

        addresses = df.copy()

        if network == "ETH":
            # tagpacks include invalid ETH addresses, ignore those
            addresses.drop(
                addresses[~addresses.address.str.startswith("0x")].index, inplace=True
            )
            addresses.rename(columns={"address": "checksum_address"}, inplace=True)
            addresses.loc[:, "address"] = addresses["checksum_address"].str.lower()
        elif network == "TRX":
            addresses.rename(columns={"address": "checksum_address"}, inplace=True)
            addresses.loc[:, "address"] = addresses["checksum_address"]

        df_address_ids = self.get_address_ids(addresses, network)
        if len(df_address_ids) == 0:
            return DataFrame()

        if is_eth_like(network):
            df_address_ids["cluster_id"] = df_address_ids["address_id"]
            df_address_ids["no_addresses"] = 1

            result = df_address_ids.merge(addresses, on="address")

            result.drop("address", axis="columns", inplace=True)
            result.rename(columns={"checksum_address": "address"}, inplace=True)
            result["cluster_defining_address"] = result["address"]

            return result

        df_cluster_ids = self.get_cluster_ids(df_address_ids, network, fresh=fresh)
        if len(df_cluster_ids) == 0:
            # Fresh clustering stores only multi-member clusters, so an empty
            # result means every address in this batch is a singleton — map each
            # to itself instead of dropping the batch. Legacy always has a
            # cluster row, so there an empty result genuinely means "not found".
            if fresh:
                return self._as_singleton_clusters(df_address_ids)
            return DataFrame()

        df_cluster_definers = self._get_cluster_definers(df_cluster_ids, network)

        df_address_clusters = self.get_clusters(df_cluster_ids, network, fresh=fresh)
        if len(df_address_clusters) == 0:
            return DataFrame()

        result = (
            df_address_ids.merge(df_cluster_ids, on="address_id", how="left")
            .merge(df_address_clusters, on="cluster_id", how="left")
            .merge(df_cluster_definers, on="cluster_id", how="left")
        )

        # Fresh clustering persists only multi-member clusters, so an address
        # with no fresh_address_cluster row is its own singleton cluster:
        # cluster_id == address_id, one member, self-defining. Mirrors the
        # account-model branch above. In the legacy scheme address.cluster_id
        # is always set, so this is a no-op there.
        missing = result["cluster_id"].isna()
        if missing.any():
            result.loc[missing, "cluster_id"] = result.loc[missing, "address_id"]
            result.loc[missing, "no_addresses"] = 1
            result.loc[missing, "cluster_defining_address"] = result.loc[
                missing, "address"
            ]
        result["cluster_id"] = result["cluster_id"].astype(int)

        # A resolved cluster_id can still lack a stats row, leaving no_addresses
        # NaN here. A single such row in a 5k batch used to abort the whole
        # multiprocess run on the int cast below (IntCastingNaNError). Classify
        # and log each so a full run reveals the mechanism: either the cluster
        # table has no row for that id ("no_cluster_row"), or a row exists whose
        # no_addresses column is NULL ("row_present_null_no_addresses").
        size_missing = result["no_addresses"].isna()
        if size_missing.any():
            have_stats = (
                set()
                if df_address_clusters.empty
                else set(df_address_clusters["cluster_id"].tolist())
            )
            n_no_row = n_null_col = 0
            for r in result.loc[size_missing].itertuples(index=False):
                cid = int(r.cluster_id)
                row_present = cid in have_stats
                n_null_col += row_present
                n_no_row += not row_present
                logger.warning(
                    "cluster-mapping NULL size: network=%s address=%s "
                    "address_id=%s cluster_id=%s self_ref=%s reason=%s",
                    network,
                    r.address,
                    int(r.address_id),
                    cid,
                    int(r.address_id) == cid,
                    "row_present_null_no_addresses"
                    if row_present
                    else "no_cluster_row",
                )
            logger.warning(
                "cluster-mapping NULL size summary: network=%s count=%s "
                "no_cluster_row=%s row_present_null_no_addresses=%s",
                network,
                int(size_missing.sum()),
                n_no_row,
                n_null_col,
            )

        # Keep the real cluster id and store the unknown size as NULL — not a
        # fabricated 1, which the `gs_cluster_no_addr = 1` singleton branch of
        # the cluster-tag views would then wrongly fold the cluster's tags into.
        result["no_addresses"] = pd.Series(
            [None if pd.isna(v) else int(v) for v in result["no_addresses"]],
            index=result.index,
            dtype=object,
        )

        return result

    def _as_singleton_clusters(self, df_address_ids: DataFrame) -> DataFrame:
        """Map every passed address to its own singleton cluster.

        Used in fresh-clustering mode when no multi-member membership is found:
        cluster_id == address_id, one member, self-defining. Mirrors the shape
        of the normal ``get_address_clusters`` result (address, address_id,
        cluster_id, no_addresses, cluster_defining_address).
        """
        result = df_address_ids.copy()
        result["cluster_id"] = result["address_id"].astype(int)
        result["no_addresses"] = 1
        result["cluster_defining_address"] = result["address"]
        return result
